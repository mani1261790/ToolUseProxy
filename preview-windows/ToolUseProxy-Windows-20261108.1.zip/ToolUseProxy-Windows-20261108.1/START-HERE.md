# Windowsで試す（移植途中・検証不十分）
通常利用の案内はMac版です。このWindows版はネイティブWindowsの試験用です。機密情報のないプロジェクトでだけ試してください。既存のToolUseProxyは上書きしません。

1. ログイン済みのCodex DesktopとCodex CLI、Python 3.11または3.12を用意します。PowerShellから codex --version と py -3.12 --version（または -3.11）を確認します。
2. Jevはこの版では環境変数 TYPESAFE_API_KEY からのみ読みます。自分のキーを利用者側の資格情報管理手段でDesktopに渡してください。チャットやプロジェクト設定に書かないでください。環境変数を変更した場合はDesktopを終了して起動し直します。判定に必要な入力・出力・ファイル内容はJevやCodexへ送られ、各自の利用枠を使います。
3. ZIP展開先で、対象フォルダーと保護するファイルを置き換えて実行します。対象はローカルドライブ上の既存フォルダーに限ります。ジャンクション、ネットワーク共有、特殊記号を含むパスは対象外です。

       py -3.12 -X utf8 install.py --workspace "C:\Work\MyProject" --protect "notes.txt" --accept-judge-data --plan

4. 表示した計画に同意したら同じコマンドから --plan だけを外します。Desktopで対象を開き、標準権限で /hooks にToolUseProxyの5定義があることを確認して人が信頼し、新しいチャットを開きます。
5. 保護ファイル一覧はプロジェクト内で次を実行します。

       py -3.12 -X utf8 .codex/tooluseproxy-review/runtime/tooluseproxy_plugin.py protect --workspace . list

**制限:** 人間による「今回だけ許可」はこのWindows版では無効です。承認記録の編集をDesktopサンドボックスから防げることを実機で確かめるまでは、検出した送信は遮断します。実際のCodex DesktopでのHook配送、実モデルによる判定、ログUI、異常終了時の復旧は未確認です。保護機能が有効であることを前提に実データで試さないでください。
