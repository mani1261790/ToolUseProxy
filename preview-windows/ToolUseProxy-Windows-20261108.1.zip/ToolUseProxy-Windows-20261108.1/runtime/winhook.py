"""Windows preview: no consent override until the Desktop sandbox is validated."""
import os, sys
from pathlib import Path
root=Path(__file__).resolve().parent
os.environ.pop("TOOLUSEPROXY_HUMAN_REVIEW",None)
os.environ.update(PLUGIN_ROOT=str(root), PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
from tooluseproxy_hook_watchdog import main
raise SystemExit(main([sys.argv[1],"--project-data",str(root.parents[2]/".tooluseproxy")]))
