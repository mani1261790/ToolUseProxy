"""Agent-specific integration adapters."""
