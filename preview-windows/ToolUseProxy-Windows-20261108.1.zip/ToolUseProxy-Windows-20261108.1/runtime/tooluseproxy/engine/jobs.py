"""Durable, leased provenance jobs. Never keep a DB write lock while judging."""

from __future__ import annotations

import secrets
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path


def failure_reason(error):
    """Persist a bounded diagnostic code, never exception text or model input."""
    from tooluseproxy.engine.codex import JudgeProviderError
    known = {
        'codex_exec_timeout', 'codex_exec_unavailable', 'semantic_provider_failed',
        'semantic_request_too_large',
        'jev_http_400', 'jev_http_401', 'jev_http_403', 'jev_http_429',
        'jev_http_500', 'jev_http_502', 'jev_http_503', 'jev_http_504',
        'jev_transport_failed', 'jev_invalid_response', 'jev_request_too_large',
        'jev_api_key_missing', 'jev_api_key_invalid', 'jev_key_file_permissions',
        'openai_deadline_exceeded', 'openai_transport_failed', 'openai_invalid_response',
        'openai_decision_refused', 'openai_request_too_large', 'openai_response_too_large',
        'openai_api_key_missing', 'openai_api_key_invalid', 'openai_key_file_permissions',
        'openai_http_401', 'openai_http_403', 'openai_http_429',
        'openai_http_500', 'openai_http_502', 'openai_http_503', 'openai_http_504',
    }
    code = getattr(error, 'code', None)
    if isinstance(error, JudgeProviderError) and isinstance(code, str) and code in known:
        return 'background_analysis_failed:' + code
    return 'background_analysis_failed'


def schema(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS flow_jobs (
        scope TEXT NOT NULL,event TEXT NOT NULL,session TEXT NOT NULL,model TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('pending','running','done','failed','paused')),
        owner TEXT,lease_until REAL NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,
        reason TEXT NOT NULL DEFAULT '',PRIMARY KEY(scope,event,model))""")
    conn.execute("CREATE INDEX IF NOT EXISTS flow_job_queue ON flow_jobs(scope,status,lease_until)")


@contextmanager
def transaction(db):
    conn = sqlite3.connect(db, timeout=5)
    try:
        conn.execute("BEGIN IMMEDIATE")
        schema(conn)
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


def enqueue(db, event, model):
    if event.phase != "post_tool_use":
        return
    with transaction(db) as conn:
        conn.execute(
            "INSERT INTO flow_jobs(scope,event,session,model,status) VALUES (?,?,?,?,?) ON CONFLICT DO NOTHING",
            (event.workspace_id, event.event_id, event.session_id, model, "pending"),
        )


def claim(db, scope, now=None):
    now = time.time() if now is None else now
    owner = secrets.token_hex(16)
    with transaction(db) as conn:
        conn.execute(
            "UPDATE flow_jobs SET status='failed',reason='lease_retries_exhausted' WHERE scope=? AND status='running' AND lease_until<? AND attempts>=3",
            (scope, now),
        )
        # Expired leases can be reclaimed; failures are not endlessly retried.
        row = conn.execute(
            """SELECT j.event,j.session,j.model,j.attempts FROM flow_jobs j
            JOIN events e ON e.event_id=j.event
            WHERE j.scope=? AND (j.status='pending' OR (j.status='running' AND j.lease_until<?))
            AND j.attempts<3 ORDER BY e.sequence_no LIMIT 1""",
            (scope, now),
        ).fetchone()
        if not row:
            return None
        event, session, model, attempts = row
        conn.execute(
            "UPDATE flow_jobs SET status='running',owner=?,lease_until=?,attempts=? WHERE scope=? AND event=? AND model=?",
            (owner, now + 600, attempts + 1, scope, event, model),
        )
    return dict(scope=scope, event=event, session=session, model=model, owner=owner)


def finish(db, job, status, reason=""):
    if status not in ("done", "failed", "paused", "pending"):
        raise ValueError("invalid_job_outcome")
    with transaction(db) as conn:
        if status == "pending" and reason == "foreground_priority":
            conn.execute(
                "UPDATE flow_jobs SET attempts=MAX(attempts-1,0) WHERE scope=? AND event=? AND model=? AND owner=? AND status='running'",
                (job["scope"], job["event"], job["model"], job["owner"]),
            )
        changed = conn.execute(
            "UPDATE flow_jobs SET status=?,reason=?,lease_until=0 WHERE scope=? AND event=? AND model=? AND status='running' AND owner=?",
            (status, reason, job["scope"], job["event"], job["model"], job["owner"]),
        ).rowcount
    return changed == 1


@dataclass(frozen=True)
class DrainBatch:
    completed: int
    exhausted: bool
    stop_reason: str


def runnable_jobs(db, scope, *, now=None):
    """Read the same eligibility boundary as claim(), without acquiring a job."""
    with sqlite3.connect(Path(db).resolve().as_uri() + '?mode=ro', uri=True) as conn:
        return conn.execute('''SELECT 1 FROM flow_jobs j
            JOIN events e ON e.event_id=j.event
            WHERE j.scope=? AND j.attempts<3 AND
            (j.status='pending' OR (j.status='running' AND j.lease_until<?))
            LIMIT 1''', (scope, time.time() if now is None else now)).fetchone() is not None


def drain(db, scope, *, provider=None, max_jobs=32, lease_factory=None):
    """Keep the bounded single-batch API for callers requesting explicit work."""
    return drain_batch(db, scope, provider=provider, max_jobs=max_jobs,
                       lease_factory=lease_factory).completed


def drain_batch(db, scope, *, provider=None, max_jobs=32, lease_factory=None):
    from tooluseproxy.engine.runtime import configuration, session_lock
    from tooluseproxy.engine.decisions import make_judge, provider_identity
    from tooluseproxy.engine.property_graph import analyze_properties
    from tooluseproxy.integrations.activation import enabled_workspace_root
    from tooluseproxy.integrations.authority import registered_workspace_authority_lease

    if max_jobs < 1:
        raise ValueError('max_jobs must be positive')
    completed = 0
    exhausted = False
    stop_reason = 'batch_limit'
    for _ in range(max_jobs):
        job = claim(db, scope)
        if job is None:
            stop_reason = 'empty'
            break
        try:
            config = configuration(Path(db), scope)
            if not config or config.get("background_provenance") is not True:
                finish(db, job, "paused", "background_disabled")
                continue
            with sqlite3.connect(db) as conn:
                lease = (lease_factory or registered_workspace_authority_lease)(
                    Path(db), conn, scope
                )
                with lease as state:
                    if state is not None and state.phase != "active":
                        finish(db, job, "paused", "authority_inactive")
                        continue
                    row = conn.execute(
                        "SELECT canonical_root FROM workspaces WHERE workspace_id=?", (scope,)
                    ).fetchone()
                    if not row or enabled_workspace_root(Path(db), row[0]) != row[0]:
                        finish(db, job, "paused", "workspace_inactive")
                        continue
                    current_model = provider_identity(config)
                    if current_model != job["model"]:
                        finish(db, job, "paused", "model_changed")
                        continue
                    started = time.monotonic()
                    judge = provider or make_judge(config)

                    def yield_to_foreground():
                        if foreground_waiting(db, scope, job['session']):
                            raise PriorityYield()

                    # Only speculative background inference is interruptible.
                    # Foreground inference always finishes its safety assessment.
                    extractor = getattr(judge, 'extractor', judge)
                    if hasattr(extractor, 'cancel_check'):
                        extractor.cancel_check = yield_to_foreground
                    if hasattr(judge, "timing_context"):
                        judge.timing_context = (db, job["event"])

                    def bounded(records, method=None):
                        live_config = configuration(Path(db), scope)
                        if not live_config or live_config.get("background_provenance") is not True:
                            raise BackgroundDisabled()
                        if provider_identity(live_config) != job["model"]:
                            raise BackgroundDisabled()
                        if foreground_waiting(db, scope, job["session"]):
                            raise PriorityYield()
                        if time.monotonic() - started > 480:
                            raise WorkBudget('background_time_budget')
                        from tooluseproxy.engine.request_budget import provider_requests_fit
                        if not provider_requests_fit(judge, records, method):
                            raise WorkBudget('background_request_budget')
                        return getattr(judge, method)(records) if method else judge(records)

                    from functools import partial
                    for method in ('review_scopes', 'review_frontier'):
                        if callable(getattr(judge, method, None)):
                            setattr(bounded, method, partial(bounded, method=method))

                    with session_lock(Path(db), scope, job["session"], background=True):
                        from tooluseproxy.engine.review import ReviewRetry
                        from tooluseproxy.engine.codex import JudgeProviderError
                        # Shape/selector feedback is persisted by review(). Resume
                        # the same evidence, retaining completed checkpoints. A
                        # repair failure never certifies ancestry or permission.
                        for repair_attempt in range(3):
                            try:
                                result = analyze_properties(
                                    Path(db), scope, job["session"], job["event"],
                                    [], bounded, model=job["model"],
                                )
                                # A local permission is not completed ancestry.
                                # Reassess unfinished evidence using review()'s
                                # persisted feedback, within the same bounded loop.
                                if result.get("graph_complete") is True:
                                    break
                            except ReviewRetry:
                                if repair_attempt == 2:
                                    result = {"action": "unavailable",
                                              "graph_complete": False}
                            except JudgeProviderError as error:
                                # The same extractor retains its bounded timeout
                                # adaptation. Completed independent reviews were
                                # checkpointed, so resume only unresolved evidence.
                                if error.code != 'codex_exec_timeout' or repair_attempt == 2:
                                    raise

            # Allowing a local operation does not certify its ancestry. Jobs
            # track provenance completion, not permission to execute the call.
            if result["action"] == "unavailable" or result.get("graph_complete") is not True:
                finish(db, job, "paused", "analysis_incomplete")
                # An incomplete observation is not a global queue barrier.
                # Keep it incomplete, but allow later independent jobs to progress.
                continue
            finish(db, job, "done")
            completed += 1
        except BackgroundDisabled:
            finish(db, job, "paused", "configuration_changed")
        except WorkBudget as error:
            finish(db, job, "pending", error.reason)
            stop_reason = 'budget'
            break
        except PriorityYield:
            finish(db, job, "pending", "foreground_priority")
            stop_reason = 'foreground_priority'
            break
        except Exception as error:
            finish(db, job, "failed", failure_reason(error))
    else:
        # A full batch is not an outage, preemption or empty queue. The detached
        # worker may continue; failed/paused jobs remain excluded by claim().
        exhausted = True
    return DrainBatch(completed, exhausted, stop_reason)


class BackgroundDisabled(Exception):
    pass


class WorkBudget(Exception):
    def __init__(self, reason='background_budget'):
        self.reason = reason
        super().__init__(reason)


class PriorityYield(Exception):
    pass


def priority_schema(conn):
    conn.execute(
        "CREATE TABLE IF NOT EXISTS flow_foreground_waiters (scope TEXT NOT NULL,session TEXT NOT NULL,owner TEXT PRIMARY KEY,until REAL NOT NULL)"
    )


def foreground_waiting(db, scope, session):
    with sqlite3.connect(db, timeout=5) as conn:
        priority_schema(conn)
        return bool(
            conn.execute(
                "SELECT 1 FROM flow_foreground_waiters WHERE scope=? AND session=? AND until>?",
                (scope, session, time.time()),
            ).fetchone()
        )


def queue_status(db, scope):
    """Diagnostics must not initialize a database or mutate the queue."""
    if not Path(db).is_file():
        return {}
    conn = sqlite3.connect(Path(db).resolve().as_uri() + "?mode=ro", uri=True, timeout=1)
    try:
        if not conn.execute("SELECT 1 FROM sqlite_master WHERE name='flow_jobs'").fetchone():
            return {}
        return dict(conn.execute("SELECT status,COUNT(*) FROM flow_jobs WHERE scope=? GROUP BY status", (scope,)))
    finally:
        conn.close()
