"""Versioned ToolCall properties and information edges, independent of policy roots."""

from __future__ import annotations

import json
import posixpath
import sqlite3
import time
from collections import deque
from collections.abc import Mapping, Set
from contextlib import closing

from tooluseproxy.engine.graph import GraphUnavailable, digest, initialize
from tooluseproxy.engine import projection
from tooluseproxy.engine.judge import PROMPT_VERSION
from tooluseproxy.engine.requirements import reusable
from tooluseproxy.engine.review import REVIEW_VERSION

ANALYSIS_VERSION = "decision-certificates-v5"


def schema(conn):
    initialize(conn)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS graph_revisions (
            revision TEXT PRIMARY KEY, workspace TEXT NOT NULL, session TEXT NOT NULL,
            node TEXT NOT NULL, event TEXT NOT NULL, model TEXT NOT NULL, prompt TEXT NOT NULL,
            verdict TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS graph_direct_reviews (
            request TEXT PRIMARY KEY, verdict TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS graph_completed_reviews (
            request TEXT PRIMARY KEY, revision TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS graph_heads (
            workspace TEXT NOT NULL, session TEXT NOT NULL, node TEXT NOT NULL,
            revision TEXT NOT NULL, PRIMARY KEY(workspace,session,node));
        CREATE TABLE IF NOT EXISTS graph_edges (
            revision TEXT NOT NULL, src TEXT NOT NULL, dst TEXT NOT NULL, reason TEXT NOT NULL,
            PRIMARY KEY(revision,src,dst));
        CREATE INDEX IF NOT EXISTS graph_incoming ON graph_edges(dst,revision,src);
        CREATE INDEX IF NOT EXISTS graph_outgoing ON graph_edges(src,revision,dst);
        CREATE TABLE IF NOT EXISTS graph_accesses (
            revision TEXT NOT NULL, node TEXT NOT NULL, path TEXT NOT NULL,
            mode TEXT NOT NULL, reason TEXT NOT NULL,
            PRIMARY KEY(revision,path,mode));
        CREATE INDEX IF NOT EXISTS graph_resource ON graph_accesses(path,mode,revision,node);
        CREATE TABLE IF NOT EXISTS graph_revision_links (
            revision TEXT NOT NULL, parent_node TEXT NOT NULL, parent_revision TEXT NOT NULL,
            PRIMARY KEY(revision,parent_node));
        CREATE TABLE IF NOT EXISTS graph_output_selections (
            revision TEXT PRIMARY KEY, node TEXT NOT NULL, selection_json TEXT NOT NULL,
            observation_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS graph_resource_selections (
            revision TEXT PRIMARY KEY, node TEXT NOT NULL, selection_json TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS graph_policies (
            revision TEXT PRIMARY KEY, sources_json TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS graph_progress (
            workspace TEXT NOT NULL, session TEXT NOT NULL, event TEXT NOT NULL,
            state TEXT NOT NULL, PRIMARY KEY(workspace,session));
        CREATE TABLE IF NOT EXISTS graph_policy_checks (
            event TEXT NOT NULL, policy_revision TEXT NOT NULL, graph_revision TEXT NOT NULL,
            result TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(event,policy_revision,graph_revision));
    """)


def selection_texts(selection):
    """Normalize a finite union of observed fragments, without widening to all output."""
    if not isinstance(selection, dict) or set(selection) not in ({"text"}, {"texts"}):
        raise GraphUnavailable("invalid_output_selection")
    texts = [selection["text"]] if "text" in selection else selection["texts"]
    if (not isinstance(texts, list) or not texts
        or any(not isinstance(text, str) or not text for text in texts)
        or sum(len(text) for text in texts) > 128_000):
        raise GraphUnavailable("invalid_output_selection")
    return sorted(set(texts))


def merge_selections(left, right):
    # Whole-output evidence subsumes fragments; distinct fragments do not imply
    # that an unrelated field in the same observation contributed information.
    if left is None or right is None:
        return None
    texts = sorted(set(selection_texts(left) + selection_texts(right)))
    result = {"text": texts[0]} if len(texts) == 1 else {"texts": texts}
    selection_texts(result)
    return result


def independent_output_leaf(value):
    # File reads, unresolved evidence and dependency-bearing verdicts cannot
    # prove a smaller output independent. Never reuse these as permission.
    return (value.get('complete') is True and value.get('dependencies') == []
            and value.get('accesses') == [] and not value.get('evidence_requests')
            and not value.get('evidence_receipts'))


def output_ranges(output, selection):
    if not isinstance(output, str):
        output = json.dumps(output, ensure_ascii=False, sort_keys=True)
    texts = selection_texts(selection)
    if any(output.find(text) < 0 or output.find(text, output.find(text) + 1) >= 0
           for text in texts):
        raise GraphUnavailable('output_selection_missing_or_ambiguous')
    return [[output.index(text), output.index(text) + len(text)] for text in texts]


def output_certificate(conn, context, output, selection, *, save=None):
    """Reuse only a subset of ONE joint independent-output assessment.

    Context binds the exact producer, historical prefix and provider versions.
    Distinct certificates are never unioned: individually independent shares
    do not establish independence of their combination.
    """
    conn.execute('''CREATE TABLE IF NOT EXISTS graph_output_certificates (
        context TEXT NOT NULL, observation TEXT NOT NULL, certificate TEXT NOT NULL,
        ranges TEXT NOT NULL, verdict TEXT NOT NULL,
        PRIMARY KEY(context,observation,certificate))''')
    observation = digest(output)
    try:
        ranges = output_ranges(output, selection)
    except GraphUnavailable:
        # This optimization must not introduce a new unavailable path. Leave
        # ambiguous scopes to the existing evidence-resolution/repair flow.
        return None
    if save is not None:
        if independent_output_leaf(save):
            conn.execute('INSERT OR IGNORE INTO graph_output_certificates VALUES (?,?,?,?,?)',
                         (context, observation, digest(ranges), json.dumps(ranges), json.dumps(save)))
        return None
    for encoded, raw in conn.execute(
            'SELECT ranges,verdict FROM graph_output_certificates WHERE context=? AND observation=?',
            (context, observation)):
        try:
            prior, value = json.loads(encoded), json.loads(raw)
            observed_length = len(output if isinstance(output, str) else
                                  json.dumps(output, ensure_ascii=False, sort_keys=True))
            if (independent_output_leaf(value) and prior
                    and all(type(a) is int and type(b) is int and 0 <= a < b
                            and b <= observed_length
                            for a, b in prior)
                    and all(any(a <= start and end <= b for a, b in prior)
                            for start, end in ranges)):
                return value
        except (ValueError, TypeError, KeyError, AttributeError):
            continue
    return None


def validate_observed_dependencies(value, candidates, observations):
    """Validate selectors while the producing assessment can still be corrected."""
    value = validate(value, candidates)
    for edge in value['dependencies']:
        selection = edge.get('selection')
        if selection is None:
            continue
        parent = observations[edge['node_id']]
        observed = parent['output']
        if not isinstance(observed, str):
            observed = json.dumps(observed, ensure_ascii=False, sort_keys=True)
        counts = [observed.count(text) for text in selection_texts(selection)]
        if not parent['completed'] or any(count != 1 for count in counts):
            # No payload text in diagnostics. The unchanged record is already
            # available to the reviewer; repair the edge, never silently widen it.
            raise GraphUnavailable(
                'output_selection_missing_or_ambiguous: '
                f"parent={edge['node_id']}; occurrences={counts}; "
                'select an exact unique fragment of the recorded output; '
                'for structured output use its JSON representation; '
                'retain every actual contribution and do not invent observations'
            )
    return value


def validate(value, candidates):
    if not isinstance(value, dict) or set(value) - {"evidence_requests", "evidence_receipts"} != {
        "externality",
        "complete",
        "reason",
        "dependencies",
        "accesses",
    }:
        raise GraphUnavailable("invalid_property_verdict")
    if value["externality"] not in ("local", "external") or type(value["complete"]) is not bool:
        raise GraphUnavailable("invalid_property_classification")
    if not isinstance(value["reason"], str) or not 0 < len(value["reason"]) <= 4000:
        raise GraphUnavailable("invalid_property_reason")
    if not isinstance(value["dependencies"], list) or not isinstance(value["accesses"], list):
        raise GraphUnavailable("invalid_property_lists")
    dependencies = {}
    for edge in value["dependencies"]:
        if (
            not isinstance(edge, dict)
            or set(edge) - {"selection"} != {"node_id", "reason"}
            or not isinstance(edge["node_id"], str)
            or edge["node_id"] not in candidates
            or not isinstance(edge["reason"], str)
            or not 0 < len(edge["reason"]) <= 4000
        ):
            raise GraphUnavailable("invalid_property_edge")
        selection = edge.get("selection")
        if selection is not None:
            selection_texts(selection)
        old = dependencies.get(edge["node_id"])
        dependencies[edge["node_id"]] = (
            dict(edge, selection=merge_selections(old.get("selection"), selection))
            if old is not None else edge
        )
    accesses = {}
    for access in value["accesses"]:
        if not isinstance(access, dict) or set(access) != {"path", "mode", "reason"}:
            raise GraphUnavailable("invalid_access")
        path = access["path"]
        if (
            not isinstance(path, str)
            or not path
            or len(path) > 4096
            or "\x00" in path
            or path == ".."
            or path.startswith("../")
            or posixpath.normpath(path) != path
            or access["mode"] not in ("read", "write")
            or not isinstance(access["reason"], str)
            or not 0 < len(access["reason"]) <= 4000
        ):
            raise GraphUnavailable("invalid_access")
        key = (path, access["mode"])
        accesses[key] = access
    requests = value.get("evidence_requests", [])
    if not isinstance(requests, list) or len(requests) > 8:
        raise GraphUnavailable("invalid_evidence_requests")
    for request in requests:
        if (not isinstance(request, dict) or set(request) != {"path", "reason"}
            or not all(isinstance(request[k], str) and 0 < len(request[k]) <= 4096 for k in request)):
            raise GraphUnavailable("invalid_evidence_request")
    if value["complete"] and requests:
        raise GraphUnavailable("completed_with_evidence_requests")
    return dict(value, dependencies=list(dependencies.values()), accesses=list(accesses.values()))


def persist(conn, workspace, session, node, revision, model, verdict, parent_revisions=None):
    current = conn.execute(
        "SELECT revision FROM graph_heads WHERE workspace=? AND session=? AND node=?",
        (workspace, session, node["node_id"]),
    ).fetchone()
    if current and current[0] == revision and conn.execute(
        "SELECT 1 FROM graph_revisions WHERE revision=?", (revision,)
    ).fetchone():
        return
    conn.execute(
        "INSERT OR IGNORE INTO graph_revisions(revision,workspace,session,node,event,model,prompt,verdict) VALUES (?,?,?,?,?,?,?,?)",
        (
            revision,
            workspace,
            session,
            node["node_id"],
            node["event_id"],
            model,
            PROMPT_VERSION,
            json.dumps(verdict),
        ),
    )
    conn.executemany(
        "INSERT OR IGNORE INTO graph_edges VALUES (?,?,?,?)",
        [(revision, e["node_id"], node["node_id"], e["reason"]) for e in verdict["dependencies"]],
    )
    conn.executemany(
        "INSERT OR IGNORE INTO graph_accesses VALUES (?,?,?,?,?)",
        [
            (revision, node["node_id"], a["path"], a["mode"], a["reason"])
            for a in verdict["accesses"]
        ],
    )
    conn.executemany(
        "INSERT OR IGNORE INTO graph_revision_links VALUES (?,?,?)",
        [
            (revision, e["node_id"], parent_revisions[e["node_id"]])
            for e in verdict["dependencies"]
            if parent_revisions is not None
        ],
    )
    conn.execute(
        "INSERT OR REPLACE INTO graph_heads VALUES (?,?,?,?)",
        (workspace, session, node["node_id"], revision),
    )


def revision_parents(conn, workspace, node, revision):
    rows = conn.execute(
        """SELECT e.src,l.parent_revision FROM graph_edges e
        LEFT JOIN graph_revision_links l ON l.revision=e.revision AND l.parent_node=e.src
        WHERE e.revision=? AND e.dst=?""",
        (revision, node),
    ).fetchall()
    result = []
    for parent, parent_revision in rows:
        if parent_revision is None:
            # Compatibility for graph-only fixtures/benchmarks, not persisted judgments.
            if conn.execute(
                "SELECT 1 FROM graph_revisions WHERE revision=?", (revision,)
            ).fetchone():
                raise GraphUnavailable("dependency_revision_missing")
            row = conn.execute(
                "SELECT revision FROM graph_heads WHERE workspace=? AND node=?", (workspace, parent)
            ).fetchone()
            parent_revision = row[0] if row else None
        if parent_revision is None:
            raise GraphUnavailable("dependency_node_missing")
        result.append((parent, parent_revision))
    return result


def reach(conn, workspace, session, node, roots, limit=200_000):
    if not roots:
        return []
    head = conn.execute(
        "SELECT revision FROM graph_heads WHERE workspace=? AND session=? AND node=?",
        (workspace, session, node),
    ).fetchone()
    if not head:
        return []
    start = (node, head[0])
    queue, toward = deque([start]), {start: None}
    while queue:
        current = queue.popleft()
        source = roots.get(current, roots.get(current[0]))
        if source:
            path = [source, current[0]]
            while toward[current] is not None:
                current = toward[current]
                path.append(current[0])
            return path
        for parent in revision_parents(conn, workspace, *current):
            if parent not in toward:
                if len(toward) >= limit:
                    raise GraphUnavailable("graph_traversal_budget_exceeded")
                toward[parent] = current
                queue.append(parent)
    return []


def bindings(conn, workspace, session, sources):
    roots = {}
    complete = True
    for source in sources:
        selector = source.get("selector")
        if not whole_file_selector(selector):
            complete = False
            continue
        # A policy marks the resource over the recorded history, not a claim that
        # every version contains identical bytes. Missing/ambiguous identity stays unknown.
        path = source.get("path")
        if not isinstance(path, str) or path.startswith("/") or posixpath.normpath(path) != path:
            complete = False
            continue
        rows = conn.execute(
            """SELECT a.node,a.revision FROM graph_accesses a JOIN graph_revisions r
            ON r.revision=a.revision AND r.node=a.node
            WHERE a.path=? AND a.mode='read' AND r.workspace=?""",
            (path, workspace),
        )
        for node, revision in rows:
            roots[(node, revision)] = source["node_id"]
    return roots, complete


class CallIndex:
    def __init__(self, calls):
        self.calls = calls

    def __getitem__(self, node):
        index = self.calls.position(node=node)
        if index is None:
            raise KeyError(node)
        return index


class CallObservations(Mapping):
    def __init__(self, calls):
        self.calls = calls

    def __getitem__(self, node):
        return self.calls[CallIndex(self.calls)[node]]

    def __iter__(self):
        return (node['node_id'] for node in self.calls)

    def __len__(self):
        return len(self.calls)


class CompletedCandidates(Set):
    def __init__(self, calls, end=None):
        self.calls, self.end = calls, len(calls) if end is None else end

    def before(self, end):
        return CompletedCandidates(self.calls, end)

    def __contains__(self, node):
        index = self.calls.position(node=node)
        return index is not None and index < self.end and self.calls[index]['completed']

    def __iter__(self):
        return (self.calls[i]['node_id'] for i in range(self.end) if self.calls[i]['completed'])

    def __len__(self):
        return sum(1 for _ in self)


def whole_file_selector(selector):
    """Use the same selector semantics for early certificates and final binding.

    Serialized whole-file registrations include values=[], unlike minimal test
    fixtures. Metadata must not silently disable positive-path pruning.
    """
    return not selector or isinstance(selector, dict) and selector.get('kind') == 'whole_file'


def protected_resources(sources):
    return {s['path']: s['node_id'] for s in sources
            if isinstance(s.get('path'), str) and not s['path'].startswith('/')
            and posixpath.normpath(s['path']) == s['path']
            and whole_file_selector(s.get('selector'))}


def pinned_path(conn, node, revision, sources):
    """Find a positive certificate without enumerating all policy bindings."""
    paths = protected_resources(sources)
    if not paths:
        return []
    pending = deque([(node, revision)])
    toward = {(node, revision): None}
    while pending:
        current = pending.popleft()
        for (path,) in conn.execute("SELECT path FROM graph_accesses WHERE revision=? AND mode='read'",
                                    (current[1],)):
            if path in paths:
                result = [paths[path], current[0]]
                while toward[current] is not None:
                    current = toward[current]
                    result.append(current[0])
                return result
        for parent in conn.execute("SELECT parent_node,parent_revision FROM graph_revision_links WHERE revision=?",
                                    (current[1],)):
            if parent not in toward:
                toward[parent] = current
                pending.append(parent)
    return []


def build_properties(db_path, workspace, session, event_id, sources, judge, *,
                     model, sources_refresh, current_evidence, visiting, _resource_scope):
    current_verdict = None
    evidence_context = {}
    with closing(sqlite3.connect(db_path, timeout=5)) as conn:
        analysis_token = projection.token(conn)
        analysis_boundary = projection.boundary(conn, workspace)
        with conn:
            calls = projection.prepare(conn, workspace, session, event_id)
        index = calls.position(event=event_id)
        if index is None:
            raise GraphUnavailable("current_node_missing")
        if current_evidence is not None:
            if isinstance(current_evidence, dict):
                calls[index]["payload_observations"] = current_evidence['parts']
                calls[index]["payload_coverage_complete"] = current_evidence['complete'] is True
                calls[index]["payload_contract_verified"] = current_evidence.get('contract_verified') is True
            else:
                calls[index]["payload_observations"] = current_evidence
        by_id = CallIndex(calls)
        candidates = CompletedCandidates(calls)
        observations = CallObservations(calls)
        tree_cacheable = {}
        positive_paths = {}
        protected = protected_resources(sources)
        assessed = {}
        pending_reviews = {}
        staged_reviews = {}
        frontier_batching = callable(getattr(judge, 'review_frontier', None))
        batching = frontier_batching or callable(getattr(judge, 'review_scopes', None))

        class PendingReview(Exception):
            pass

        def assess(index, selection=None, depth=0, resources=None):
            if depth >= 128 or len(assessed) > 50_000:
                raise GraphUnavailable("output_provenance_expansion_budget")
            producer = calls[index]
            historical = None
            if producer.get('pre_execution_payload_ref') is not None:
                from tooluseproxy.engine.transmission_evidence import load
                historical = load(conn, workspace, producer)
                if historical is not None:
                    producer = dict(producer, pre_execution_payload=historical)
            if historical is not None and selection is None and resources is None:
                # A whole operation includes its submitted payload. A selected
                # response does not automatically inherit every submitted byte.
                producer = dict(producer,
                                pre_execution_payload={k: v for k, v in historical.items() if k != 'parts'},
                                payload_observations=historical['parts'],
                                payload_coverage_complete=historical.get('complete') is True,
                                payload_contract_verified=historical.get('contract_verified') is True)
            if selection is not None:
                texts = selection_texts(selection)
                selection = {'text': texts[0]} if len(texts) == 1 else {'texts': texts}
            key = (index, digest([selection, resources]))
            if key in assessed:
                return assessed[key]
            focused = dict(producer)
            if resources is not None:
                witnessed = {(r['path'], r['version']) for r in producer.get('resource_observations', [])
                             if r['mode'] == 'write' and r['status'] == 'observed'}
                if not resources or any((r['path'], r['version']) not in witnessed for r in resources):
                    raise GraphUnavailable('resource_selection_not_observed')
                focused['required_resources'] = resources
            if selection is not None:
                observed = producer["output"] if isinstance(producer["output"], str) else json.dumps(producer["output"], ensure_ascii=False, sort_keys=True)
                if not producer["completed"] or any(observed.count(text) != 1 for text in selection_texts(selection)):
                    raise GraphUnavailable("output_selection_missing_or_ambiguous")
                focused["required_output"] = dict(selection, observation_hash=digest(producer["output"]))
            request = digest([ANALYSIS_VERSION, projection.VERSION, REVIEW_VERSION,
                              PROMPT_VERSION, model, calls.prefix(index), focused])
            subtree = projection.cached_tree(conn, request, workspace)
            if subtree is not None:
                _, revision, verdict = subtree
                tree_cacheable[revision] = True
                positive_paths[revision] = pinned_path(conn, producer['node_id'], revision, sources)
                assessed[key] = revision, verdict
                if selection is None and resources is None:
                    with conn:
                        conn.execute("INSERT OR REPLACE INTO graph_heads VALUES (?,?,?,?)",
                                     (workspace, session, producer['node_id'], revision))
                return revision, verdict
            cached = conn.execute("SELECT verdict FROM graph_direct_reviews WHERE request=?", (request,)).fetchone()
            if cached and not reusable(json.loads(cached[0]), producer):
                cached = None
            candidate_ids = candidates.before(index)
            def validate_current(value, allowed):
                return validate_observed_dependencies(value, allowed, observations)

            cached_verdict = None
            if cached:
                try:
                    cached_verdict = validate_current(json.loads(cached[0]), candidate_ids)
                except GraphUnavailable:
                    # An invalid cached selection needs a fresh assessment.
                    cached = None
            scope_context = (digest(['independent-output-v1', ANALYSIS_VERSION, projection.VERSION,
                                    REVIEW_VERSION, PROMPT_VERSION, model, calls.prefix(index), producer])
                             if selection is not None else None)
            if cached_verdict is None and selection is not None:
                inherited = output_certificate(conn, scope_context, producer['output'], selection)
                if inherited is not None:
                    try:
                        cached_verdict = validate_current(inherited, candidate_ids)
                    except GraphUnavailable:
                        cached_verdict = None
                    if cached_verdict is not None:
                        cached = True
                        from tooluseproxy.engine.timing import record_assessment
                        record_assessment(db_path, event_id, request,
                                          dict(kind='output_scope_reuse', reused=True))
            # Independence of the entire unchanged operation proves independence
            # of its selected outputs/resources. The reverse is invalid. Reuse
            # only a complete leaf with NO content reads, dependencies or acquired
            # evidence, so narrowing cannot carry unrelated taint or stale files.
            if cached_verdict is None and (selection is not None or resources is not None):
                whole_request = digest([ANALYSIS_VERSION, projection.VERSION, REVIEW_VERSION,
                                        PROMPT_VERSION, model, calls.prefix(index), producer])
                whole = conn.execute("SELECT verdict FROM graph_direct_reviews WHERE request=?",
                                     (whole_request,)).fetchone()
                if whole:
                    candidate = json.loads(whole[0])
                    if (candidate.get('complete') is True
                            and candidate.get('dependencies') == []
                            and not candidate.get('evidence_receipts')
                            and not candidate.get('evidence_requests')
                            and all(a.get('mode') == 'write' for a in candidate.get('accesses', []))):
                        cached_verdict = validate_current(candidate, candidate_ids)
                        cached = True
            from tooluseproxy.engine.contracts import provenance_contract
            mechanical = provenance_contract(focused)
            if mechanical is not None:
                verdict = validate_current(mechanical, candidate_ids)
            elif cached:
                verdict = cached_verdict
            else:
                from tooluseproxy.engine.review import review
                records = {"previous_calls": calls[:index], "current_call": focused}
                if batching:
                    if request not in staged_reviews:
                        pending_reviews[request] = (index, records)
                        raise PendingReview()
                    verdict = staged_reviews[request]
                else:
                    verdict = review(db_path, request, records, judge, validate_current, evidence_context=evidence_context)
            if verdict['complete']:
                with conn:
                    conn.execute("INSERT OR REPLACE INTO graph_direct_reviews VALUES (?,?)",
                                 (request, json.dumps(verdict)))
                    if selection is not None:
                        output_certificate(conn, scope_context, producer['output'], selection, save=verdict)
            # A transmitted value selected from a controller-loaded observation
            # has a mandatory producer edge. A model cannot omit that provenance.
            observed_edges = {}
            for part in producer.get('payload_observations', []):
                parent = part.get('observation', {}).get('source_node_id')
                if parent is None:
                    continue
                if parent not in candidate_ids:
                    raise GraphUnavailable('observed_transmission_parent_missing')
                original = calls[by_id[parent]]['output']
                original = original if isinstance(original, str) else json.dumps(original, ensure_ascii=False, sort_keys=True)
                content = part.get('content', '')
                output_selection = ({'text': content} if part.get('encoding') == 'utf-8'
                             and content and original.count(content) == 1 else None)
                old = observed_edges.get(parent)
                if old is not None:
                    output_selection = merge_selections(old['selection'], output_selection)
                observed_edges[parent] = dict(node_id=parent, selection=output_selection,
                                              reason='controller-resolved transmitted output')
            if observed_edges:
                dependencies = {edge['node_id']: edge for edge in verdict['dependencies']}
                for parent, edge in observed_edges.items():
                    old = dependencies.get(parent)
                    if old is not None:
                        edge = dict(edge, selection=merge_selections(old.get('selection'), edge['selection']))
                    dependencies[parent] = edge
                verdict = dict(verdict, dependencies=list(dependencies.values()))
            # Relative and absolute aliases must name the same policy resource.
            from tooluseproxy.engine.requirements import resource_identity
            context_projections = {}
            if mechanical is not None:
                from tooluseproxy.engine.contracts import read_projections
                context_projections.update({path: parts for path, parts in read_projections(focused).items()
                                            if parts is not None})
            context_accesses = []
            for part in producer.get('payload_observations', []):
                origin = part.get('observation', {}).get('context_origin')
                if origin is None:
                    continue
                path = resource_identity(origin['path'], producer['workspace_root'])
                context_projections.setdefault(path, []).append(origin['projection'])
                context_accesses.append(dict(path=path, mode='read',
                                             reason='controller-observed configuration value'))
            for part in producer.get('payload_observations', []):
                observation = part.get('observation', {})
                if observation.get('context_origin'):
                    continue
                # A separately submitted whole file must not be narrowed to a
                # configuration field just because both share an origin path.
                paths = [observation['path']] if 'path' in observation else []
                for path in paths:
                    context_projections.pop(resource_identity(path, producer['workspace_root']), None)
            from tooluseproxy.engine.resource_contracts import payload_accesses
            accesses = {}
            for access in verdict['accesses'] + context_accesses + payload_accesses(producer):
                access = dict(access, path=resource_identity(access['path'], producer['workspace_root']))
                accesses[(access['path'], access['mode'])] = access
            verdict = dict(verdict, accesses=list(accesses.values()))
            positive = next(([protected[a['path']], producer['node_id']]
                             for a in verdict['accesses']
                             if a['mode'] == 'read' and a['path'] in protected), [])
            # Collect all demands on each producer BEFORE reviewing it. A consumer
            # can use several files and output fragments from the same operation.
            # One focused parent revision must cover their union, not whichever
            # resource happened to be visited last.
            links = {}
            from tooluseproxy.engine.lineage import matching_producers
            reads = {a["path"] for a in verdict["accesses"] if a["mode"] == "read"}
            origins = matching_producers(conn, workspace, producer["event_id"])
            if historical is not None:
                # Immutable payload generations were observed before execution;
                # they must retain their writers when the Post is analyzed.
                origins = list(dict.fromkeys([*origins, *matching_producers(
                    conn, workspace, historical['event_id'])]))
            demands = {}
            for origin_event, origin_session, path, version in origins:
                if path not in reads:
                    continue
                demand = dict(path=path, version=version)
                if path in context_projections:
                    demand['projections'] = context_projections[path]
                demands.setdefault((origin_event, origin_session), []).append(demand)
            semantic_edges = {edge['node_id']: edge for edge in verdict['dependencies']}
            resource_links = []
            skipped = False
            deferred = False
            resource_deferred = set()
            for (origin_event, origin_session), requested in sorted(demands.items()):
                if positive:
                    skipped = True
                    break
                requested = sorted(requested, key=lambda r: (r['path'], r['version']))
                origin_index = calls.position(event=origin_event)
                if origin_index is not None and origin_index >= index:
                    origin_index = None
                if origin_session == session and origin_index is not None:
                    parent_node = calls[origin_index]['node_id']
                    edge = semantic_edges.get(parent_node)
                    # A resource's bytes are not the writer's tool response.
                    # Null output selection adds no response demand when a
                    # witnessed resource identifies the consumed value. Any
                    # additional consumed response must be explicitly selected.
                    scope = requested
                    try:
                        parent_revision = assess(origin_index, edge.get('selection') if edge else None,
                                                 depth+1, scope)[0]
                    except PendingReview:
                        deferred = True
                        resource_deferred.add(parent_node)
                        continue
                    if edge is not None:
                        links[parent_node] = parent_revision
                elif origin_session != session:
                    parent_result = analyze_properties(
                        db_path, workspace, origin_session, origin_event,
                        sources, judge, model=model, sources_refresh=sources_refresh,
                        _visiting=visiting, _resource_scope=requested,
                    )
                    parent_node, parent_revision = parent_result['node_id'], parent_result['revision']
                    tree_cacheable[parent_revision] = parent_result['cacheable']
                    positive_paths[parent_revision] = parent_result['positive_path']
                else:
                    raise GraphUnavailable('resource_producer_missing')
                resource_links.append((parent_node, parent_revision))
                if positive_paths.get(parent_revision):
                    positive = positive_paths[parent_revision] + [producer['node_id']]
            for edge in verdict['dependencies']:
                if edge['node_id'] in links or edge['node_id'] in resource_deferred:
                    continue
                if positive:
                    skipped = True
                    break
                parent_index = by_id[edge['node_id']]
                if parent_index >= index:
                    raise GraphUnavailable('future_output_dependency')
                try:
                    links[edge['node_id']] = assess(parent_index, edge.get('selection'), depth+1)[0]
                except PendingReview:
                    deferred = True
                    continue
                if positive_paths.get(links[edge['node_id']]):
                    positive = positive_paths[links[edge['node_id']]] + [producer['node_id']]
            if deferred and not positive:
                raise PendingReview()
            if deferred:
                skipped = True
            if skipped:
                # Preserve the full direct review separately. Missing graph edges
                # are unresolved, never negative evidence for a future allow.
                verdict = dict(verdict, complete=False,
                               reason='positive certificate; remaining ancestry not expanded',
                               dependencies=[e for e in verdict['dependencies'] if e['node_id'] in links])
            revision = digest([request, verdict, links, resource_links])
            existing = conn.execute("SELECT model,prompt,verdict FROM graph_revisions WHERE revision=?",
                                    (revision,)).fetchone()
            if existing and (existing[0] != model or existing[1] != PROMPT_VERSION
                             or json.loads(existing[2]) != verdict):
                # Preserve the old record for audit; a repaired assessment must
                # not point back to a migrated/corrected revision with other data.
                revision = digest(['reassessed-revision', revision, list(existing)])
            old_head = conn.execute("SELECT revision FROM graph_heads WHERE workspace=? AND session=? AND node=?", (workspace, session, producer["node_id"])).fetchone()
            with conn:
                persist(conn, workspace, session, producer, revision, model, verdict, links)
                for parent_node, parent_revision in resource_links:
                    conn.execute('INSERT OR IGNORE INTO graph_edges VALUES (?,?,?,?)',
                                 (revision, parent_node, producer['node_id'], 'witnessed resource generation'))
                    conn.execute('INSERT OR IGNORE INTO graph_revision_links VALUES (?,?,?)',
                                 (revision, parent_node, parent_revision))
                if selection is not None:
                    conn.execute("INSERT OR IGNORE INTO graph_output_selections VALUES (?,?,?,?)", (revision, producer["node_id"], json.dumps(selection), digest(producer["output"])))
                if resources is not None:
                    conn.execute('INSERT OR IGNORE INTO graph_resource_selections VALUES (?,?,?)',
                                 (revision, producer['node_id'], json.dumps(resources)))
                if selection is not None or resources is not None:
                    # Keep scoped reviews out of the whole-operation head/cache.
                    if old_head:
                        conn.execute("UPDATE graph_heads SET revision=? WHERE workspace=? AND session=? AND node=?", (old_head[0], workspace, session, producer["node_id"]))
                    else:
                        conn.execute("DELETE FROM graph_heads WHERE workspace=? AND session=? AND node=?", (workspace, session, producer["node_id"]))
                if verdict["complete"]:
                    conn.execute("INSERT OR REPLACE INTO graph_completed_reviews VALUES (?,?)", (request, revision))
                parents = list(links.values()) + [r for _, r in resource_links]
                cacheable = (verdict['complete'] and not verdict.get('evidence_receipts')
                             and all(tree_cacheable.get(r, False) for r in parents))
                tree_cacheable[revision] = cacheable
                if cacheable:
                    cutoff = conn.execute("SELECT sequence_no FROM events WHERE event_id=?",
                                          (producer['event_id'],)).fetchone()[0]
                    conn.execute("INSERT OR REPLACE INTO analysis_trees VALUES (?,?,?,?,?,?,?,?)",
                                 (request, workspace, cutoff, analysis_token, analysis_boundary,
                                  producer['node_id'], revision, json.dumps(verdict)))
            positive_paths[revision] = positive
            assessed[key] = (revision, verdict)
            return revision, verdict

        while True:
            pending_reviews.clear()
            try:
                current_revision, current_verdict = assess(index, resources=_resource_scope)
                break
            except PendingReview:
                # Expand newer consumers first. All paths to an older producer
                # are then visible before its separate scopes are sent together.
                newest = max(item[0] for item in pending_reviews.values())
                group = [(key, records) for key, (position, records) in pending_reviews.items()
                         if position == newest][:8]
                batch_method = 'review_scopes'
                if len(group) == 1 and frontier_batching:
                    # Batch already discovered targets, never speculate on unseen
                    # ancestors. Each question keeps its own history cutoff.
                    group = [(key, records) for key, (_, records) in sorted(
                        pending_reviews.items(), key=lambda item: item[1][0], reverse=True)][:4]
                    batch_method = 'review_frontier'
                if len(group) == 1:
                    key, records = group[0]
                    from tooluseproxy.engine.review import review
                    staged_reviews[key] = review(db_path, key, records, judge,
                        lambda value, allowed: validate_observed_dependencies(value, allowed, observations),
                        evidence_context=evidence_context)
                else:
                    from tooluseproxy.engine.codex import JudgeProviderError, PartialReviewError
                    try:
                        values = getattr(judge, batch_method)([records for _, records in group])
                        if not isinstance(values, list) or len(values) != len(group):
                            raise GraphUnavailable('invalid_scope_batch_results')
                        checked = []
                        for (_, records), value in zip(group, values):
                            allowed = {n['node_id'] for n in records['previous_calls'] if n['completed']}
                            try:
                                checked.append(validate_observed_dependencies(value, allowed, observations))
                            except GraphUnavailable:
                                # A bad selector belongs to this independent
                                # answer; it must not discard valid peers.
                                checked.append(None)
                    except PartialReviewError as error:
                        checked = [None] * len(group)
                        # Each entry was its own complete evidence request, not a
                        # partition of one inference. Validate before saving; a
                        # missing/invalid sibling never becomes an independent leaf.
                        with conn:
                            for position, value in error.completed.items():
                                if type(position) is not int or not 0 <= position < len(group):
                                    continue
                                key, records = group[position]
                                allowed = {n['node_id'] for n in records['previous_calls'] if n['completed']}
                                try:
                                    checked_value = validate_observed_dependencies(value, allowed, observations)
                                except (GraphUnavailable, ValueError, KeyError, TypeError):
                                    continue
                                if checked_value['complete'] and not checked_value.get('evidence_requests'):
                                    checked[position] = checked_value
                                    conn.execute('INSERT OR REPLACE INTO graph_direct_reviews VALUES (?,?)',
                                                 (key, json.dumps(checked_value)))
                        cause = error.cause
                        if not (isinstance(cause, GraphUnavailable) or
                                isinstance(cause, JudgeProviderError) and cause.code in (
                                    'scope_batch_results_mismatch', 'semantic_provider_invalid_shape',
                                    'semantic_provider_invalid_json', 'semantic_unexpected_evidence_request')):
                            raise cause
                        # Keep the existing per-scope shape repair path for the
                        # failed peers; valid checkpoints need no second review.
                    except (GraphUnavailable, JudgeProviderError) as error:
                        if isinstance(error, JudgeProviderError) and error.code not in (
                                'scope_batch_results_mismatch', 'semantic_provider_invalid_shape',
                                'semantic_provider_invalid_json', 'semantic_unexpected_evidence_request'):
                            raise  # Provider/auth failures are never independence.
                        checked = [None] * len(group)
                    # These are independent, validated evidence questions. Save
                    # completed peers before a repair can fail or yield; never
                    # turn a missing sibling into a completed graph.
                    with conn:
                        for (key, _), value in zip(group, checked):
                            if value is not None and value['complete'] and not value.get('evidence_requests'):
                                conn.execute('INSERT OR REPLACE INTO graph_direct_reviews VALUES (?,?)',
                                             (key, json.dumps(value)))
                    for position, ((key, records), value) in enumerate(zip(group, checked)):
                        if value is None or not value['complete'] or value.get('evidence_requests'):
                            # Repair only unresolved scopes using the established
                            # individual path. No missing result becomes a leaf.
                            from tooluseproxy.engine.review import review
                            checked[position] = review(db_path, key, records, judge,
                                lambda result, allowed: validate_observed_dependencies(result, allowed, observations),
                                evidence_context=evidence_context)
                    # Only validated, complete answers become reusable evidence.
                    with conn:
                        for (key, _), value in zip(group, checked):
                            if value['complete']:
                                conn.execute('INSERT OR REPLACE INTO graph_direct_reviews VALUES (?,?)',
                                             (key, json.dumps(value)))
                    staged_reviews.update((key, value) for (key, _), value in zip(group, checked))
        current_node = calls[index]['node_id']
        return current_node, current_revision, current_verdict, tree_cacheable.get(current_revision, False)


class AnalysisChanged(Exception):
    def __init__(self, sources):
        self.sources = sources


def analyze_properties(db_path, workspace, session, event_id, sources, judge, **kwargs):
    """Restart changed snapshots without converting an unfinished review to a decision."""
    while True:
        try:
            return _analyze_properties(db_path, workspace, session, event_id, sources, judge, **kwargs)
        except AnalysisChanged as changed:
            sources = changed.sources


def _analyze_properties(
    db_path,
    workspace,
    session,
    event_id,
    sources,
    judge,
    *,
    model="codex_default",
    sources_refresh=None,
    current_evidence=None,
    require_external=False,
    _visiting=None,
    _resource_scope=None,
):
    with sqlite3.connect(db_path, timeout=5) as conn:
        schema(conn)
        if _resource_scope is None:
            conn.execute(
                "INSERT OR REPLACE INTO graph_progress VALUES (?,?,?,?)",
                (workspace, session, event_id, "analyzing"),
            )

    visiting = set() if _visiting is None else _visiting
    if event_id in visiting or len(visiting) >= 64:
        raise GraphUnavailable("resource_lineage_expansion_budget")
    visiting.add(event_id)
    policy_at_start = digest(sorted(sources, key=lambda source: source['node_id']))
    with sqlite3.connect(db_path, timeout=5) as conn:
        projection.schema(conn)
        start_token = projection.token(conn)
        start_boundary = projection.boundary(conn, workspace)
        cutoff = conn.execute("SELECT sequence_no FROM events WHERE event_id=?", (event_id,)).fetchone()
        if not cutoff:
            raise GraphUnavailable("event_missing")
        cutoff = cutoff[0]
        tree_request = digest(['event-tree-v1', ANALYSIS_VERSION, projection.VERSION, REVIEW_VERSION,
                               workspace, session, event_id, PROMPT_VERSION,
                               model, current_evidence, _resource_scope])
        cached = projection.cached_tree(conn, tree_request, workspace)
    if cached is not None:
        current_node, current_revision, current_verdict = cached
        cacheable = True
        if _resource_scope is None:
            with sqlite3.connect(db_path, timeout=5) as conn:
                conn.execute("INSERT OR REPLACE INTO graph_heads VALUES (?,?,?,?)",
                             (workspace, session, current_node, current_revision))
    else:
        current_node, current_revision, current_verdict, cacheable = build_properties(
            db_path, workspace, session, event_id, sources, judge, model=model,
            sources_refresh=sources_refresh, current_evidence=current_evidence,
            visiting=visiting, _resource_scope=_resource_scope)
    with sqlite3.connect(db_path, timeout=5) as conn:
        if (projection.changed(conn, workspace, start_token, cutoff)
                or projection.boundary(conn, workspace) != start_boundary):
            visiting.remove(event_id)
            raise AnalysisChanged(sources)
        if cacheable:
            conn.execute("INSERT OR REPLACE INTO analysis_trees VALUES (?,?,?,?,?,?,?,?)",
                         (tree_request, workspace, cutoff, start_token, projection.boundary(conn, workspace),
                          current_node, current_revision, json.dumps(current_verdict)))
    if current_verdict is None:
        raise GraphUnavailable("current_node_missing")
    if _resource_scope is not None:
        visiting.remove(event_id)
        with sqlite3.connect(db_path, timeout=5) as conn:
            positive = pinned_path(conn, current_node, current_revision, sources)
        return dict(node_id=current_node, revision=current_revision, cacheable=cacheable,
                    positive_path=positive)
    with sqlite3.connect(db_path, timeout=5) as conn:
        # Serialize the final policy snapshot and recorded decision with source
        # registration. Model requests finished before this short transaction.
        conn.execute("BEGIN IMMEDIATE")
        if sources_refresh is not None:
            sources = sources_refresh()
        policy_revision = digest(sorted(sources, key=lambda source: source["node_id"]))
        if (projection.changed(conn, workspace, start_token, cutoff)
                or projection.boundary(conn, workspace) != start_boundary
                or policy_revision != policy_at_start and not cacheable):
            conn.rollback()
            visiting.remove(event_id)
            raise AnalysisChanged(sources)
        conn.execute(
            "INSERT OR IGNORE INTO graph_policies VALUES (?,?)",
            (policy_revision, json.dumps(sources)),
        )
        traversal_started = time.monotonic_ns()
        complete = cacheable or dependency_complete(conn, workspace, current_node)
        roots, policy_complete = bindings(conn, workspace, session, sources)
        path = reach(conn, workspace, session, current_node, roots)
        if current_verdict["externality"] == "local" and not require_external:
            # Local work need not wait for provenance that only a later send needs.
            # Keep incomplete verdicts intact so that send still requires inspection.
            action, reason = "allow", "local_operation"
        elif path:
            action, reason = "block", "protected_source_reachable"
        elif not complete or not policy_complete:
            action, reason = "unavailable", "property_graph_incomplete"
        else:
            action, reason = "allow", "no_protected_path_observed"
        result = {"node_id": current_node, "action": action, "reason": reason, "path": path,
                  "graph_complete": complete, "decision_complete": action != 'unavailable',
                  "certificate": ('local_operation' if reason == 'local_operation' else
                                  'protected_path' if path else
                                  'closed_ancestry' if complete and policy_complete else None),
                  "reachability_ms": (time.monotonic_ns() - traversal_started) / 1_000_000}
        if action == "unavailable":
            # An unfinished model review is not a terminal policy decision.
            # Retry it in this Hook, retaining completed parts. Missing policy
            # bindings require real evidence and cannot be repaired by guessing.
            result["retryable"] = policy_complete
            if policy_complete:
                result["retry_scope"] = "review"
            result["evidence_needs"] = unresolved_dependencies(conn, workspace, current_node)
        conn.execute(
            "INSERT OR REPLACE INTO graph_progress VALUES (?,?,?,?)",
            (
                workspace,
                session,
                event_id,
                "positive_certificate" if path else
                "incomplete" if not complete or not policy_complete else "ready",
            ),
        )
        conn.execute(
            "INSERT OR IGNORE INTO graph_policy_checks(event,policy_revision,graph_revision,result) VALUES (?,?,?,?)",
            (
                event_id,
                digest(sorted(sources, key=lambda s: s["node_id"])),
                current_revision,
                json.dumps(result),
            ),
        )
    visiting.remove(event_id)
    return result


def dependency_complete(conn, workspace, node):
    head = conn.execute(
        "SELECT revision FROM graph_heads WHERE workspace=? AND node=?", (workspace, node)
    ).fetchone()
    if not head:
        return False
    pending, seen = [(node, head[0])], set()
    while pending:
        current = pending.pop()
        if current in seen:
            continue
        seen.add(current)
        if len(seen) > 200_000:
            raise GraphUnavailable("graph_completeness_budget")
        row = conn.execute(
            "SELECT verdict FROM graph_revisions WHERE workspace=? AND node=? AND revision=?",
            (workspace, *current),
        ).fetchone()
        if not row or not json.loads(row[0])["complete"]:
            return False
        pending.extend(revision_parents(conn, workspace, *current))
    return True


def unresolved_dependencies(conn, workspace, node):
    head = conn.execute("SELECT revision FROM graph_heads WHERE workspace=? AND node=?", (workspace, node)).fetchone()
    pending = [(node, head[0])] if head else []
    seen, needs = set(), []
    while pending:
        current = pending.pop()
        if current in seen:
            continue
        if len(seen) >= 200_000:
            raise GraphUnavailable("graph_traversal_budget_exceeded")
        seen.add(current)
        row = conn.execute("SELECT verdict FROM graph_revisions WHERE workspace=? AND node=? AND revision=?", (workspace, *current)).fetchone()
        if row:
            value = json.loads(row[0])
            if not value["complete"]:
                needs.append(dict(node_id=current[0], revision=current[1], reason=value["reason"],
                                  requests=value.get("evidence_requests", []), receipts=value.get("evidence_receipts", [])))
        pending.extend(revision_parents(conn, workspace, *current))
    return needs
