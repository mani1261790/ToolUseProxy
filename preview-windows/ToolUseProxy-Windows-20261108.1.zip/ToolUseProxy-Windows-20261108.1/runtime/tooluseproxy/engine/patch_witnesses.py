"""Bind exact patch replay to observed generations without storing file bodies."""
from dataclasses import asdict
import json

from tooluseproxy.engine.evidence import ContentVersion, Resource
from tooluseproxy.engine.patch_ranges import replay_section, update_sections
from tooluseproxy.engine.resource_contracts import patch_resources
from tooluseproxy.engine.transmission_evidence import FIELDS, identity


def schema(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS flow_patch_range_maps (
        scope TEXT NOT NULL,event TEXT NOT NULL,identity_hash TEXT NOT NULL,
        source_path TEXT NOT NULL,source_version TEXT NOT NULL,
        target_path TEXT NOT NULL,target_version TEXT NOT NULL,ranges_json TEXT NOT NULL,
        PRIMARY KEY(scope,event,source_path))''')


def save(conn, event, before_version, content, resolver):
    raw = event.raw_payload
    if raw.get('tool_name') != 'apply_patch':
        return
    inputs = raw.get('tool_input')
    contract = patch_resources('apply_patch', inputs)
    if not contract or contract['additions_only']:
        return
    row = conn.execute('SELECT ' + ','.join(FIELDS) + ',payload_json FROM events WHERE event_id=?',
                       (event.event_id,)).fetchone()
    if row is None or row[4] != row[5]:
        return
    from tooluseproxy.engine.requirements import resource_identity
    paths = {r['path']: resource_identity(r['path'], row[4]) for r in contract['resources']}
    # Distinct spellings of the same resource can create order-dependent writes.
    if len(set(paths.values())) != len(paths) or any(p.startswith('/') for p in paths.values()):
        return
    patch = inputs if isinstance(inputs, str) else inputs.get('patch', inputs.get('command'))
    sections = [s for s in update_sections(patch.encode('utf-8'))
                if paths[s['source']] == before_version.resource.locator]
    if len(sections) != 1:
        return
    section = sections[0]
    result = replay_section(content, section)
    if result is None or len(result.ranges) > 4096:
        return
    target_path = paths[section['target']]
    target = ContentVersion(Resource(event.workspace_id, 'file', target_path),
                            resolver.token(result.content), event.event_id)
    conn.execute('INSERT OR REPLACE INTO flow_patch_range_maps VALUES (?,?,?,?,?,?,?,?)', (
        event.workspace_id, event.event_id, identity(row), before_version.resource.locator,
        before_version.identity, target_path, target.identity,
        json.dumps([asdict(r) for r in result.ranges])))


def attach(conn, workspace, node):
    node.pop('patch_range_witness', None)
    node.pop('patch_range_witnesses', None)
    if not node.get('completed') or node.get('tool_name') != 'apply_patch':
        return
    post = conn.execute('SELECT ' + ','.join(FIELDS) + ',payload_json,sequence_no FROM events '
                        "WHERE event_id=? AND workspace_id=? AND phase='post_tool_use'",
                        (node['event_id'], workspace)).fetchone()
    if post is None:
        return
    boundary = 0
    if conn.execute("SELECT 1 FROM sqlite_master WHERE name='recording_boundaries'").fetchone():
        row = conn.execute('SELECT after_sequence FROM recording_boundaries WHERE workspace_id=?',
                           (workspace,)).fetchone()
        boundary = row[0] if row else 0
    rows = conn.execute('''SELECT r.event,r.identity_hash,r.source_path,r.source_version,
        r.target_path,r.target_version,r.ranges_json FROM flow_patch_range_maps r
        JOIN events e ON e.event_id=r.event AND e.workspace_id=r.scope
        WHERE r.scope=? AND e.session_id=? AND e.tool_use_id=?
        AND e.phase='pre_tool_use' AND e.sequence_no>? AND e.sequence_no<?''',
        (workspace, post[1], post[2], boundary, post[-1])).fetchall()
    if not rows or len({r[0] for r in rows}) != 1:
        return
    pre_event = rows[0][0]
    pre = conn.execute('SELECT ' + ','.join(FIELDS) + ',payload_json FROM events WHERE event_id=?',
                       (pre_event,)).fetchone()
    if any(r[1] != identity(pre) or r[1] != identity(post[:-1]) for r in rows):
        return
    witnesses = []
    for _, _, source, old, target, new, ranges in rows:
        matched = True
        for event, path, mode, version, status in (
            (pre_event, source, 'read', old, 'planned'),
            (node['event_id'], target, 'write', new, 'observed')):
            observed = conn.execute('''SELECT version,status FROM flow_file_observations
                WHERE scope=? AND event=? AND path=? AND mode=? ORDER BY observation DESC LIMIT 1''',
                (workspace, event, path, mode)).fetchone()
            if observed != (version, status):
                matched = False
                break
        if matched:
            witnesses.append(dict(
                basis='exact_replay_matches_observed_generations_not_semantic_independence',
                source=dict(path=source, version=old, event=pre_event),
                target=dict(path=target, version=new, event=node['event_id']),
                ranges=json.loads(ranges)))
    if witnesses:
        node['patch_range_witnesses'] = witnesses
