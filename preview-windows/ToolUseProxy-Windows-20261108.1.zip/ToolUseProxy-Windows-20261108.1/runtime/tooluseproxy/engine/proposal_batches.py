"""Bound non-authoritative edge proposals, never the final joint assessment."""
import json

from tooluseproxy.engine.codex import JudgeProviderError

PROPOSAL_BYTES = 384_000
VERSION = 'partial-edge-proposals-v1'


def edge_proposal_batches(records, questions, *, model, limit=None):
    """Keep every historical record, but give each proposal only its local part.

    The caller MUST resolve all proposals against the original, intact records.
    In particular, an empty set of proposed edges is not independence evidence.
    No input record or question is mutated; no partial result is returned on an
    oversized indivisible record/current target.
    """
    limit = PROPOSAL_BYTES if limit is None else limit

    def wire_size(state, batch):
        return len(json.dumps(dict(model=model, state=state, questions=batch),
                              ensure_ascii=False).encode('utf-8'))

    if wire_size(records, questions) <= limit:
        return [(records, questions)]
    by_node = {}
    for key, question in questions.items():
        node = question['instructions']['candidate_node']
        by_node.setdefault(node, {})[key] = question
    context = dict(format=VERSION, part=999999, parts=999999,
        authoritative=False,
        interpretation='This is only a partial-history proposal. Records in other '
        'parts may jointly contribute. A negative answer is not a global independence '
        'verdict. A separate resolver must inspect the entire original history.')
    base = dict(records, previous_calls=[], proposal_context=context)
    groups, nodes, batch = [], [], {}
    for node in records['previous_calls']:
        additions = by_node.get(node['node_id'], {})
        candidate_nodes = nodes + [node]
        candidate_batch = dict(batch, **additions)
        if wire_size(dict(base, previous_calls=candidate_nodes), candidate_batch) > limit:
            if not nodes:
                raise JudgeProviderError('jev_proposal_context_too_large')
            groups.append((nodes, batch))
            nodes, batch = [node], dict(additions)
            if wire_size(dict(base, previous_calls=nodes), batch) > limit:
                raise JudgeProviderError('jev_proposal_context_too_large')
        else:
            nodes, batch = candidate_nodes, candidate_batch
    if nodes:
        groups.append((nodes, batch))
    if not groups or {k for _, qs in groups for k in qs} != set(questions):
        raise JudgeProviderError('jev_proposal_context_too_large')
    return [(dict(base, previous_calls=nodes,
                  proposal_context=dict(context, part=i, parts=len(groups))), batch)
            for i, (nodes, batch) in enumerate(groups)]
