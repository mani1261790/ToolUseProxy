"""Cross-process request identity and results in the existing event database."""
from contextlib import closing
import sqlite3


class RequestStore:
    def __init__(self, db, event, scope):
        self.db, self.event, self.scope = db, event, scope
        with closing(self._connect()) as conn, conn:
            conn.execute('''CREATE TABLE IF NOT EXISTS flow_local_requests (
                event TEXT NOT NULL, scope TEXT NOT NULL, request TEXT NOT NULL,
                handle TEXT NOT NULL, response BLOB,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(event,scope,request))''')
            conn.execute('''CREATE TABLE IF NOT EXISTS flow_local_request_epochs (
                event TEXT NOT NULL, scope TEXT NOT NULL, request TEXT NOT NULL,
                handle TEXT NOT NULL, instance TEXT NOT NULL,
                PRIMARY KEY(event,scope,request,handle))''')

    def _connect(self):
        return sqlite3.connect(self.db, timeout=1)

    def get(self, request):
        with closing(self._connect()) as conn:
            return conn.execute('''SELECT handle,response FROM flow_local_requests
                WHERE event=? AND scope=? AND request=?''',
                (self.event, self.scope, request)).fetchone()

    def accept(self, request, handle, instance=''):
        # Concurrent reservations may leave an empty remote slot, but only the
        # winning persisted handle may receive evidence. No network under lock.
        with closing(self._connect()) as conn, conn:
            conn.execute('''INSERT OR IGNORE INTO flow_local_requests
                (event,scope,request,handle) VALUES (?,?,?,?)''',
                (self.event, self.scope, request, handle))
            conn.execute('''INSERT OR IGNORE INTO flow_local_request_epochs
                VALUES (?,?,?,?,?)''', (self.event, self.scope, request, handle, instance))
            return conn.execute('''SELECT handle,response FROM flow_local_requests
                WHERE event=? AND scope=? AND request=?''',
                (self.event, self.scope, request)).fetchone()

    def instance(self, request, handle):
        with closing(self._connect()) as conn:
            row = conn.execute('''SELECT instance FROM flow_local_request_epochs
                WHERE event=? AND scope=? AND request=? AND handle=?''',
                (self.event, self.scope, request, handle)).fetchone()
            return row[0] if row else ''

    def recover(self, request, old_handle, handle, instance):
        with closing(self._connect()) as conn, conn:
            conn.execute('BEGIN IMMEDIATE')
            old = conn.execute('''SELECT instance FROM flow_local_request_epochs
                WHERE event=? AND scope=? AND request=? AND handle=?''',
                (self.event, self.scope, request, old_handle)).fetchone()
            if not old or not old[0] or not instance or old[0] == instance:
                raise ValueError('runtime_change_unproven')
            changed = conn.execute('''UPDATE flow_local_requests SET handle=?
                WHERE event=? AND scope=? AND request=? AND handle=? AND response IS NULL''',
                (handle, self.event, self.scope, request, old_handle)).rowcount
            if changed:
                conn.execute('''INSERT INTO flow_local_request_epochs VALUES (?,?,?,?,?)''',
                             (self.event, self.scope, request, handle, instance))
            return conn.execute('''SELECT handle,response FROM flow_local_requests
                WHERE event=? AND scope=? AND request=?''',
                (self.event, self.scope, request)).fetchone()

    def complete(self, request, handle, response):
        if not isinstance(response, bytes) or len(response) > 1_000_000:
            raise ValueError('invalid_local_response')
        with closing(self._connect()) as conn, conn:
            row = conn.execute('''SELECT handle,response FROM flow_local_requests
                WHERE event=? AND scope=? AND request=?''',
                (self.event, self.scope, request)).fetchone()
            if row is None or row[0] != handle or (row[1] is not None and row[1] != response):
                raise ValueError('local_response_conflict')
            conn.execute('''UPDATE flow_local_requests SET response=?
                WHERE event=? AND scope=? AND request=?''',
                (response, self.event, self.scope, request))
