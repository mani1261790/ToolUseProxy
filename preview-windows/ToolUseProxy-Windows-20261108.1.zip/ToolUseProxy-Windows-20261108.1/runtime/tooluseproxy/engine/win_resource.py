"""Read local regular files via a checked Windows handle, never follow device aliases."""
import ctypes, msvcrt, os, stat
from ctypes import wintypes as W
from contextlib import contextmanager
from pathlib import Path, PureWindowsPath

k=ctypes.WinDLL('kernel32',use_last_error=True)
create=k.CreateFileW
create.argtypes=[W.LPCWSTR,W.DWORD,W.DWORD,W.LPVOID,W.DWORD,W.DWORD,W.HANDLE]
create.restype=W.HANDLE
final=k.GetFinalPathNameByHandleW
final.argtypes=[W.HANDLE,W.LPWSTR,W.DWORD,W.DWORD]
final.restype=W.DWORD
close=k.CloseHandle
close.argtypes=[W.HANDLE]
def check_path(p):
    if len(p.anchor)!=3 or not p.drive.endswith(':'):
        raise OSError('local_drive_required')
    for node in (*reversed(p.parents),p):
        if node.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise OSError('reparse_point_not_supported')
@contextmanager
def open_file(root,parts):
    if any(any(c in s for c in '\\/:*?"<>|') or s.endswith((' ','.')) or
           PureWindowsPath(s).is_reserved() or s.casefold()=='protected_sources.json' for s in parts):
        raise OSError('invalid_windows_path')
    p=Path(root).joinpath(*parts)
    check_path(p)
    h=create(str(p),0x80000000,1,None,3,0x00200000,None)
    if h==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
    fd=None
    try:
        buf=ctypes.create_unicode_buffer(32768)
        n=final(h,buf,len(buf),0)
        if not 0<n<len(buf) or buf.value.removeprefix('\\\\?\\')!=str(p):
            raise OSError('resource_path_mismatch')
        fd=msvcrt.open_osfhandle(h,os.O_RDONLY|os.O_BINARY)
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise OSError('regular_file_required')
        yield fd,None,p
    finally:
        if fd is None:close(h)
        else:os.close(fd)
