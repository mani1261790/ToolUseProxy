"""Opt-in, project-local human review after a completed blocking decision.

Uses the existing transmission inspection to compare resources after approval.
No transfer locks, content copies, or command rewrites. Requires Codex's standard sandbox protection of .codex.
"""
from dataclasses import asdict
import json
from pathlib import Path
import secrets
import sqlite3
import time

from tooluseproxy.engine.graph import digest
from tooluseproxy.engine.review_receipts import target_key


def control_path(root):
    root = Path(root).resolve(strict=True)
    current = root
    for name in ('.codex', 'tooluseproxy-review', 'control.db'):
        current = current / name
        if current.is_symlink():
            raise ValueError('approval_control_symlink')
    return current


def prepare(root):
    path = control_path(root)
    path.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    path.parent.chmod(0o700)
    with sqlite3.connect(path) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS reviews (
            key TEXT PRIMARY KEY, nonce TEXT NOT NULL, state TEXT NOT NULL,
            expires REAL NOT NULL, context TEXT NOT NULL, policy TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS audit (
            key TEXT, nonce TEXT, outcome TEXT, recorded REAL)''')
    path.chmod(0o600)
    ignore = path.parent / '.gitignore'
    if ignore.is_symlink():
        raise ValueError('approval_ignore_symlink')
    ignore.write_text('*\n')
    return path


def connect(root):
    # Never auto-create an empty DB in the runtime path.
    path = control_path(root)
    if not path.is_file():
        raise ValueError('approval_not_installed')
    return sqlite3.connect(path.as_uri() + '?mode=rw', uri=True, timeout=1)


def inspection_review(event, resolver, resolution):
    """Reuse inspection for all tool kinds: files, Git refs, and inline values."""
    original = target_key(event.raw_payload)
    def recheck():
        if target_key(event.raw_payload) != original or not resolver.unchanged(resolution):
            return False
        # Compare bytes too, rather than relying only on file timestamps.
        checked = set()
        for part in resolution.parts:
            if part.version.resource.kind != 'file':
                continue
            path = part.version.resource.locator
            if path in checked:
                continue
            content, _ = resolver.read_file(path, {'bytes': 8_388_608})
            if resolver.token(content) != part.version.token:
                return False
            checked.add(path)
        return True
    resources = []
    for part in resolution.parts:
        observation = part.observation
        resources.append(dict(kind=part.version.resource.kind,
            path=observation.get('path', observation.get('repository')),
            revision=observation.get('revision'), head=observation.get('head'),
            paths=observation.get('paths', []), object_kind=observation.get('object_kind'),
            pointer=observation.get('pointer'),
            bytes=part.extent.get('length'), digest=part.version.token))
    submission = dict(operation=event.raw_payload.get('tool_input'),
        tool=event.raw_payload.get('tool_name'), resources=resources,
        bytes=sum(len(p.content) for p in resolution.parts))
    return dict(submission=submission, recheck=recheck)


def policy_fingerprint(store, event):
    from tooluseproxy.engine.runtime import configuration
    sources = [asdict(s) for s in store.list_protected_sources_for_workspace(event.workspace_id)]
    return digest([sorted(sources, key=lambda s: s['source_id']),
                   configuration(store.db_path, event.workspace_id)])


def request(root, payload, context, policy, *, lifetime=90):
    if not 0 < lifetime <= 90:
        raise ValueError('invalid_approval_lifetime')
    key = target_key(payload)
    nonce = secrets.token_hex(32)
    with connect(root) as db:
        # Same ToolCall is never reopened: stale UI replies cannot authorize a retry.
        db.execute('INSERT INTO reviews VALUES (?,?,?,?,?,?)',
                   (key, nonce, 'waiting', time.time()+lifetime,
                    json.dumps(context, ensure_ascii=False), policy))
    return key, nonce


def load(root, payload):
    with connect(root) as db:
        row = db.execute('SELECT nonce,state,expires,context FROM reviews WHERE key=?',
                         (target_key(payload),)).fetchone()
    if row is None:
        return None
    return dict(nonce=row[0], state=row[1], expires=row[2], context=json.loads(row[3]))


def answer(root, payload, nonce, allowed):
    with connect(root) as db:
        db.execute('UPDATE reviews SET state=? WHERE key=? AND nonce=? AND state=? AND expires>?',
                   ('accepted' if allowed is True else 'denied', target_key(payload), nonce,
                    'waiting', time.time()))


def wait(root, payload, nonce, policy, *, timeout=90):
    key = target_key(payload)
    deadline = time.monotonic()+timeout
    while True:
        with connect(root) as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT nonce,state,expires,policy FROM reviews WHERE key=?', (key,)).fetchone()
            if row is None or row[0] != nonce:
                return False
            expired = row[2] <= time.time() or time.monotonic() >= deadline
            if row[1] != 'waiting' or expired:
                allowed = row[1] == 'accepted' and not expired and row[3] == policy
                db.execute("UPDATE reviews SET state=?,context='{}' WHERE key=?", ('consumed', key))
                db.execute('INSERT INTO audit VALUES (?,?,?,?)',
                           (key, nonce, 'accepted' if allowed else 'denied_or_expired', time.time()))
                return allowed
        time.sleep(.05)


def decision_route(store, event, result):
    """Describe only the path in this verdict, using its pinned graph revisions."""
    path = result.get('path') or []
    if result['reason'] != 'protected_source_reachable' or not path:
        return []
    source_names = {'source:' + s.source_id: s.path
                    for s in store.list_protected_sources_for_workspace(event.workspace_id)}
    steps = [source_names.get(path[0], '保護対象（名前を特定できません）')]
    # The journal already contains the full path. Only signal omitted calls here.
    if len(path) > 2:
        steps.append('…')
    return steps + ['今回の送信操作']


def review_block(store, event, result, *, timeout=90, submission=None, recheck=None):
    """Fail closed. Existing graph/source policy remains unchanged."""
    if result.get('action') != 'block':
        return result
    if result.get('reason') not in ('protected_content_match', 'protected_source_reachable'):
        return result
    # User explicitly excluded unrestricted/automatically approved execution.
    if event.raw_payload.get('permission_mode') not in ('default', 'on-request'):
        return result
    if submission is None or not callable(recheck):
        return result
    try:
        if not recheck():
            return dict(result, reason="approval_target_changed_recheck_required")
        policy = policy_fingerprint(store, event)
        _, nonce = request(event.workspace_root, event.raw_payload,
                           dict(submission, reason=result['reason'], project=event.workspace_root,
                                route=decision_route(store, event, result)),
                           policy, lifetime=timeout)
        if not wait(event.workspace_root, event.raw_payload, nonce, policy, timeout=timeout):
            return result
        if policy_fingerprint(store, event) != policy or not recheck():
            return dict(result, reason="approval_target_changed_recheck_required")
        with sqlite3.connect(store.db_path, timeout=1) as db:
            db.execute('''CREATE TABLE IF NOT EXISTS human_review_outcomes (
                event TEXT PRIMARY KEY, nonce TEXT NOT NULL, target TEXT NOT NULL,
                policy TEXT NOT NULL, outcome TEXT NOT NULL)''')
            db.execute('INSERT INTO human_review_outcomes VALUES (?,?,?,?,?)',
                       (event.event_id, nonce, target_key(event.raw_payload), policy, 'accepted_once'))
        return dict(result, action='allow', reason='human_approved_once')
    except (ValueError, OSError, sqlite3.Error, TypeError, KeyError):
        return result


def notify_done(root, payload):
    """Wake the companion hook for operations which did not request a review."""
    try:
        with connect(root) as db:
            db.execute('INSERT OR IGNORE INTO reviews VALUES (?,?,?,?,?,?)',
                       (target_key(payload), secrets.token_hex(32), 'not_requested',
                        time.time()+30, '{}', ''))
    except (ValueError, OSError, sqlite3.Error, TypeError, KeyError):
        pass  # The authoritative command Hook retains its own decision.
