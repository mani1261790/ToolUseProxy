"""Bounded stdio MCP child recovery. Deployment is experimental.

A failed request is never replayed. Callers must retain an independent deny
Hook because an MCP error alone does not block a Codex ToolCall.
"""
import argparse
import json
import os
import queue
import subprocess
import sys
import threading
import time


def pump(stream, messages, origin):
    try:
        for line in iter(stream.readline, b''):
            if len(line) > 1_048_576:
                break
            messages.put((origin, json.loads(line)))
    except (ValueError, OSError):
        pass
    finally:
        messages.put((origin, None))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--max-restarts', type=int, default=2)
    ap.add_argument('command', nargs=argparse.REMAINDER)
    args = ap.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    if not command or not 0 <= args.max_restarts <= 3:
        return 2
    messages = queue.Queue()
    threading.Thread(target=pump, args=(sys.stdin.buffer, messages, 'client'), daemon=True).start()
    child = None
    generation = 0
    init = None
    init_result = None
    ready = False
    pending = {}
    child_requests = set()
    until = time.monotonic() + 10

    def send(value):
        print(json.dumps(value, ensure_ascii=False), flush=True)

    def child_send(value):
        child.stdin.write((json.dumps(value) + '\n').encode())
        child.stdin.flush()

    def error(request_id):
        send({'jsonrpc': '2.0', 'id': request_id,
              'error': {'code': -32000, 'message': 'Review service unavailable; request was not replayed.'}})

    def start():
        nonlocal child, ready, until
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=sys.stderr, env=os.environ.copy())
        threading.Thread(target=pump, args=(child.stdout, messages, generation), daemon=True).start()
        ready = False
        until = time.monotonic() + 10
        if init:
            child_send(init)

    def stop():
        if child and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=1)

    try:
        start()
        while True:
            try:
                origin, msg = messages.get(timeout=0.1)
            except queue.Empty:
                if ready or time.monotonic() < until:
                    continue
                origin, msg = generation, None
            if origin == 'client':
                if msg is None:
                    return 0
                method = msg.get('method')
                request_id = msg.get('id')
                if method == 'initialize':
                    if init is not None:
                        error(request_id)
                        continue
                    init = msg
                    pending[request_id] = method
                    child_send(msg)
                elif method and request_id is not None:
                    if not ready:
                        error(request_id)
                    else:
                        pending[request_id] = method
                        child_send(msg)
                elif method:
                    if ready:
                        child_send(msg)
                elif request_id in child_requests:
                    child_requests.remove(request_id)
                    if ready:
                        child_send(msg)
                # Late human responses from a dead child cannot authorize a new one.
            elif origin == generation:
                if msg is None:
                    for request_id in list(pending):
                        error(request_id)
                    pending.clear()
                    child_requests.clear()
                    stop()
                    if generation >= args.max_restarts:
                        return 1
                    generation += 1
                    start()
                    continue
                request_id = msg.get('id')
                if init and request_id == init['id'] and 'method' not in msg and not ready:
                    result = msg.get('result')
                    if result is None or (init_result is not None and result != init_result):
                        return 1
                    ready = True
                    if init_result is None:
                        init_result = result
                        pending.pop(request_id, None)
                        send(msg)
                    else:
                        child_send({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
                elif 'method' in msg and request_id is not None:
                    child_requests.add(request_id)
                    send(msg)
                elif request_id in pending:
                    pending.pop(request_id)
                    send(msg)
                elif 'method' in msg:
                    send(msg)
    except (OSError, BrokenPipeError):
        return 1
    finally:
        stop()


if __name__ == '__main__':
    raise SystemExit(main())
