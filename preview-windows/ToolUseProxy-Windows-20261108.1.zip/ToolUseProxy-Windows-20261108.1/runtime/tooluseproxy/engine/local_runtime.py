"""Explicit foreground supervisor for an already-installed local Kev runtime.

Never called by a Hook. No package installation or model downloads occur here.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import stat
import subprocess
import threading
import time
import urllib.parse

from tooluseproxy.engine.local_decisions import KevClient, local_key, validate_local_config


def supervise(command, *, env, cwd, stop, ready, report, output,
              startup_seconds=120, max_restarts=3, poll_seconds=0.2):
    """Keep one child handle; stop that child, never a PID from a stale file."""
    restarts = 0
    while not stop.is_set():
        child = None
        try:
            child = subprocess.Popen(command, env=env, cwd=cwd, stdin=subprocess.DEVNULL,
                                     stdout=output, stderr=subprocess.STDOUT)
            report('starting', child.pid, restarts)
            deadline = time.monotonic() + startup_seconds
            running = False
            while child.poll() is None and not stop.is_set():
                if not running:
                    try:
                        ready()
                        running = True
                        report('ready', child.pid, restarts)
                    except Exception:
                        if time.monotonic() >= deadline:
                            break
                stop.wait(poll_seconds)
            if stop.is_set():
                break
        finally:
            if child is not None and child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()
        if restarts >= max_restarts:
            report('failed', None, restarts)
            return 1
        restarts += 1
        report('restarting', None, restarts)
        stop.wait(min(2 ** (restarts - 1), 8))
    report('stopped', None, restarts)
    return 0


def run(config, python, directory):
    validate_local_config(config)
    python = Path(python).absolute()
    if not python.is_file() or not os.access(python, os.X_OK):
        raise ValueError('local_runtime_python_missing')
    # Validate key before taking a lock or starting any process.
    key = local_key(config['decision_key_file'])
    directory = Path(directory).expanduser()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    info = directory.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise ValueError('local_runtime_directory_permissions')
    endpoint = config['decision_endpoint'].rstrip('/')
    identity = hashlib.sha256(endpoint.encode()).hexdigest()[:24]
    lock_path = directory / (identity + '.lock')
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    with os.fdopen(fd, 'w') as lock:
        info = os.fstat(lock.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ValueError('local_runtime_lock_permissions')
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('local_runtime_already_supervised') from None
        port = urllib.parse.urlsplit(endpoint).port
        with socket.socket() as sock:
            try:
                sock.bind(('127.0.0.1', port))
            except OSError:
                raise ValueError('local_runtime_port_in_use') from None
        # Allow only runtime essentials; do not pass Codex/API credentials to Kev.
        env = {k: os.environ[k] for k in ('HOME', 'PATH', 'TMPDIR', 'HF_HOME', 'HF_HUB_CACHE') if k in os.environ}
        env.update(KEV_API_KEY=key, KEV_BACKEND='mlx', KEV_TRUNCATE_STATES='0',
                   HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
        # Only this packaged runtime directory, never an inherited PYTHONPATH.
        env['PYTHONPATH'] = str(Path(__file__).resolve().parents[2])
        command = [str(python), '-m', 'tooluseproxy.engine.local_server', '--run', config['decision_run'],
                   '--host', '127.0.0.1', '--port', str(port)]
        client = KevClient(config)
        stop = threading.Event()
        handlers = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM)}
        for sig in handlers:
            signal.signal(sig, lambda *_: stop.set())
        def report(state, pid, restarts):
            # Readiness is an observation, not proof that a later request will work.
            print(json.dumps(dict(state=state, pid=pid, restarts=restarts,
                                  run=config['decision_run'], endpoint=endpoint)), flush=True)
        try:
            # Child output can contain model evidence diagnostics. It is not
            # forwarded to the terminal or retained in an unbounded shared log.
            return supervise(command, env=env, cwd=directory, stop=stop,
                ready=lambda: client._verify(time.monotonic()+2), report=report,
                output=subprocess.DEVNULL)
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True, help='Local provider configuration JSON, not workspace policy')
    parser.add_argument('--python', required=True, help='Python executable in the separately prepared Kev environment')
    parser.add_argument('--state-dir', default='~/.cache/tooluseproxy/local-runtime')
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text())
    try:
        return run(config, args.python, args.state_dir)
    except (OSError, ValueError):
        # Do not echo config, key contents, or arbitrary exception messages.
        print(json.dumps({'state': 'failed', 'reason': 'local_runtime_start_failed'}), flush=True)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
