"""One-call review state machine. Not enabled in the production Hook.

The host must supply an elicitation response, never a tool argument. This
component does not authenticate a host, execute tools, or issue reusable grants.
"""

from __future__ import annotations

import hashlib
import json
import secrets
import time
from collections.abc import Callable


def fingerprint(target: dict) -> str:
    encoded = json.dumps(target, sort_keys=True, ensure_ascii=False, allow_nan=False)
    if len(encoded.encode()) > 64_000:
        raise ValueError("review_target_too_large")
    return hashlib.sha256(encoded.encode()).hexdigest()


class HumanReview:
    """Pending review; callers serialize access on their MCP event loop."""

    def __init__(self, target: dict, *, lifetime: float = 300,
                 clock: Callable[[], float] = time.monotonic):
        if not 0 < lifetime <= 900:
            raise ValueError("invalid_review_lifetime")
        self.digest = fingerprint(target)
        self.request_id = "review-" + secrets.token_hex(16)
        self.clock = clock
        self.deadline = clock() + lifetime
        self.state = "pending"

    def form(self, message: str) -> dict:
        return {
            "mode": "form",
            "message": message,
            "requestedSchema": {
                "type": "object",
                "properties": {"allow_once": {
                    "type": "boolean",
                    "title": "この送信を今回だけ許可する",
                    "default": False,
                }},
                "required": ["allow_once"],
            },
        }

    def resolve(self, response: dict, current_target: dict) -> bool:
        if self.state != "pending":
            return False
        # A reply is terminal, including malformed or mismatched replies.
        self.state = "denied"
        if self.clock() >= self.deadline:
            self.state = "expired"
            return False
        if response.get("id") != self.request_id or "error" in response:
            return False
        try:
            if fingerprint(current_target) != self.digest:
                self.state = "changed"
                return False
        except (ValueError, TypeError):
            return False
        result = response.get("result")
        if not isinstance(result, dict) or result.get("action") != "accept":
            return False
        content = result.get("content")
        if not isinstance(content, dict) or content.get("allow_once") is not True:
            return False
        self.state = "consumed"
        return True

    def cancel(self) -> None:
        if self.state == "pending":
            self.state = "cancelled"
