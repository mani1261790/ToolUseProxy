"""Optional authenticated loopback Kev client; no weights in plugin dependencies."""
from __future__ import annotations

import os
import base64
import hashlib
import re
import stat
import time
import urllib.error
import urllib.parse
import urllib.request

from tooluseproxy.engine.codex import JudgeProviderError, _loads_no_duplicate_keys
from tooluseproxy.engine.decisions import JevClient, NoRedirect

VERSION = 'kev-loopback-v2'


def validate_local_config(config):
    try:
        url = urllib.parse.urlsplit(config['decision_endpoint'])
        valid = (url.scheme == 'http' and url.hostname == '127.0.0.1'
                 and url.port is not None and 1 <= url.port <= 65535
                 and not url.username and not url.password
                 and url.path in ('', '/') and not url.query and not url.fragment)
        run = config['decision_run']
        valid = valid and isinstance(run, str) and bool(re.fullmatch(
            r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+@[a-f0-9]{40}', run))
        valid = valid and config.get('decision_backend') == 'mlx'
        valid = valid and isinstance(config.get('decision_key_file'), str) and os.path.isabs(config['decision_key_file'])
        if not valid:
            raise ValueError()
    except (KeyError, ValueError, TypeError):
        raise JudgeProviderError('kev_invalid_configuration') from None


def local_key(path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd) as handle:
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
                raise ValueError()
            key = handle.read(257).strip()
        if not re.fullmatch(r'[a-f0-9]{64}', key):
            raise ValueError()
        return key
    except (OSError, ValueError, UnicodeError):
        raise JudgeProviderError('kev_invalid_local_key') from None


class KevClient(JevClient):
    def __init__(self, config):
        validate_local_config(config)
        self.config = dict(config)
        self.endpoint = config['decision_endpoint'].rstrip('/')
        super().__init__('kev-latest', transport=self._transport)
        self.identity = (VERSION, config['decision_run'], config['decision_backend'])
        self.transport_timings = []
        self.request_protocol = None
        self.pending_handles = {}
        self.pending_instances = {}
        self.runtime_instance = None
        self.request_context = None
        self.capacity_wait_seconds = 0.0

    def _await_capacity(self, path, body, deadline, method=None):
        delay = 0.05
        while True:
            try:
                return self._request(path, body, deadline, method=method)
            except JudgeProviderError as error:
                if error.code != 'kev_inference_http_429':
                    raise
                remaining = deadline-time.monotonic()
                if remaining <= 0:
                    raise JudgeProviderError('kev_capacity_wait_expired') from None
                started = time.monotonic()
                time.sleep(min(delay, remaining))
                self.capacity_wait_seconds += time.monotonic()-started
                if time.monotonic() >= deadline:
                    raise JudgeProviderError('kev_capacity_wait_expired') from None
                delay = min(delay*2, 1.0)

    def _request(self, path, body, deadline, method=None):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise JudgeProviderError('kev_deadline_exceeded')
        req = urllib.request.Request(self.endpoint + path, data=body, method=method, headers={
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + local_key(self.config['decision_key_file'])})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        phase = 'metadata' if path == '/v1/models' else 'inference'
        started = time.monotonic()
        success = False
        try:
            with opener.open(req, timeout=remaining) as response:
                raw = response.read(2_000_001)
            success = True
        except urllib.error.HTTPError as error:
            raise JudgeProviderError('kev_' + phase + '_http_' + str(error.code)) from None
        except (urllib.error.URLError, TimeoutError, OSError):
            raise JudgeProviderError('kev_' + phase + '_transport_failed') from None
        finally:
            self.transport_timings.append(dict(phase=phase, success=success,
                                                seconds=time.monotonic()-started))
            del self.transport_timings[:-128]

        if len(raw) > 2_000_000:
            raise JudgeProviderError('kev_response_too_large')
        return raw

    def _verify(self, deadline):
        try:
            data = _loads_no_duplicate_keys(self._request('/v1/models', None, deadline))
            protocol = data.get('request_protocol')
            if protocol not in (None, 'tooluseproxy-requests-v1'):
                raise ValueError()
            instance = data.get('runtime_instance')
            if protocol and (not isinstance(instance, str) or not re.fullmatch('[a-f0-9]{32}', instance)):
                raise ValueError()
            self.runtime_instance = instance
            matches = [m for m in data['models'] if m.get('name') == self.model]
            if len(matches) != 1:
                raise ValueError()
            self.request_protocol = protocol
            model = matches[0]
            if (model.get('run') != self.config['decision_run']
                    or model.get('backend') != self.config['decision_backend']
                    or model.get('truncate_states') is not False):
                raise ValueError()
        except (ValueError, TypeError, KeyError, UnicodeError, AttributeError):
            raise JudgeProviderError('kev_model_identity_mismatch') from None

    def _transport(self, body, remaining):
        deadline = time.monotonic() + remaining
        self._verify(deadline)
        raw = (self._queued(body, deadline) if self.request_protocol else
               self._request('/v1/systemone', body, deadline))
        self._verify(deadline)
        handle = self.pending_handles.pop(hashlib.sha256(body).hexdigest(), None)
        self.pending_instances.pop(hashlib.sha256(body).hexdigest(), None)
        if handle is not None:
            try:
                self._request('/v1/requests/'+handle, None, deadline, method='DELETE')
            except JudgeProviderError:
                # The result is already received and identity checked. Failed
                # cleanup is bounded by server retention; don't redo inference.
                pass
        return raw

    def _queued(self, body, deadline):
        from tooluseproxy.engine.local_request_store import RequestStore
        import json
        scope = hashlib.sha256(json.dumps([self.identity, self.endpoint], sort_keys=True).encode()).hexdigest()
        store = RequestStore(*self.request_context, scope) if self.request_context else None
        digest = hashlib.sha256(body).hexdigest()
        saved = store.get(digest) if store else None
        if saved and saved[1] is not None:
            return saved[1]
        handle = saved[0] if saved else self.pending_handles.get(digest)
        old_instance = (store.instance(digest, handle) if store and handle else
                        self.pending_instances.get(digest))
        replaced_handle = None
        if handle and old_instance and old_instance != self.runtime_instance:
            # A new verified serving generation cannot contain the old job.
            # Recompute inference only; this path never dispatches a ToolCall.
            replaced_handle, handle = handle, None
        if handle is None:
            if digest not in self.pending_handles and len(self.pending_handles) >= 128:
                raise JudgeProviderError('kev_unresolved_request_limit')
            reservation = _loads_no_duplicate_keys(self._await_capacity('/v1/requests', b'', deadline))
            handle = reservation.get('handle') if isinstance(reservation, dict) else None
            if not isinstance(handle, str) or not re.fullmatch('[A-Za-z0-9_-]{43}', handle):
                raise JudgeProviderError('kev_invalid_request_handle')
            if reservation.get('runtime_instance') != self.runtime_instance:
                raise JudgeProviderError('kev_runtime_changed_during_reservation')
            if store:
                handle, response = (store.recover(digest, replaced_handle, handle, self.runtime_instance)
                                    if replaced_handle else store.accept(digest, handle, self.runtime_instance))
                if response is not None:
                    return response
            # Retain before transmitting evidence. A lost response never causes
            # this client to reserve another handle for the same request body.
        self.pending_handles[digest] = handle
        self.pending_instances[digest] = self.runtime_instance
        path = '/v1/requests/'+handle
        def exchange(payload=None, method=None):
            try:
                if method == 'PUT':
                    return self._await_capacity(path, payload, deadline, method=method)
                return self._request(path, payload, deadline, method=method)
            except JudgeProviderError:
                # Another process may already have persisted and acknowledged
                # the result while this process was polling the same handle.
                saved = store.get(digest) if store else None
                if saved and saved[1] is not None:
                    return json.dumps(dict(state='completed', result=base64.b64encode(saved[1]).decode())).encode()
                raise
        exchange(body, 'PUT')
        while True:
            state = _loads_no_duplicate_keys(exchange())
            if not isinstance(state, dict):
                raise JudgeProviderError('kev_invalid_request_state')
            if state.get('state') == 'completed':
                try:
                    raw = base64.b64decode(state['result'], validate=True)
                    if len(raw) > 1_000_000:
                        raise ValueError()
                except (KeyError, ValueError, TypeError):
                    raise JudgeProviderError('kev_invalid_request_result') from None
                if store:
                    store.complete(digest, handle, raw)
                # The caller releases the handle after model identity is
                # verified again; a failed metadata read must not resubmit work.
                return raw
            if state.get('state') == 'failed':
                raise JudgeProviderError('kev_inference_job_failed')
            if state.get('state') not in ('queued', 'running'):
                raise JudgeProviderError('kev_invalid_request_state')
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                raise JudgeProviderError('kev_deadline_exceeded')
            time.sleep(min(0.1, remaining))


def setup_config(path):
    """Read explicit local settings, retaining only provider connection fields."""
    import json
    from pathlib import Path
    try:
        raw = json.loads(Path(path).read_text())
        fields = ('decision_endpoint', 'decision_run', 'decision_backend', 'decision_key_file')
        if not isinstance(raw, dict) or raw.get('provider') != 'kev_edges':
            raise ValueError()
        config = dict(provider='kev_edges', **{field: raw[field] for field in fields})
        validate_local_config(config)
        return config
    except (OSError, ValueError, KeyError, TypeError):
        raise JudgeProviderError('kev_invalid_configuration') from None


def preflight(config):
    """Warm the installed server using synthetic data only; no workspace reads."""
    client = KevClient(config)
    client.decide('Synthetic readiness check: reception is open.', {'ready': dict(
        type='choice', instructions='Is reception described as open?',
        criteria={'yes': 'Open', 'no': 'Not open'})})
    # Valid inference proves availability, not accuracy or Hook enforcement.
    return True
