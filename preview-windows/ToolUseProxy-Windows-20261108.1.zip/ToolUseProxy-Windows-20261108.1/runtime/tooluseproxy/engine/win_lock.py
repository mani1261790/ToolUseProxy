"""One-byte non-blocking session lock; released automatically on process exit."""
import errno,msvcrt,os
LOCK_EX, LOCK_NB, LOCK_UN = 1,2,4
def flock(handle, mode):
    os.lseek(handle.fileno(),0,os.SEEK_SET)
    try:
        msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK if mode==LOCK_UN else msvcrt.LK_NBLCK,1)
    except OSError as exc:
        if mode!=LOCK_UN and exc.errno==errno.EACCES:
            raise BlockingIOError from exc
        raise
