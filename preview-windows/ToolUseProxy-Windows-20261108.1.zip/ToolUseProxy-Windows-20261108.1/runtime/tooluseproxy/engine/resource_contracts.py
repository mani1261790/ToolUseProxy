"""Exhaustive resource contracts for the host's literal patch format.

Paths are not evidence of semantic contribution. Update/delete operations retain
Codex resolution; only literal additions have no implicit old-content input.
"""
import posixpath
import re
from pathlib import PurePosixPath


def patch_resources(tool_name, tool_input):
    if tool_name != 'apply_patch':
        return None
    patch = tool_input if isinstance(tool_input, str) else (
        tool_input.get('patch', tool_input.get('command')) if isinstance(tool_input, dict) else None)
    if not isinstance(patch, str):
        return None
    lines = patch.splitlines()
    if not lines or lines[0] != '*** Begin Patch' or lines[-1] != '*** End Patch':
        return None
    resources, additions, active, content = [], True, None, False
    seen = set()
    for line in lines[1:-1]:
        headers = [('*** Add File: ', 'add'), ('*** Update File: ', 'update'),
                   ('*** Delete File: ', 'delete'), ('*** Move to: ', 'move')]
        matched = next(((prefix, kind) for prefix, kind in headers if line.startswith(prefix)), None)
        if matched:
            prefix, kind = matched
            path = line[len(prefix):]
            if (not path or posixpath.normpath(path) != path
                    or path == '..' or path.startswith('../') or '\x00' in path or path in seen):
                return None
            if kind == 'move' and active != 'update':
                return None
            if active == 'add' and not content:
                return None
            seen.add(path)
            resources.append(dict(path=path, mode='write'))
            if kind in ('update', 'delete'):
                resources.append(dict(path=path, mode='read'))
            additions = additions and kind == 'add'
            if kind != 'move':
                active, content = kind, False
        elif active == 'add' and line.startswith('+'):
            content = True
        elif active == 'update' and (line.startswith((' ', '+', '-', '@@')) or line == '*** End of File'):
            content = True
        else:
            return None
    if not resources or (active == 'add' and not content):
        return None
    return dict(resources=resources, additions_only=additions)


def literal_shell_write(tool_name, tool_input):
    """Closed printf replacement, optionally followed by a read of that same file.

    No expansion, append, substitution, pipeline, variable format, or partial edit.
    The post-call snapshot must still witness the write before semantic use.
    """
    if tool_name != 'Bash' or not isinstance(tool_input, dict):
        return None
    command = tool_input.get('command')
    if not isinstance(command, str) or len(command) > 64_000:
        return None
    match = re.fullmatch(
        r"printf[ \t]+'%s(?P<newline>\\n)?'[ \t]+'(?P<text>[^'\x00]*)'[ \t]*>[ \t]*"
        r"(?P<path>[A-Za-z0-9_./-]+)(?:[ \t]*(?:\n|&&)[ \t]*cat[ \t]+(?P=path))?[ \t]*", command)
    if not match:
        return None
    path = match["path"]
    if (path.startswith(('-', '/', '../')) or path in ('.', '..')
            or posixpath.normpath(path) != path or path.endswith('/')):
        return None
    return dict(resources=[dict(path=path, mode='write')], additions_only=True,
                literal_bytes=(match['text'] + ('\n' if match['newline'] else '')).encode('utf-8'))


def literal_creation(node):
    """Only closed, successfully witnessed new files qualify for span resolution."""
    contract = patch_resources(node.get('tool_name'), node.get('input'))
    if contract is None:
        if node.get('literal_value_verified') is not True:
            return None
        contract = literal_shell_write(node.get('tool_name'), node.get('input'))
    if (not contract or not contract['additions_only'] or not node.get('completed')
            or node.get('required_output') is not None):
        return None
    if node.get('resolved_cwd') != node.get('workspace_root'):
        return None
    observed = {(r['path'], r['mode']) for r in node.get('resource_observations', [])
                if r.get('status') == 'observed'}
    from tooluseproxy.engine.requirements import resource_identity
    try:
        resources = [dict(r, path=resource_identity(r['path'], node['workspace_root']))
                     for r in contract['resources']]
    except (ValueError, OSError):
        return None
    expected = {(r['path'], r['mode']) for r in resources}
    if observed != expected:
        return None
    # A partial output/resource demand needs a narrower target than all additions.
    # The model sees that scope, but unknown configuration projections stay with
    # the existing resolver until their coverage has an explicit contract.
    if any(r.get('projections') for r in node.get('required_resources', []) or []):
        return None
    return [dict(r, reason='literal replacement resource witnessed after execution')
            for r in resources]


def payload_accesses(node):
    """Byte observations impose read edges independently of model proposals."""
    from tooluseproxy.engine.requirements import resource_identity
    paths = set()
    for part in node.get('payload_observations', []):
        observation = part.get('observation', {})
        if 'path' in observation:
            paths.add(observation['path'])
        if observation.get('object_kind') == 'blob':
            paths.update(str(PurePosixPath(observation['repository']) / path)
                         for path in observation['paths'])
    return [dict(path=resource_identity(path, node['workspace_root']), mode='read',
                 reason='controller-resolved transmitted resource bytes') for path in sorted(paths)]


def closed_payload(node):
    """Only fully resolved, non-transforming value sources close the inventory.

    Repository commit/tree metadata needs its own generation evidence; leave
    that to the existing resolver. Neither hashes nor an empty result prove safety.
    """
    parts = node.get('payload_observations')
    if (node.get('payload_coverage_complete') is not True
            or node.get('payload_contract_verified') is not True or not parts):
        return None
    for part in parts:
        kind = part.get('resource_kind')
        observation = part.get('observation', {})
        if kind not in ('file', 'event_input', 'event_output', 'invocation_context'):
            return None
        if kind == 'file' and (part.get('extent', {}).get('offset') != 0
                or part.get('extent', {}).get('length') != part.get('full_length')
                or 'path' not in observation):
            return None
        if kind == 'event_output' and 'source_node_id' not in observation:
            return None
        if kind == 'invocation_context' and not observation.get('context_origin'):
            return None
    return payload_accesses(node)


def payload_inventory_verified(tool_name, tool_input, parts):
    """Positive inventory adapter for a closed literal binary-body submission.

    curl -q disables implicit curlrc options. Extra flags, expansions, headers,
    multipart/transformations, missing URL bytes and partial file ranges fall back.
    The reusable graph path consumes this proof; a model's complete flag is not it.
    """
    from tooluseproxy.engine.contracts import literal_words
    words = literal_words(tool_name, tool_input)
    if (not words or len(words) != 5 or words[:3] != ['curl', '-q', '--data-binary']
            or not words[3].startswith('@') or not words[4].startswith(('https://','http://'))
            or any(c in word for word in words for c in '~*?[]') or len(parts) != 2):
        return False
    path, url = words[3][1:], words[4]
    if not path or path.startswith(('-', '/')) or posixpath.normpath(path) != path or '..' in path.split('/'):
        return False
    files = [p for p in parts if p.get('resource_kind') == 'file']
    inline = [p for p in parts if p.get('resource_kind') == 'event_input']
    return (len(files)==len(inline)==1
        and files[0].get('observation', {}).get('path')==path
        and files[0].get('extent', {}).get('offset')==0
        and files[0].get('extent', {}).get('length')==files[0].get('full_length')
        and inline[0].get('encoding')=='utf-8' and inline[0].get('content')==url)


def literal_creation_target(node):
    """Name the written bytes, not the tool's acknowledgement, as the target.

    This is a value inventory only. Status/branch dependencies still require
    model assessment against the complete history.
    """
    accesses = literal_creation(node)
    if accesses is None:
        return None
    patch = patch_resources(node.get('tool_name'), node.get('input'))
    values = []
    if patch is not None:
        raw = node['input']
        raw = raw if isinstance(raw, str) else raw.get('patch', raw.get('command'))
        path, lines = None, []
        for line in raw.splitlines()[1:-1]:
            if line.startswith('*** Add File: '):
                if path is not None:
                    values.append(dict(path=path, content='\n'.join(lines)+'\n'))
                path, lines = line[len('*** Add File: '):], []
            else:
                lines.append(line[1:])
        values.append(dict(path=path, content='\n'.join(lines)+'\n'))
    else:
        write = literal_shell_write(node.get('tool_name'), node.get('input'))
        values = [dict(path=write['resources'][0]['path'],
                       content=write['literal_bytes'].decode('utf-8'))]
    target = dict(accesses=accesses,
                  boundary='Controller-extracted written bytes; no claim of semantic independence.')
    if len(values) == 1:
        target['content'] = values[0]['content']
    else:
        target['files'] = values
    return target
