"""Small positive contracts for visible local operations, never command allowlists.

Unsupported syntax falls back to recorded-input classification. These contracts
say nothing about hidden shell startup files, program hooks or network isolation.
They classify communication only; they never grant an outbound permission.
"""

import shlex

from tooluseproxy.engine.resource_contracts import patch_resources, literal_shell_write



def literal_read_paths(tool_name, tool_input):
    """Ordered literal cat invocations only; no transformations or shell effects."""
    words = literal_words(tool_name, tool_input)
    if words:
        return words[1:] if len(words) > 1 and words[0] == 'cat' and all(
            not p.startswith('-') for p in words[1:]) else None
    groups = literal_and_groups(tool_name, tool_input)
    if not groups or any(len(group) < 2 or group[0] != 'cat' or
                         any(p.startswith('-') for p in group[1:]) for group in groups):
        return None
    return [path for group in groups for path in group[1:]]


def literal_and_groups(tool_name, tool_input):
    """Parse a closed AND-list; no expansion, redirection or other operators."""
    if tool_name != 'Bash' or not isinstance(tool_input, dict):
        return None
    command = tool_input.get('command')
    if (not isinstance(command, str) or len(command) > 64_000
            or any(c in command for c in '\n\r<>`$(){}\\#')):
        return None
    # shlex removes quotes, so a literal argument "&&" would otherwise look
    # like a shell separator. Refuse operator characters inside either quote.
    quote = None
    for char in command:
        if quote is not None:
            if char == quote:
                quote = None
            elif char in ';&|':
                return None
        elif char in ('"', "'"):
            quote = char
    lexer = shlex.shlex(command, posix=True, punctuation_chars=';&|')
    lexer.whitespace_split = True
    lexer.commenters = ''
    try:
        tokens = list(lexer)
    except ValueError:
        return None
    groups, current = [], []
    for token in tokens:
        if token == '&&':
            if not current:
                return None
            groups.append(current)
            current = []
        elif any(c in token for c in ';&|'):
            return None
        else:
            current.append(token)
    if not current:
        return None
    groups.append(current)
    return groups


def authenticated_read_spans(node, key, workspace):
    """Prove a literal concatenation against immutable, keyed file observations.

    Never reread live files: a later edit must not change historical provenance.
    An output envelope, diagnostic, truncation or transformation fails this proof.
    """
    import hashlib
    import hmac
    import posixpath
    from tooluseproxy.engine.evidence import ContentVersion, Resource

    paths = literal_read_paths(node.get("tool_name"), node.get("input"))
    if (not key or not node.get("completed") or not paths
            or not isinstance(node.get("output"), str)
            or node.get("resolved_cwd") != node.get("workspace_root")):
        return None
    if any(not p or p.startswith(("-", "/")) or any(c in p for c in "~*?[]")
           or posixpath.normpath(p) != p or p.startswith("../") or p == ".." for p in paths):
        return None
    observed = {r["path"]: r for r in node.get("resource_observations", [])
                if r["mode"] == "read" and r["status"] == "observed"}
    if set(observed) != set(paths):
        return None
    data = node["output"].encode("utf-8")
    spans, offset = [], 0
    for path in paths:
        record = observed[path]
        stamp = record.get("fingerprint")
        if not isinstance(stamp, list) or len(stamp) != 5:
            return None
        size = stamp[2]
        if type(size) is not int or size < 0 or offset + size > len(data):
            return None
        fragment = data[offset:offset + size]
        token = hmac.new(key, fragment, hashlib.sha256).hexdigest()
        expected = ContentVersion(Resource(workspace, "file", path), token, node["event_id"]).identity
        if record.get("version") != expected:
            return None
        spans.append(dict(path=path, offset=offset, length=size))
        offset += size
    return spans if offset == len(data) else None


def read_projections(node):
    """Map selected output bytes to authenticated file ranges, without widening."""
    spans = node.get("authenticated_read_spans")
    if spans is None or node.get("required_resources") is not None:
        return None
    output = node["output"]
    selected = node.get("required_output")
    if selected is None:
        return {span["path"]: None for span in spans}
    texts = selected.get("texts", [selected.get("text")])
    if not texts or any(not isinstance(t, str) or not t or (output.find(t) < 0 or output.find(t) != output.rfind(t)) for t in texts):
        return None
    data = output.encode("utf-8")
    ranges = []
    for text in texts:
        offset = len(output[:output.index(text)].encode("utf-8"))
        ranges.append((offset, offset + len(text.encode("utf-8"))))
    projections = {}
    for span in spans:
        for start, end in ranges:
            left, right = max(start, span["offset"]), min(end, span["offset"] + span["length"])
            if left < right:
                try:
                    text = data[left:right].decode("utf-8")
                except UnicodeError:
                    return None
                projection = dict(kind="file_utf8_range", offset=left - span["offset"],
                                  length=right - left, text=text)
                items = projections.setdefault(span["path"], [])
                if projection not in items:
                    items.append(projection)
    return projections or None


def provenance_contract(node):
    """Authenticated reads preserve resource ancestry and current registration."""
    projections = read_projections(node)
    if projections is None:
        return None
    return dict(externality="local", complete=True,
                reason="authenticated literal file content read", dependencies=[],
                accesses=[dict(path=path, mode="read", reason="observed file content")
                          for path in projections], evidence_requests=[])


def literal_words(tool_name, tool_input):
    if tool_name != "Bash" or not isinstance(tool_input, dict):
        return None
    command = tool_input.get("command")
    if not isinstance(command, str) or len(command) > 64_000:
        return None
    if any(char in command for char in "\n\r;&|<>`$(){}\\"):
        return None
    try:
        return shlex.split(command, posix=True) or None
    except ValueError:
        return None


def communication_contract(tool_name, tool_input):
    local = local_contract(tool_name, tool_input)
    if local is not None:
        return local
    words = literal_words(tool_name, tool_input)
    if (
        words
        and len(words) > 1
        and words[0] == "git"
        and words[1]
        in {
            "push",
            "fetch",
            "pull",
            "clone",
            "ls-remote",
        }
    ):
        return dict(
            externality="external",
            complete=True,
            resources=[],
            reason="explicit_remote_operation_contract",
        )
    return None


def evidence_requirements(tool_name, tool_input):
    words = remote_context_words(tool_name, tool_input)
    if (
        words
        and len(words) > 1
        and words[:2]
        in [
            ["git", "push"],
            ["git", "fetch"],
            ["git", "pull"],
            ["git", "ls-remote"],
        ]
    ):
        # Only the current repository's explicit remote settings. Never walk
        # imports, executable implementations or arbitrary filesystem parents.
        return [{"path": ".git/config", "reason": "resolve named remote configuration"}]
    return []


def local_contract(tool_name, tool_input):
    if tool_name == "apply_patch":
        # The canonical name of the host's local patch operation.
        return dict(
            externality="local", complete=True, resources=(patch_resources(tool_name, tool_input) or {}).get("resources", []), reason="local_file_edit_contract"
        )
    replacement = literal_shell_write(tool_name, tool_input)
    if replacement is not None:
        return dict(externality='local', complete=True, resources=replacement['resources'],
                    reason='literal_file_replacement_contract')
    reads = literal_read_paths(tool_name, tool_input)
    if reads:
        return dict(externality='local', complete=True,
                    resources=[dict(path=p, mode='read') for p in reads],
                    reason='literal_local_command_contract')
    words = literal_words(tool_name, tool_input)
    if not words:
        groups = literal_and_groups(tool_name, tool_input)
        if not groups or len(groups) < 2:
            return None
        parts = [local_contract(tool_name, dict(tool_input, command=shlex.join(group)))
                 for group in groups]
        if any(part is None for part in parts):
            return None
        return dict(externality='local', complete=True,
                    resources=[resource for part in parts for resource in part['resources']],
                    reason='composed_literal_local_contract')
    executable, args = words[0], words[1:]
    # No executable-path aliasing, env wrappers, function expansion or -c flags.
    if executable in {"pwd", "ls", "cat", "head", "tail", "wc"}:
        resources = (
            [dict(path=path, mode="read") for path in args]
            if executable == "cat" and all(not path.startswith("-") for path in args)
            else []
        )
        return dict(
            externality="local",
            complete=True,
            resources=resources,
            reason="literal_local_command_contract",
        )
    if (
        executable == "git"
        and args
        and args[0]
        in {
            "status",
            "add",
            "commit",
            "diff",
            "log",
            "show",
            "rev-parse",
            "rev-list",
            "branch",
            "reset",
            "ls-files",
        }
    ):
        # An invocation of git's local operation is local in the explicit-send
        # product boundary. Its configured hooks/helpers are outside coverage.
        # Global options (notably -c), remote commands and aliases do not match.
        return dict(
            externality="local",
            complete=True,
            resources=[],
            reason="literal_local_command_contract",
        )
    return None


def remote_context_words(tool_name, tool_input):
    """One remote invocation with only literal read-only inspections around it.

    This exposes configuration evidence, not an execution permission. Operations
    that can change cwd/configuration or a second remote command stay unresolved.
    """
    words = literal_words(tool_name, tool_input)
    remote = {'push', 'fetch', 'pull', 'ls-remote'}
    if words:
        return words if len(words)>1 and words[0]=='git' and words[1] in remote else None
    if tool_name != 'Bash' or not isinstance(tool_input, dict):
        return None
    command = tool_input.get('command')
    if not isinstance(command, str) or len(command)>64_000 or any(c in command for c in '\r<>`$(){}\\'):
        return None
    lexer = shlex.shlex(command, posix=True, punctuation_chars=';&|\n')
    lexer.whitespace=' \t'
    lexer.whitespace_split=True
    lexer.commenters=''
    try:
        tokens=list(lexer)
    except ValueError:
        return None
    segments, current = [], []
    for token in tokens:
        if token in ('\n',';','&&'):
            if not current:
                return None
            segments.append(current)
            current=[]
        elif any(c in token for c in ';&|\n'):
            return None
        else:
            current.append(token)
    if current:
        segments.append(current)
    found=[]
    for part in segments:
        if len(part)<2 or part[0]!='git':
            return None
        if part[1] in remote:
            found.append(part)
        elif part[1:] == ['branch','--show-current']:
            continue
        else:
            flags = {
                'status': {'--short', '--porcelain', '--porcelain=v1', '--porcelain=v2', '-sb'},
                'log': {'--oneline', '--branches', '--not', '--remotes', '--all', '-5', '-1'},
                'diff': {'--name-only', '--stat', '--cached', '--staged', '--quiet'},
                'rev-parse': {'--abbrev-ref', '--show-toplevel', '--verify', '--git-dir'},
                'rev-list': {'--count', '--left-right', '--max-count=1'},
                'ls-files': {'--stage', '--cached'},
            }.get(part[1])
            if flags is None or any(arg.startswith('-') and arg not in flags for arg in part[2:]):
                return None
    return found[0] if len(found)==1 else None
