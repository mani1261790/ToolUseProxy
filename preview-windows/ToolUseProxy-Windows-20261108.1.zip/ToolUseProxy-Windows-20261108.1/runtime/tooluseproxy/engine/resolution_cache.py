"""Bounded reuse of an identical, validated provenance assessment, never permission."""
import json
import sqlite3
import time

VERSION = 'exact-resolution-v1'
MAX_ENTRIES = 128
MAX_BYTES = 131072
TTL_SECONDS = 3600


def schema(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS exact_resolution_cache (
        request TEXT PRIMARY KEY, payload TEXT NOT NULL, created REAL NOT NULL)''')


def load(db, key):
    try:
        with sqlite3.connect(db, timeout=0.1) as conn:
            schema(conn)
            row = conn.execute('SELECT payload FROM exact_resolution_cache WHERE request=? AND created>=?',
                               (key, time.time()-TTL_SECONDS)).fetchone()
        if row and len(row[0].encode()) <= MAX_BYTES:
            return json.loads(row[0])
    except (sqlite3.Error, ValueError, TypeError):
        pass
    return None


def save(db, key, value):
    encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
    if len(encoded.encode()) > MAX_BYTES:
        return
    try:
        with sqlite3.connect(db, timeout=0.1) as conn:
            schema(conn)
            conn.execute('DELETE FROM exact_resolution_cache WHERE created<?', (time.time()-TTL_SECONDS,))
            conn.execute('INSERT OR REPLACE INTO exact_resolution_cache VALUES (?,?,?)',
                         (key, encoded, time.time()))
            conn.execute('''DELETE FROM exact_resolution_cache WHERE request IN (
                SELECT request FROM exact_resolution_cache ORDER BY created DESC, request DESC
                LIMIT -1 OFFSET ?)''', (MAX_ENTRIES,))
    except sqlite3.Error:
        pass  # Optional acceleration must not turn into a judgment failure.
