"""Bound each model request, not the container of independent requests."""
import json

MAX_RECORD_BYTES = 512_000


def record_bytes(value):
    return len(json.dumps(value, ensure_ascii=False).encode('utf-8'))


def requests_fit(value, method=None, *, evidence_encoder=None, limit=None):
    limit = MAX_RECORD_BYTES if limit is None else limit
    packets = value if method in ('review_scopes', 'review_frontier') else [value]
    return all(record_bytes(evidence_encoder(packet) if evidence_encoder else packet)
               <= limit for packet in packets)


def provider_requests_fit(provider, value, method=None):
    """Let a provider describe its wire representation, retaining conservative fallback.

    A composite provider must account for every transport before exposing this
    capability. An extractor's encoding alone does not bound its decision API.
    Actual transports must still enforce their final request limits.
    """
    check = getattr(provider, 'requests_fit', None)
    if callable(check):
        return check(value, method) is True
    return requests_fit(value, method)
