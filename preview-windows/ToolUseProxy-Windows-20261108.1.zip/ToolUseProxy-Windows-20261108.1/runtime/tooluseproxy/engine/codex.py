"""Isolated Codex inference transport. No ToolUseProxy analysis imports."""

from __future__ import annotations
import json
import os
import re
import signal
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path


class JudgeProviderError(RuntimeError):
    def __init__(self, code: str, *, diagnostics=None):
        self.code = code
        # Only fixed numeric counters may leave the isolated inference transport.
        self.diagnostics = {k: v for k, v in (diagnostics or {}).items()
                            if k in PROCESS_COUNTERS and type(v) is int and v >= 0}
        super().__init__(code)


PROCESS_EVENTS = ('thread.started', 'turn.started', 'item.started',
                  'item.updated', 'item.completed', 'turn.completed', 'turn.failed', 'error')
PROCESS_COUNTERS = (*PROCESS_EVENTS, 'stdout_bytes', 'stderr_bytes',
                    'unknown_events', 'invalid_lines', 'process_exit_code', 'process_signal',
                    'transport_timeout', 'transport_url_error', 'transport_os_error',
                    'transport_dns_error', 'transport_tls_error', 'transport_tls_verification_error',
                    'transport_connection_reset', 'transport_connection_refused',
                    'transport_connection_aborted', 'transport_response_started',
                    'capacity_error')


def process_progress(stdout: bytes, stderr: bytes) -> dict:
    """Report protocol progress, never message text, identifiers or error strings."""
    counters = dict.fromkeys(PROCESS_COUNTERS, 0)
    counters.update(stdout_bytes=len(stdout), stderr_bytes=len(stderr))
    for line in stdout.splitlines():
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except (ValueError, UnicodeError):
            counters['invalid_lines'] += 1
            continue
        kind = event.get('type') if isinstance(event, dict) else None
        if isinstance(kind, str) and kind in PROCESS_EVENTS:
            counters[kind] += 1
            # Only protocol error fields, never model output or stderr text.
            if kind in ('error', 'turn.failed'):
                error = event.get('error')
                messages = [event.get('message'), event.get('code')]
                if isinstance(error, dict):
                    messages.extend((error.get('message'), error.get('code')))
                if any(isinstance(value, str) and re.search(r'\bcapacity\b', value, re.I)
                       for value in messages):
                    counters['capacity_error'] += 1
        else:
            counters['unknown_events'] += 1
    return counters


class PartialReviewError(JudgeProviderError):
    """Independent successful requests survive a peer failure; none is permission."""
    def __init__(self, cause: Exception, completed: dict[int, dict]):
        super().__init__(cause.code if isinstance(cause, JudgeProviderError)
                         else 'parallel_review_failed')
        self.cause = cause
        self.completed = completed


@dataclass(frozen=True)
class ProcessResult:
    returncode: int
    stdout: bytes
    stderr: bytes


CODEX_DISABLED_FEATURES = (
    "apps",
    "browser_use",
    "browser_use_external",
    "browser_use_full_cdp_access",
    "code_mode_host",
    "computer_use",
    "hooks",
    "image_generation",
    "in_app_browser",
    "memories",
    "multi_agent",
    "multi_agent_v2",
    "plugins",
    "remote_plugin",
    "shell_tool",
    "standalone_web_search",
    "tool_suggest",
    "unified_exec",
    "unified_exec_zsh_fork",
    "workspace_dependencies",
)


def build_codex_exec_argv(
    *,
    executable: str,
    schema_path: Path,
    output_path: Path,
    model: str | None,
    context_window: int | None = None,
) -> list[str]:
    argv = [
        executable,
        "exec",
        "--ephemeral",
        "--ignore-user-config",
        "--ignore-rules",
        "--strict-config",
        "--skip-git-repo-check",
        "--sandbox",
        "read-only",
        "--json",
        "--color",
        "never",
        "--output-schema",
        str(schema_path),
        "--output-last-message",
        str(output_path),
    ]
    for feature in CODEX_DISABLED_FEATURES:
        argv.extend(("--disable", feature))
    if model is not None:
        argv.extend(("--model", model))
    if context_window is not None:
        if type(context_window) is not int or not 1 <= context_window <= 872_000 or not model:
            raise JudgeProviderError('invalid_resolver_context_configuration')
        argv.extend(("-c", f"model_context_window={context_window}"))
    argv.append("-")
    return argv


def codex_events_contain_tool_activity(events: bytes) -> bool:
    for raw_line in events.splitlines():
        if not raw_line.strip():
            continue
        try:
            event = json.loads(raw_line)
        except (UnicodeDecodeError, json.JSONDecodeError):
            return True
        if _contains_forbidden_event_value(event):
            return True
    return False


def _contains_forbidden_event_value(value: object) -> bool:
    forbidden = {
        "browser",
        "command_execution",
        "computer_use",
        "function_call",
        "mcp_tool_call",
        "shell",
        "tool_call",
        "web_search",
    }
    if isinstance(value, dict):
        for key, nested in value.items():
            if key in {"type", "item_type", "tool"} and isinstance(nested, str):
                normalized = nested.lower()
                if normalized in forbidden or any(token in normalized for token in forbidden):
                    return True
            if _contains_forbidden_event_value(nested):
                return True
    elif isinstance(value, list):
        return any(_contains_forbidden_event_value(item) for item in value)
    return False


def _loads_no_duplicate_keys(value: str | bytes) -> object:
    def closed_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, item in pairs:
            if key in result:
                raise JudgeProviderError("provider_response_duplicate_key")
            result[key] = item
        return result

    return json.loads(value, object_pairs_hook=closed_object)


def _minimal_codex_environment() -> dict[str, str]:
    allowed = (
        "CODEX_HOME",
        "HOME",
        "LANG",
        "LC_ALL",
        "PATH",
        "SSL_CERT_DIR",
        "SSL_CERT_FILE",
        "TMPDIR",
    )
    environment = {key: os.environ[key] for key in allowed if key in os.environ}
    environment["NO_COLOR"] = "1"
    environment["TOOLUSEPROXY_CODEX_JUDGE"] = "1"
    return environment


def _run_process(
    argv: list[str],
    stdin: bytes,
    cwd: Path,
    environment: dict[str, str],
    timeout_seconds: float,
    *,
    cancel_check=None,
) -> ProcessResult:
    if cancel_check is not None:
        cancel_check()
    try:
        process = subprocess.Popen(
            argv,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd,
            env=environment,
            start_new_session=os.name == "posix",
        )
    except OSError as exc:
        raise JudgeProviderError("codex_exec_unavailable") from exc
    communication = None
    exchange = {}
    try:
        if cancel_check is None:
            stdout, stderr = process.communicate(stdin, timeout=timeout_seconds)
        else:
            # communicate(None) after a timed-out communicate(input) does not
            # resume unfinished stdin writes on CPython/POSIX. Keep exactly one
            # exchange alive while the controller polls cancellation/deadline.
            ready = threading.Event()

            def communicate():
                try:
                    exchange['output'] = process.communicate(stdin)
                except BaseException as exc:
                    exchange['error'] = exc
                finally:
                    ready.set()

            communication = threading.Thread(target=communicate, name='judge-pipes')
            communication.start()
            deadline = time.monotonic() + timeout_seconds
            while True:
                cancel_check()
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(argv, timeout_seconds)
                if ready.wait(min(0.25, remaining)):
                    communication.join()
                    if 'error' in exchange:
                        raise exchange['error']
                    stdout, stderr = exchange['output']
                    break
    except BaseException as error:
        # Background preemption must reap the isolated inference process group,
        # just like a timeout, and must never return a partial model verdict.
        try:
            if os.name == "nt":
                subprocess.run(["taskkill.exe", "/T", "/F", "/PID", str(process.pid)], capture_output=True, timeout=10) if process.poll() is None else None
            else:
                os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        if communication is not None:
            communication.join()
            partial_stdout, partial_stderr = exchange.get('output', (b'', b''))
        else:
            partial_stdout, partial_stderr = process.communicate()
        if isinstance(error, subprocess.TimeoutExpired):
            raise JudgeProviderError("codex_exec_timeout", diagnostics=process_progress(
                partial_stdout, partial_stderr)) from error
        raise
    return ProcessResult(process.returncode, stdout, stderr)
