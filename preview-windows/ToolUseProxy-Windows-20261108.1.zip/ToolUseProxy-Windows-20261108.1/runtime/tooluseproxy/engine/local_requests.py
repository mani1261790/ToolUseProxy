"""Bounded, process-local inference jobs, independent of protection decisions.

Reserve a server-issued handle before submitting evidence. An expired or lost
handle never creates a new job. Repeating submit on a live handle is idempotent.
The HTTP adapter must authenticate callers before exposing this registry.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import hashlib
import secrets
import threading
import time


class RequestError(Exception):
    pass


@dataclass
class _Job:
    state: str
    touched: float
    digest: bytes | None = None
    payload: bytes | None = None
    result: bytes | None = None
    error: str | None = None


class RequestRegistry:
    def __init__(self, infer, *, max_jobs=32, max_bytes=8_000_000,
                 max_request_bytes=1_000_000, retention_seconds=300,
                 clock=time.monotonic):
        if min(max_jobs, max_bytes, max_request_bytes, retention_seconds) <= 0 or max_bytes < max_request_bytes:
            raise ValueError('invalid_request_limits')
        self.infer = infer
        self.max_jobs, self.max_bytes = max_jobs, max_bytes
        self.max_request_bytes = max_request_bytes
        self.retention_seconds, self.clock = retention_seconds, clock
        self._jobs = {}
        self._queue = deque()
        self._bytes = 0
        self._closed = False
        self._condition = threading.Condition()
        self._worker = threading.Thread(target=self._work, daemon=True,
                                        name='tooluseproxy-inference')
        self._worker.start()

    def _expire(self):
        now = self.clock()
        for handle, job in list(self._jobs.items()):
            if job.state in ('reserved', 'completed', 'failed') and now-job.touched >= self.retention_seconds:
                self._bytes -= len(job.result or b'')
                del self._jobs[handle]

    def reserve(self):
        with self._condition:
            if self._closed:
                raise RequestError('runtime_closed')
            self._expire()
            if len(self._jobs) >= self.max_jobs:
                raise RequestError('runtime_busy')
            handle = secrets.token_urlsafe(32)
            self._jobs[handle] = _Job('reserved', self.clock())
            return handle

    def _get(self, handle):
        self._expire()
        if handle not in self._jobs:
            raise RequestError('request_missing_or_expired')
        return self._jobs[handle]

    def submit(self, handle, payload):
        if not isinstance(payload, bytes) or len(payload) > self.max_request_bytes:
            raise RequestError('request_invalid_size')
        digest = hashlib.sha256(payload).digest()
        with self._condition:
            job = self._get(handle)
            if job.digest is not None:
                if job.digest != digest:
                    raise RequestError('request_content_conflict')
                return self._snapshot(job)
            if self._closed:
                raise RequestError('runtime_closed')
            if self._bytes + self.max_request_bytes > self.max_bytes:
                raise RequestError('runtime_busy')
            job.digest, job.payload, job.state = digest, payload, 'queued'
            # Reserve room for the result too, so other submissions cannot
            # prevent retention of a completed inference.
            self._bytes += self.max_request_bytes
            self._queue.append(handle)
            self._condition.notify()
            return self._snapshot(job)

    @staticmethod
    def _snapshot(job):
        # Never return an input payload or a mutable reference to internal state.
        return dict(state=job.state, result=job.result, error=job.error)

    def status(self, handle):
        with self._condition:
            return self._snapshot(self._get(handle))

    def acknowledge(self, handle):
        """Release a delivered terminal result; never cancel accepted work."""
        with self._condition:
            job = self._get(handle)
            if job.state not in ('completed', 'failed'):
                raise RequestError('request_still_active')
            self._bytes -= len(job.result or b'')
            del self._jobs[handle]

    def _work(self):
        while True:
            with self._condition:
                self._condition.wait_for(lambda: self._queue or self._closed)
                if not self._queue:
                    return
                handle = self._queue.popleft()
                job = self._jobs[handle]
                job.state = 'running'
                payload = job.payload
            result, error = None, None
            try:
                result = self.infer(payload)
                if not isinstance(result, bytes) or len(result) > self.max_request_bytes:
                    result, error = None, 'invalid_inference_result'
            except Exception:
                # Provider exceptions can contain evidence; retain only a fixed code.
                error = 'inference_failed'
            with self._condition:
                self._bytes -= self.max_request_bytes
                job.payload = None
                job.result, job.error = result, error
                self._bytes += len(result or b'')
                job.state = 'failed' if error else 'completed'
                job.touched = self.clock()
            # Release local references before waiting for another request.
            payload = result = None

    def close(self, timeout=0):
        """Stop accepting work; queued jobs fail. In-flight inference is not killed."""
        with self._condition:
            self._closed = True
            self._queue.clear()
            for job in self._jobs.values():
                if job.state in ('reserved', 'queued'):
                    if job.state == 'queued':
                        self._bytes -= self.max_request_bytes
                    job.payload = None
                    job.state, job.error = 'failed', 'runtime_closed'
                    job.touched = self.clock()
            self._condition.notify_all()
        self._worker.join(timeout)
        return not self._worker.is_alive()
