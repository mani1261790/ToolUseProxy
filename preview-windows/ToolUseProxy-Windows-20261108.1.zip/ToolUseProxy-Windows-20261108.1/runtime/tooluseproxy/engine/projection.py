"""Incremental, lazy call projection with evidence-range invalidation.

The source journal remains authoritative. Corrections rebuild a session's view;
ordinary append-only ingestion touches only new/changed calls. Negative review
results depend on the whole recorded candidate range, not just selected parents.
"""
from __future__ import annotations

import json
from collections.abc import Sequence

from tooluseproxy.engine.graph import GraphUnavailable, digest, merge_call
from tooluseproxy.engine.lineage import attach_witnesses, schema as lineage_schema

VERSION = "incremental-evidence-v7"


def schema(conn):
    lineage_schema(conn)
    from tooluseproxy.engine.transmission_evidence import schema as transmission_schema
    transmission_schema(conn)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS analysis_changes (
            id INTEGER PRIMARY KEY AUTOINCREMENT, workspace TEXT NOT NULL,
            sequence INTEGER NOT NULL);
        CREATE INDEX IF NOT EXISTS analysis_changes_scope
            ON analysis_changes(workspace,id,sequence);
        CREATE TABLE IF NOT EXISTS analysis_projection_state (
            workspace TEXT NOT NULL, session TEXT NOT NULL, boundary INTEGER NOT NULL,
            cursor INTEGER NOT NULL, token INTEGER NOT NULL, events INTEGER NOT NULL,
            bytes INTEGER NOT NULL, nodes INTEGER NOT NULL,
            PRIMARY KEY(workspace,session));
        CREATE TABLE IF NOT EXISTS analysis_projection_formats (
            workspace TEXT NOT NULL, session TEXT NOT NULL, version TEXT NOT NULL,
            PRIMARY KEY(workspace,session));
        CREATE TABLE IF NOT EXISTS analysis_calls (
            workspace TEXT NOT NULL, session TEXT NOT NULL, ordinal INTEGER NOT NULL,
            node TEXT NOT NULL, event TEXT NOT NULL, value TEXT NOT NULL,
            node_hash TEXT NOT NULL, prefix TEXT NOT NULL,
            PRIMARY KEY(workspace,session,ordinal), UNIQUE(workspace,session,node));
        CREATE INDEX IF NOT EXISTS analysis_calls_event
            ON analysis_calls(workspace,session,event);
        CREATE TABLE IF NOT EXISTS analysis_trees (
            request TEXT PRIMARY KEY, workspace TEXT NOT NULL, cutoff INTEGER NOT NULL,
            token INTEGER NOT NULL, boundary INTEGER NOT NULL, node TEXT NOT NULL,
            revision TEXT NOT NULL, verdict TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS analysis_trees_revision ON analysis_trees(workspace,revision);
    """)
    # Source tables may be corrected by migration/admin/import paths, so track
    # mutations in SQLite rather than relying on a particular Python writer.
    for table in ("events", "flow_file_observations", "flow_immutable_reads", "flow_transmission_observations", "flow_patch_range_maps"):
        for operation, aliases in (("INSERT", ("NEW",)), ("DELETE", ("OLD",)),
                                   ("UPDATE", ("OLD", "NEW"))):
            statements = []
            for alias in aliases:
                if table == "events":
                    statements.append(
                        f"INSERT INTO analysis_changes(workspace,sequence) SELECT "
                        f"{alias}.workspace_id,COALESCE({alias}.sequence_no,0) "
                        f"WHERE {alias}.workspace_id IS NOT NULL;")
                else:
                    statements.append(
                        f"INSERT INTO analysis_changes(workspace,sequence) VALUES "
                        f"({alias}.scope,COALESCE((SELECT sequence_no FROM events "
                        f"WHERE event_id={alias}.event),0));")
            conn.execute(f"CREATE TRIGGER IF NOT EXISTS analysis_{table}_{operation} "
                         f"AFTER {operation} ON {table} BEGIN {''.join(statements)} END")
    # A correction/revocation of the accepted Pre invalidates its saved context.
    for operation, alias in (('INSERT', 'NEW'), ('UPDATE', 'NEW'), ('DELETE', 'OLD')):
        conn.execute(f"""CREATE TRIGGER IF NOT EXISTS analysis_transmission_decision_{operation}
            AFTER {operation} ON semantic_flow_decisions
            WHEN EXISTS (SELECT 1 FROM flow_transmission_observations WHERE event={alias}.event_id)
            BEGIN
            INSERT INTO analysis_changes(workspace,sequence)
                SELECT workspace_id,sequence_no FROM events WHERE event_id={alias}.event_id;
            END""")
    for operation in ('UPDATE', 'DELETE'):
        conn.execute(f"""CREATE TRIGGER IF NOT EXISTS analysis_revision_{operation}
            AFTER {operation} ON graph_revisions BEGIN
            DELETE FROM analysis_trees WHERE workspace=OLD.workspace;
            DELETE FROM graph_direct_reviews;
            INSERT INTO analysis_changes(workspace,sequence) VALUES (OLD.workspace,0);
            END""")


def token(conn):
    return conn.execute("SELECT COALESCE(MAX(id),0) FROM analysis_changes").fetchone()[0]


def boundary(conn, workspace):
    if not conn.execute("SELECT 1 FROM sqlite_master WHERE name='recording_boundaries'").fetchone():
        return 0
    row = conn.execute("SELECT after_sequence FROM recording_boundaries WHERE workspace_id=?",
                       (workspace,)).fetchone()
    return row[0] if row else 0


def changed(conn, workspace, since, cutoff):
    return conn.execute("SELECT 1 FROM analysis_changes WHERE workspace=? AND id>? "
                        "AND sequence<=? LIMIT 1", (workspace, since, cutoff)).fetchone() is not None


def cached_tree(conn, request, workspace):
    row = conn.execute("SELECT cutoff,token,boundary,node,revision,verdict FROM analysis_trees "
                       "WHERE request=? AND workspace=?", (request, workspace)).fetchone()
    if not row or row[2] != boundary(conn, workspace) or changed(conn, workspace, row[1], row[0]):
        return None
    if not conn.execute("SELECT 1 FROM graph_revisions WHERE revision=?", (row[4],)).fetchone():
        return None
    return row[3], row[4], json.loads(row[5])


class Calls(Sequence):
    """Only metadata is needed until a contract/cache actually needs call bytes."""
    def __init__(self, conn, workspace, session, count):
        self.conn, self.workspace, self.session, self.count = conn, workspace, session, count
        self.loaded = {}

    def __len__(self):
        return self.count

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [self[i] for i in range(*index.indices(self.count))]
        if index < 0:
            index += self.count
        if not 0 <= index < self.count:
            raise IndexError(index)
        if index not in self.loaded:
            row = self.conn.execute("SELECT value FROM analysis_calls WHERE workspace=? "
                                    "AND session=? AND ordinal=?",
                                    (self.workspace, self.session, index)).fetchone()
            self.loaded[index] = json.loads(row[0])
        return self.loaded[index]

    def position(self, *, node=None, event=None):
        column, value = ("node", node) if node is not None else ("event", event)
        row = self.conn.execute(f"SELECT ordinal FROM analysis_calls WHERE workspace=? "
                                f"AND session=? AND {column}=?",
                                (self.workspace, self.session, value)).fetchone()
        return row[0] if row else None

    def prefix(self, index):
        return self.conn.execute("SELECT prefix FROM analysis_calls WHERE workspace=? "
                                 "AND session=? AND ordinal=?",
                                 (self.workspace, self.session, index)).fetchone()[0]


def prepare(conn, workspace, session, event, max_events=50_000, max_bytes=64_000_000):
    end = conn.execute("SELECT sequence_no FROM events WHERE event_id=? AND workspace_id=? "
                       "AND session_id=?", (event, workspace, session)).fetchone()
    if not end:
        raise GraphUnavailable("event_missing")
    cutoff = end[0]
    after = boundary(conn, workspace)
    state = conn.execute("SELECT boundary,cursor,token,events,bytes,nodes "
                         "FROM analysis_projection_state WHERE workspace=? AND session=?",
                         (workspace, session)).fetchone()
    stored_format = conn.execute("SELECT version FROM analysis_projection_formats WHERE workspace=? "
                                 "AND session=?", (workspace, session)).fetchone()
    if state and (stored_format != (VERSION,) or state[0] != after or state[1] > cutoff
                  or changed(conn, workspace, state[2], state[1])):
        state = None
    if state is None:
        conn.execute("DELETE FROM analysis_calls WHERE workspace=? AND session=?", (workspace, session))
        state = (after, after, token(conn), 0, 0, 0)
    _, cursor, _, count, size, nodes = state
    if count > max_events or size > max_bytes:
        raise GraphUnavailable("history_budget_exceeded")
    dirty = set()
    rows = conn.execute("""SELECT sequence_no,event_id,phase,tool_use_id,tool_name,payload_json,
        workspace_root,workspace_execution_cwd FROM events WHERE workspace_id=? AND session_id=?
        AND sequence_no>? AND sequence_no<=? AND phase IN ('pre_tool_use','post_tool_use')
        ORDER BY sequence_no""", (workspace, session, cursor, cutoff)).fetchall()
    for sequence, *row in rows:
        count += 1
        size += len(row[4].encode())
        if count > max_events or size > max_bytes:
            raise GraphUnavailable("history_budget_exceeded")
        node = "call:" + digest([workspace, session, row[2]])
        old = conn.execute("SELECT ordinal,value FROM analysis_calls WHERE workspace=? AND session=? "
                           "AND node=?", (workspace, session, node)).fetchone()
        calls = {node: json.loads(old[1])} if old else {}
        merge_call(calls, row, workspace, session)
        value = calls[node]
        value.pop('resource_observations', None)
        value.pop('literal_value_verified', None)
        value.pop('authenticated_read_spans', None)
        value.pop('pre_execution_payload', None)
        value.pop('pre_execution_payload_ref', None)
        value.pop('resource_origins', None)
        value.pop('patch_range_witness', None)
        value.pop('patch_range_witnesses', None)
        ordinal = old[0] if old else nodes
        nodes += int(old is None)
        conn.execute("INSERT OR REPLACE INTO analysis_calls VALUES (?,?,?,?,?,?,?,?)",
                     (workspace, session, ordinal, node, value['event_id'], json.dumps(value), '', ''))
        dirty.add(ordinal)
    for ordinal in sorted(dirty):
        value = json.loads(conn.execute("SELECT value FROM analysis_calls WHERE workspace=? "
            "AND session=? AND ordinal=?", (workspace, session, ordinal)).fetchone()[0])
        attach_witnesses(conn, workspace, value)
        from tooluseproxy.engine.transmission_evidence import attach
        attach(conn, workspace, value)
        conn.execute("UPDATE analysis_calls SET value=?,node_hash=? WHERE workspace=? AND session=? "
                     "AND ordinal=?", (json.dumps(value), digest(value), workspace, session, ordinal))
    if dirty:
        start = min(dirty)
        prefix = digest([VERSION, workspace, session, after])
        if start:
            previous = conn.execute("SELECT prefix,node_hash FROM analysis_calls WHERE workspace=? "
                "AND session=? AND ordinal=?", (workspace, session, start - 1)).fetchone()
            prefix = digest(list(previous))
        for ordinal, node_hash in conn.execute("SELECT ordinal,node_hash FROM analysis_calls "
                "WHERE workspace=? AND session=? AND ordinal>=? ORDER BY ordinal",
                (workspace, session, start)).fetchall():
            conn.execute("UPDATE analysis_calls SET prefix=? WHERE workspace=? AND session=? AND ordinal=?",
                         (prefix, workspace, session, ordinal))
            prefix = digest([prefix, node_hash])
    conn.execute("INSERT OR REPLACE INTO analysis_projection_state VALUES (?,?,?,?,?,?,?,?)",
                 (workspace, session, after, cutoff, token(conn), count, size, nodes))
    conn.execute("INSERT OR REPLACE INTO analysis_projection_formats VALUES (?,?,?)",
                 (workspace, session, VERSION))
    return Calls(conn, workspace, session, nodes)
