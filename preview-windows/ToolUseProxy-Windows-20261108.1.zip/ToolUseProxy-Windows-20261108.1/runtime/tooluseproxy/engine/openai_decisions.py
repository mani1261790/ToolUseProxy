"""OpenAI Decisions adapter. No weights, SDK, or Codex credentials required."""
from __future__ import annotations

import json
import os
from pathlib import Path
import stat
import time
import urllib.error
import urllib.request
import uuid

from tooluseproxy.engine.codex import JudgeProviderError, _loads_no_duplicate_keys
from tooluseproxy.engine.decisions import NoRedirect, probability

VERSION = 'openai-decisions-v1'
MODEL = 'gpt-6-luna'
ENDPOINT = 'https://api.openai.com/v1/decisions'
# Local transport bounds, not a claim about the model's token capacity.
REQUEST_BYTES = 1_000_000
RESPONSE_BYTES = 1_000_000


def usage_counters(raw):
    """Extract only bounded numeric counters; never persist arbitrary provider data."""
    if raw is None or len(raw) > RESPONSE_BYTES:
        return None
    try:
        value = _loads_no_duplicate_keys(raw)
        usage = value.get('usage') if isinstance(value, dict) else None
        if not isinstance(usage, dict):
            return None
        result = {}
        for name in ('input_tokens', 'output_tokens', 'total_tokens'):
            count = usage.get(name)
            if type(count) is int and 0 <= count < 2**63:
                result[name] = count
        details = usage.get('input_tokens_details')
        if isinstance(details, dict):
            selected = {k: details[k] for k in ('cached_tokens', 'cache_write_tokens')
                        if type(details.get(k)) is int and 0 <= details[k] < 2**63}
            if selected:
                result['input_tokens_details'] = selected
        return result or None
    except (ValueError, TypeError, RecursionError):
        return None


def http_failure(error):
    """Keep only known provider error codes, never response text or credentials."""
    reason = 'openai_http_' + str(error.code)
    if error.code != 429:
        return reason
    try:
        body = error.read(4097)
        if len(body) > 4096:
            return reason
        data = json.loads(body)
        code = data.get('error', {}).get('code') if isinstance(data, dict) else None
        if code in ('insufficient_quota', 'rate_limit_exceeded',
                    'billing_hard_limit_reached', 'billing_not_active', 'credit_balance_exhausted'):
            return reason + ':' + code
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    return reason


def api_key():
    value = os.environ.get('OPENAI_API_KEY', '').strip()
    if not value:
        path = Path(os.environ.get('TOOLUSEPROXY_OPENAI_KEY_FILE',
                                   '~/.config/tooluseproxy/openai-api-key')).expanduser()
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, 'r') as handle:
                info = os.fstat(handle.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077 or info.st_uid != os.getuid():
                    raise JudgeProviderError('openai_key_file_permissions')
                value = handle.read(8193).strip()
        except OSError:
            raise JudgeProviderError('openai_api_key_missing') from None
    if not value or len(value) > 8192 or not value.isascii() or any(c.isspace() or ord(c) < 33 for c in value):
        raise JudgeProviderError('openai_api_key_invalid')
    return value


class OpenAIDecisionsClient:
    def __init__(self, model=MODEL, timeout=60, transport=None, *, evidence_encoder=None):
        if model != MODEL:
            raise JudgeProviderError('openai_decision_model_unsupported')
        self.model, self.timeout, self.transport = model, timeout, transport
        self.evidence_encoder = evidence_encoder
        self.identity = VERSION + ':' + model
        if evidence_encoder is not None:
            self.identity += ':' + evidence_encoder.identity
        self.deadline = None
        self.last_report = None
        self.request_context = None
        self.usage_audit_complete = None
        self.usage_audit_failures = 0

    def _audit_usage(self, request_id, receipt):
        if self.request_context is None:
            return
        from tooluseproxy.engine.timing import record_assessment
        saved = record_assessment(*self.request_context, request_id,
                                  dict(kind='decision_api_usage', provider='openai',
                                       endpoint='decisions', model=self.model, **receipt))
        self.usage_audit_complete = bool(self.usage_audit_complete and saved)
        self.usage_audit_failures += int(not saved)

    def decide(self, state, questions):
        self.last_report = None
        self.usage_audit_complete = True if self.request_context is not None else None
        evidence = json.dumps(self.evidence_encoder(state) if self.evidence_encoder else state,
                              ensure_ascii=False, allow_nan=False)
        wire = [{
            'type': 'choice', 'name': name,
            'instructions': json.dumps(q['instructions'], ensure_ascii=False, allow_nan=False),
            'choices': [{'value': k, 'description': v} for k, v in q['criteria'].items()],
        } for name, q in questions.items()]
        def encode(batch):
            return json.dumps(dict(model=self.model, input=evidence, questions=batch),
                              ensure_ascii=False, allow_nan=False).encode()
        # Count the actual converted wire format. Never partition joint evidence.
        base = len(encode([]))
        batches, batch, size = [], [], base
        for question in wire:
            cost = len(json.dumps(question, ensure_ascii=False, allow_nan=False).encode())
            if base + cost > REQUEST_BYTES:
                raise JudgeProviderError('openai_request_too_large')
            if size + cost + (2 if batch else 0) > REQUEST_BYTES:
                batches.append(batch)
                batch, size = [], base
            size += cost + (2 if batch else 0)
            batch.append(question)
        if batch:
            batches.append(batch)
        deadline = time.monotonic() + self.timeout
        if self.deadline is not None:
            deadline = min(deadline, self.deadline)
        answers, reports = {}, []
        for batch in batches:
            body = encode(batch)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise JudgeProviderError('openai_deadline_exceeded')
            started = time.monotonic()
            request_id = 'decision-api:' + uuid.uuid4().hex
            metadata = dict(request_bytes=len(body), questions=len(batch))
            self._audit_usage(request_id, dict(phase='started', **metadata))
            raw, validated = None, False
            try:
                raw = self._request(body, remaining)
                result, normalized = self._parse(raw, batch)
                validated = True
            finally:
                self._audit_usage(request_id, dict(phase='finished', **metadata,
                    duration_ms=(time.monotonic()-started)*1000,
                    outcome='validated' if validated else 'invalid_or_refused_response'
                        if raw is not None else 'transport_error',
                    usage=usage_counters(raw)))
            answers.update(normalized)
            reports.append(dict(model=result['model'], usage=result.get('usage'),
                duration_ms=(time.monotonic()-started)*1000, request_bytes=len(body),
                questions=len(batch)))
        self.last_report = dict(model=self.model, questions=len(questions), batches=reports,
            duration_ms=sum(r['duration_ms'] for r in reports),
            request_bytes=sum(r['request_bytes'] for r in reports))
        return answers

    def _request(self, body, timeout):
        try:
            if self.transport is not None:
                return self.transport(body, timeout)
            request = urllib.request.Request(ENDPOINT, data=body, headers={
                'Authorization': 'Bearer ' + api_key(), 'Content-Type': 'application/json'})
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
            with opener.open(request, timeout=timeout) as response:
                return response.read(RESPONSE_BYTES + 1)
        except urllib.error.HTTPError as error:
            raise JudgeProviderError(http_failure(error)) from None
        except (urllib.error.URLError, TimeoutError, OSError):
            raise JudgeProviderError('openai_transport_failed') from None

    def _parse(self, raw, questions):
        if len(raw) > RESPONSE_BYTES:
            raise JudgeProviderError('openai_response_too_large')
        try:
            result = _loads_no_duplicate_keys(raw)
            if not isinstance(result, dict) or result.get('model') != self.model:
                raise ValueError()
            if result.get('truncated', False) is not False:
                raise ValueError()
            answers = result['answers']
            if not isinstance(answers, list) or len(answers) != len(questions):
                raise ValueError()
            normalized = {}
            for question, answer in zip(questions, answers):
                if not isinstance(answer, dict) or answer.get('name') != question['name']:
                    raise ValueError()
                if answer.get('type') == 'refusal':
                    raise JudgeProviderError('openai_decision_refused')
                options = {v['value'] for v in question['choices']}
                choice = answer.get('choice')
                if (answer.get('type') != 'choice' or type(choice) is not str or choice not in options
                        or not probability(answer.get('confidence'))):
                    raise ValueError()
                distribution = answer['probabilities']
                if not isinstance(distribution, list) or len(distribution) != len(options):
                    raise ValueError()
                probs = {}
                for item in distribution:
                    if (not isinstance(item, dict) or type(item.get('value')) is not str
                            or item['value'] not in options or item['value'] in probs
                            or not probability(item.get('probability'))):
                        raise ValueError()
                    probs[item['value']] = item['probability']
                if abs(sum(probs.values())-1) > 1e-4 or probs[choice] < max(probs.values()):
                    raise ValueError()
                normalized[question['name']] = dict(type='choice', choice=choice,
                    confidence=answer['confidence'], probabilities=probs)
        except (ValueError, TypeError, KeyError, UnicodeError):
            raise JudgeProviderError('openai_invalid_response') from None
        return result, normalized
