"""Experimental paired-Hook receipts, not enabled in the distribution.

The store must be outside ALL agent-writable sandbox roots. Mode 0700 alone
is not an authorization boundary against a process running as the same user.
The MCP client is trusted to deliver human responses; this is not authentication.
"""
import json
import sqlite3
import time
from pathlib import Path

from tooluseproxy.engine.human_review import fingerprint


def target_key(payload):
    fields = ('session_id', 'tool_use_id', 'tool_name', 'tool_input')
    if any(k not in payload for k in fields):
        raise ValueError('missing_review_identity')
    if any(not isinstance(payload[k], str) or not payload[k] for k in fields[:3]):
        raise ValueError('invalid_review_identity')
    return fingerprint({k: payload[k] for k in fields})


def initialize(path):
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with sqlite3.connect(path, timeout=1) as db:
        db.execute('CREATE TABLE IF NOT EXISTS receipts (key TEXT PRIMARY KEY, state TEXT NOT NULL, expires REAL NOT NULL)')
    path.chmod(0o600)


def publish(path, payload, allowed, *, lifetime=30):
    key = target_key(payload)
    with sqlite3.connect(path, timeout=1) as db:
        # First result wins, including an expiry tombstone written by the guard.
        db.execute('INSERT OR IGNORE INTO receipts VALUES (?,?,?)',
                   (key, 'accepted' if allowed else 'denied', time.time() + lifetime))


def consume(path, payload, *, timeout=30):
    key = target_key(payload)
    deadline = time.monotonic() + timeout
    while True:
        with sqlite3.connect(path, timeout=1) as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT state, expires FROM receipts WHERE key=?', (key,)).fetchone()
            if row:
                db.execute('UPDATE receipts SET state=? WHERE key=?', ('consumed', key))
                return row[0] == 'accepted' and row[1] > time.time()
            if time.monotonic() >= deadline:
                db.execute('INSERT INTO receipts VALUES (?,?,?)', (key, 'expired', time.time()))
                return False
        time.sleep(0.025)


def main():
    import argparse
    import sys
    ap = argparse.ArgumentParser(description='Experimental fail-closed review guard')
    ap.add_argument('--store', type=Path, required=True)
    ap.add_argument('--timeout', type=float, default=30)
    args = ap.parse_args()
    allowed = False
    try:
        if not 0 < args.timeout <= 120:
            raise ValueError('invalid_wait')
        raw = sys.stdin.buffer.read(65537)
        if len(raw) > 65536:
            raise ValueError('oversize')
        allowed = consume(args.store, json.loads(raw), timeout=args.timeout)
    except Exception:
        pass  # Storage errors, malformed input, and absent service all deny.
    output = {} if allowed else {'hookSpecificOutput': {
        'hookEventName': 'PreToolUse', 'permissionDecision': 'deny',
        'permissionDecisionReason': 'ToolUseProxy: 今回の操作の確認が完了しなかったため停止しました。'}}
    print(json.dumps(output, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
