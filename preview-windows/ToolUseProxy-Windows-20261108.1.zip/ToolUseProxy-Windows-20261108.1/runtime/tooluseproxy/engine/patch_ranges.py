"""Exact patch replay for evidence ranges, never a semantic independence proof.

Unsupported/fuzzy/ambiguous patches return None and retain normal resolution.
The caller must authenticate both input and resulting generations before using
these ranges. No filesystem access or model decision happens in this module.
"""
from dataclasses import dataclass


MAX_BYTES = 4_194_304
MAX_HUNKS = 64


@dataclass(frozen=True)
class Range:
    output_offset: int
    length: int
    source: str  # before or patch
    source_offset: int


@dataclass(frozen=True)
class Replay:
    content: bytes
    ranges: tuple[Range, ...]


def update_sections(patch: bytes):
    """Validated per-file update slices with offsets into the original ToolCall."""
    from tooluseproxy.engine.resource_contracts import patch_resources
    if not isinstance(patch, bytes) or len(patch) > MAX_BYTES:
        return []
    try:
        text = patch.decode('utf-8')
    except UnicodeDecodeError:
        return []
    if patch_resources('apply_patch', text) is None or b'\r' in patch:
        return []
    prefix = b'*** Begin Patch\n'
    headers, offset = [], 0
    for line in patch.splitlines(keepends=True):
        if line.startswith((b'*** Add File: ', b'*** Update File: ', b'*** Delete File: ', b'*** End Patch')):
            headers.append((offset, line.rstrip(b'\n')))
        offset += len(line)
    sections = []
    for (start, header), (end, _) in zip(headers, headers[1:]):
        if not header.startswith(b'*** Update File: '):
            continue
        body = patch[start:end]
        lines = body.splitlines()
        source = header[len(b'*** Update File: '):].decode()
        target = (lines[1][len(b'*** Move to: '):].decode()
                  if len(lines) > 1 and lines[1].startswith(b'*** Move to: ') else source)
        sections.append(dict(source=source, target=target,
                             patch=prefix + body + b'*** End Patch', delta=start-len(prefix)))
    return sections


def replay_section(before: bytes, section) -> Replay | None:
    result = replay_update(before, section['patch'])
    if result is None:
        return None
    return Replay(result.content, tuple(Range(r.output_offset, r.length, r.source,
        r.source_offset + (section['delta'] if r.source == 'patch' else 0)) for r in result.ranges))


def replay_update(before: bytes, patch: bytes) -> Replay | None:
    """Replay one literal LF update with unique exact context, optionally moved.

    Ranges describe byte copying only. A preserved expression can change meaning
    when its definitions change; consumers must not treat it as an allow verdict.
    Caps bound this optional analysis. Refusal is not a protection decision.
    """
    if (not isinstance(before, bytes) or not isinstance(patch, bytes)
            or len(before) > MAX_BYTES or len(patch) > MAX_BYTES
            or b'\r' in before or b'\r' in patch or b'\x00' in before or b'\x00' in patch
            or (before and not before.endswith(b'\n'))):
        return None
    try:
        before.decode('utf-8')
        patch.decode('utf-8')
    except UnicodeDecodeError:
        return None
    # Only this terminal newline is optional. File contents retain their newline.
    raw = patch[:-1] if patch.endswith(b'\n') else patch
    lines = raw.split(b'\n')
    if (len(lines) < 5 or lines[0] != b'*** Begin Patch'
            or not lines[1].startswith(b'*** Update File: ')
            or not lines[1][len(b'*** Update File: '):]
            or lines[-1] != b'*** End Patch'):
        return None
    offsets, position = [], 0
    for line in lines:
        offsets.append(position)
        position += len(line) + 1
    start = 2
    if lines[start].startswith(b'*** Move to: '):
        if not lines[start][len(b'*** Move to: '):]:
            return None
        start += 1
    hunks, active = [], None
    for index in range(start, len(lines) - 1):
        line = lines[index]
        if line == b'@@' or line.startswith(b'@@ '):
            if len(hunks) >= MAX_HUNKS:
                return None
            active = []
            hunks.append(active)
        elif active is not None and line[:1] in (b' ', b'+', b'-'):
            active.append((line[:1], line[1:] + b'\n', offsets[index] + 1))
        else:
            return None
    if not hunks or any(not h for h in hunks):
        return None
    output, ranges, cursor = bytearray(), [], 0

    def append(value, source, source_offset):
        if not value:
            return
        offset = len(output)
        output.extend(value)
        if (ranges and ranges[-1].source == source
                and ranges[-1].output_offset + ranges[-1].length == offset
                and ranges[-1].source_offset + ranges[-1].length == source_offset):
            last = ranges[-1]
            ranges[-1] = Range(last.output_offset, last.length + len(value), source, last.source_offset)
        else:
            ranges.append(Range(offset, len(value), source, source_offset))

    for hunk in hunks:
        old = b''.join(value for mode, value, _ in hunk if mode != b'+')
        # No positional proof exists for context-free insertion here.
        if not old:
            return None
        found = before.find(old, cursor)
        if (found < 0 or before.find(old) != found
                or (found and before[found - 1:found] != b'\n')
                or before.find(old, found + 1) >= 0):
            return None
        append(before[cursor:found], 'before', cursor)
        source_cursor = found
        for mode, value, patch_offset in hunk:
            if mode == b' ':
                append(value, 'before', source_cursor)
            elif mode == b'+':
                append(value, 'patch', patch_offset)
            if mode != b'+':
                source_cursor += len(value)
        cursor = source_cursor
        if len(output) > MAX_BYTES:
            return None
    append(before[cursor:], 'before', cursor)
    if len(output) > MAX_BYTES:
        return None
    return Replay(bytes(output), tuple(ranges))
