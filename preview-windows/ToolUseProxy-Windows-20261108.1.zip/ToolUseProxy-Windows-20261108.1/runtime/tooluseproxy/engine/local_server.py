"""Authenticated loopback HTTP adapter for bounded local inference requests.

Only main() imports the optional Kev environment. No model package is required
to use or test the HTTP protocol with a synthetic inference function.
"""
from __future__ import annotations

import base64
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import re
import secrets
import threading

from tooluseproxy.engine.local_requests import RequestError, RequestRegistry

PROTOCOL = 'tooluseproxy-requests-v1'


class LocalServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, *, key, infer, metadata, max_connections=16, **limits):
        if address[0] != '127.0.0.1' or not re.fullmatch('[a-f0-9]{64}', key) or max_connections < 1:
            raise ValueError('invalid_local_server_configuration')
        self.key, self.metadata = key, metadata
        self.instance = secrets.token_hex(16)
        self.slots = threading.BoundedSemaphore(max_connections)
        # Bind before starting a worker; bind failure must not leak a thread.
        super().__init__(address, Handler)
        try:
            self.registry = RequestRegistry(infer, **limits)
        except Exception:
            super().server_close()
            raise

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            # No per-connection thread or evidence parsing when saturated.
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

    def handle_error(self, request, client_address):
        # Standard handler tracebacks may contain model/input diagnostics.
        pass

    def server_close(self):
        self.registry.close()
        super().server_close()


class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *_):
        pass

    def _reply(self, status, data):
        raw = json.dumps(data, separators=(',', ':')).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Connection', 'close')
        self.end_headers()
        self.close_connection = True
        try:
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            pass  # Losing an acknowledgement does not cancel accepted work.

    def _dispatch(self):
        auth = self.headers.get_all('Authorization', [])
        if len(auth) != 1 or not hmac.compare_digest(auth[0], 'Bearer '+self.server.key):
            return self._reply(401, {'error': 'unauthorized'})
        # Never accept browser-origin calls, including requests from other local pages.
        if self.headers.get('Origin') is not None:
            return self._reply(403, {'error': 'origin_forbidden'})
        if self.headers.get('Transfer-Encoding') is not None:
            return self._reply(400, {'error': 'unsupported_transfer_encoding'})
        lengths = self.headers.get_all('Content-Length', [])
        if len(lengths) > 1 or (lengths and not re.fullmatch('[0-9]{1,8}', lengths[0])):
            return self._reply(400, {'error': 'invalid_content_length'})
        length = int(lengths[0]) if lengths else 0
        if length > self.server.registry.max_request_bytes:
            return self._reply(413, {'error': 'request_invalid_size'})
        if self.command != 'PUT' and length:
            return self._reply(400, {'error': 'unexpected_body'})
        try:
            if self.command == 'GET' and self.path == '/v1/models':
                return self._reply(200, dict(self.server.metadata(), request_protocol=PROTOCOL,
                                             runtime_instance=self.server.instance))
            if self.command == 'POST' and self.path == '/v1/requests':
                return self._reply(201, {'handle': self.server.registry.reserve(),
                                         'runtime_instance': self.server.instance})
            match = re.fullmatch('/v1/requests/([A-Za-z0-9_-]{43})', self.path)
            if match and self.command in ('GET', 'PUT', 'DELETE'):
                handle = match.group(1)
                if self.command == 'DELETE':
                    self.server.registry.acknowledge(handle)
                    return self._reply(200, {'state': 'released'})
                if self.command == 'PUT':
                    payload = self.rfile.read(length)
                    if len(payload) != length:
                        return self._reply(400, {'error': 'incomplete_body'})
                    result = self.server.registry.submit(handle, payload)
                else:
                    result = self.server.registry.status(handle)
                if result['result'] is not None:
                    result['result'] = base64.b64encode(result['result']).decode('ascii')
                return self._reply(200, result)
        except RequestError as error:
            code = str(error)
            status = {'runtime_busy': 429, 'request_missing_or_expired': 410,
                      'request_content_conflict': 409, 'request_still_active': 409,
                      'runtime_closed': 503}.get(code, 400)
            return self._reply(status, {'error': code})
        return self._reply(404, {'error': 'not_found'})

    do_GET = _dispatch
    do_POST = _dispatch
    do_PUT = _dispatch
    do_DELETE = _dispatch


def main():
    import argparse
    from dataclasses import replace
    import os
    # Imported only in the separately prepared optional model environment.
    from kev import serve

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True)
    parser.add_argument('--host', choices=['127.0.0.1'], default='127.0.0.1')
    parser.add_argument('--port', type=int, required=True)
    args = parser.parse_args()
    options = replace(serve.LoadOptions.from_env(), backend='mlx', dtype=serve.torch.bfloat16)
    checkpoint = serve.Checkpoint(args.run)
    device = serve.default_device()
    tokenizer, model = checkpoint.load(device, options)
    engine = serve.Server(checkpoint, tokenizer, model, device, truncate_states=False)
    serve.app.state.server = engine  # Reuse its model-card implementation only.

    def infer(payload):
        request = serve.SystemOneRequest.model_validate_json(payload)
        return json.dumps(engine.answer(request), ensure_ascii=False).encode()

    server = None
    try:
        server = LocalServer((args.host, args.port), key=os.environ['KEV_API_KEY'],
                             infer=infer, metadata=serve.models)
        server.serve_forever()
    finally:
        if server is not None:
            server.server_close()
        engine.close()


if __name__ == '__main__':
    main()
