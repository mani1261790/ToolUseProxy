"""Companion MCP Hook. The existing command Hook owns the actual decision.

Only controller-created requests may elicit approval. Tool arguments cannot
create approvals; answers arrive over the host MCP elicitation channel.
"""
import argparse
import json
import os
from pathlib import Path
import re
import selectors
import shlex
import sys
import time

from tooluseproxy.engine import approval_bridge as bridge
from tooluseproxy.engine.human_review import HumanReview


def review_message(context):
    def short(value, limit):
        line = ' '.join(str(value).splitlines())
        if len(line) <= limit:
            return line
        return line[:limit//2] + '…' + line[-(limit-limit//2-1):]

    operation = context['operation']
    action = short(context.get('tool') or 'ツール', 55) + ' を実行'
    cmd = operation.get('cmd', operation.get('command'))
    if isinstance(cmd, list) and all(isinstance(v, str) for v in cmd):
        cmd = shlex.join(cmd)
    if isinstance(cmd, str) and cmd.strip():
        if re.fullmatch(r'(?:/usr/bin/)?git push [\w./-]+(?: [\w./:-]+)?', cmd):
            action = short(cmd, 72)
        elif re.match(r'^(?:/usr/bin/)?curl(?: |$)', cmd) and not re.search(r'[;&|\n`$<>]', cmd):
            action = 'curl で送信'
        else:
            action = short(cmd, 72)
    # Quote argument arrays individually. Keep all other fields visible:
    # a tool can specify the destination separately from the command.
    lines = []
    for key, value in operation.items():
        if key in ('cmd', 'command'):
            if isinstance(value, list) and all(isinstance(v, str) for v in value):
                value = shlex.join(value)
            label = 'コマンド'
        else:
            label = key
        lines.append(f'{label}: {value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)}')
    def resource_name(r):
        if r.get('kind') == 'repository_object':
            prefix = f"Git {r.get('revision')}（{str(r.get('head') or '')[:12]}）"
            return prefix + ': ' + ('、'.join(r.get('paths') or [])
                or {'commit': 'コミット情報', 'tree': 'ディレクトリ情報'}.get(r.get('object_kind'), 'Gitオブジェクト'))
        if r.get('path'):
            return r['path']
        origin = {'event_input': 'コマンド・ツールに直接入力した内容',
                  'event_output': '以前のツールの出力',
                  'invocation_context': '実行時の設定値'}.get(r.get('kind'), 'ツールの入力')
        return origin + (f"（{r['pointer']}）" if r.get('pointer') else '')
    resources = [resource_name(r) for r in context['resources']]
    names = list(dict.fromkeys(resources))
    target = short(names[0], 70) if len(names) == 1 else (
        f'送信対象 {len(names)} 件' if names else '対象名不明')
    if context['reason'] == 'protected_content_match':
        matches = context.get('matches', [])
        if matches:
            m = matches[0]
            route = f"{short(m['source'], 70)} → {short(resources[m['resource']], 70)} → {action}"
            if len(matches) > 1:
                route += f"（ほか {len(matches)-1} 件の一致）"
        else:
            route = '一致元の名前は不明'
        reason = '送信内容の一部が保護ファイルと一致したため、送信を保留しています。'
    else:
        steps = context.get('route', [])
        route = (short(steps[0], 70) + (' → …' if len(steps) > 2 else '') + ' → '
                 + target + ' → ' + action) if steps else '経路の詳細は不明'
        reason = '保護ファイルをもとにした内容が含まれる可能性があるため、送信を保留しています。'
    operation_text = ' / '.join(lines)
    shortened = len(' '.join(operation_text.splitlines())) > 180
    return ('この送信を今回だけ許可しますか？\n'
            + reason + '\n' + route + '\n'
            + short(operation_text, 180) + '\n'
            + ('操作は一部省略しています。許可する前にログで全文を確認してください。\n' if shortened else '')
            + '詳しくはログ画面でこの操作を選んでください（Codexに「ログを見せて」）。')



def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve(strict=True)
    bridge.control_path(root)
    pending = None
    form = False
    selector = selectors.DefaultSelector()
    selector.register(sys.stdin, selectors.EVENT_READ)
    buffered = b''

    def send(value):
        print(json.dumps(dict(jsonrpc='2.0', **value), ensure_ascii=False), flush=True)

    def finish(call_id):
        # Never authorize a tool: only the command Hook can consume a receipt.
        send({'id': call_id, 'result': {'content': [{'type': 'text', 'text': '{}'}]}})

    while True:
        if pending:
            if time.monotonic() >= pending['deadline']:
                if pending.get('nonce'):
                    bridge.answer(root, pending['payload'], pending['nonce'], False)
                finish(pending['id'])
                pending = None
            elif (pending.get('review')
                  and pending['review'].clock() >= pending['review'].deadline):
                bridge.answer(root, pending['payload'], pending['nonce'], False)
                finish(pending['id'])
                pending = None
            elif not pending.get('review'):
                row = bridge.load(root, pending['payload'])
                if row and row['state'] != 'waiting':
                    finish(pending['id'])
                    pending = None
                elif row:
                    remaining = row['expires'] - time.time()
                    if remaining <= 0 or not form:
                        bridge.answer(root, pending['payload'], row['nonce'], False)
                        finish(pending['id'])
                        pending = None
                    else:
                        target = dict(call_key=bridge.target_key(pending['payload']),
                                      review_nonce=row['nonce'], context_digest=bridge.digest(row['context']))
                        review = HumanReview(target, lifetime=min(remaining, 90))
                        pending.update(review=review, target=target, nonce=row['nonce'])
                        message = review_message(row['context'])
                        send({'id': review.request_id, 'method': 'elicitation/create',
                              'params': review.form(message)})
        if b'\n' not in buffered:
            if not selector.select(.05):
                continue
            chunk = os.read(sys.stdin.fileno(), 65537)
            if not chunk:
                return 0
            buffered += chunk
            if b'\n' not in buffered:
                if len(buffered) > 65536:
                    return 1
                continue
        raw, buffered = buffered.split(b'\n', 1)
        if len(raw) > 65536:
            return 1
        msg = json.loads(raw)
        method = msg.get('method')
        if method == 'initialize':
            cap = msg.get('params', {}).get('capabilities', {}).get('elicitation')
            form = isinstance(cap, dict) and (not cap or 'form' in cap)
            send({'id': msg['id'], 'result': {'protocolVersion': msg['params']['protocolVersion'],
                  'serverInfo': {'name': 'tooluseproxy-human-review', 'version': '0.1.0'},
                  'capabilities': {'tools': {}}}})
        elif method == 'tools/list':
            send({'id': msg['id'], 'result': {'tools': [{'name': 'review',
                  'description': 'Wait for a controller-created review; never grants permission directly.',
                  'inputSchema': {'type': 'object', 'properties': {'payload': {'type': 'object'}},
                                  'required': ['payload'], 'additionalProperties': False}}]}})
        elif method == 'tools/call':
            params = msg.get('params', {})
            arguments = params.get('arguments', {})
            if pending or params.get('name') != 'review' or set(arguments) != {'payload'}:
                finish(msg['id'])
                continue
            payload = arguments['payload']
            bridge.target_key(payload)
            if Path(payload.get('cwd', '')).resolve() != root:
                finish(msg['id'])
                continue
            pending = dict(id=msg['id'], payload=payload, deadline=time.monotonic()+600)
        elif method == 'notifications/cancelled' and pending:
            if msg.get('params', {}).get('requestId') == pending['id']:
                if pending.get('nonce'):
                    bridge.answer(root, pending['payload'], pending['nonce'], False)
                finish(pending['id'])
                pending = None
        elif method is None and pending and pending.get('review'):
            allowed = pending['review'].resolve(msg, pending['target'])
            bridge.answer(root, pending['payload'], pending['nonce'], allowed)
            finish(pending['id'])
            pending = None
        elif method == 'ping':
            send({'id': msg['id'], 'result': {}})
        elif method and 'id' in msg:
            send({'id': msg['id'], 'error': {'code': -32601, 'message': 'Unsupported'}})


if __name__ == '__main__':
    raise SystemExit(main())
