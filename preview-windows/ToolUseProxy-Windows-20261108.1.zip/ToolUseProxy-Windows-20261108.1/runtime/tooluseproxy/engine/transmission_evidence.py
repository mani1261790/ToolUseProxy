"""Bind pre-execution payload observations to their own completed ToolCall.

This is historical evidence, never a permission or proof of remote delivery.
The decision and snapshot are persisted in one transaction by the runtime.
"""
import json

from tooluseproxy.engine.graph import digest


FIELDS = ('workspace_id', 'session_id', 'tool_use_id', 'tool_name', 'workspace_root',
          'workspace_execution_cwd')


def schema(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS flow_transmission_observations (
        scope TEXT NOT NULL,event TEXT PRIMARY KEY,identity_hash TEXT NOT NULL,
        evidence_json TEXT NOT NULL,evidence_hash TEXT NOT NULL)''')
    conn.execute('''CREATE INDEX IF NOT EXISTS transmission_call_events
        ON events(workspace_id,session_id,tool_use_id,phase,sequence_no)''')


def identity(row):
    *fields, raw = row
    return digest([fields, json.loads(raw).get('tool_input')])


def save(conn, event, evidence):
    schema(conn)
    row = conn.execute('SELECT ' + ','.join(FIELDS) + ',payload_json FROM events WHERE event_id=? AND phase=?',
                       (event.event_id, 'pre_tool_use')).fetchone()
    if row is None or row[0] != event.workspace_id:
        raise ValueError('transmission_event_missing')
    encoded = json.dumps(evidence, ensure_ascii=False, sort_keys=True)
    conn.execute('INSERT OR REPLACE INTO flow_transmission_observations VALUES (?,?,?,?,?)',
                 (event.workspace_id, event.event_id, identity(row), encoded, digest(evidence)))


def load(conn, workspace, node):
    if not node.get('completed'):
        return
    post = conn.execute('SELECT ' + ','.join(FIELDS) + ',payload_json,sequence_no FROM events '
                        'WHERE event_id=? AND phase=? AND workspace_id=?',
                        (node['event_id'], 'post_tool_use', workspace)).fetchone()
    if post is None:
        return
    boundary = 0
    if conn.execute("SELECT 1 FROM sqlite_master WHERE name='recording_boundaries'").fetchone():
        row = conn.execute('SELECT after_sequence FROM recording_boundaries WHERE workspace_id=?',
                           (workspace,)).fetchone()
        boundary = row[0] if row else 0
    rows = conn.execute('''SELECT e.event_id,t.identity_hash,t.evidence_json,t.evidence_hash,
        e.workspace_id,e.session_id,e.tool_use_id,e.tool_name,e.workspace_root,
        e.workspace_execution_cwd,e.payload_json FROM events e
        JOIN flow_transmission_observations t ON t.event=e.event_id AND t.scope=e.workspace_id
        JOIN semantic_flow_decisions d ON d.event_id=e.event_id
        WHERE e.workspace_id=? AND e.session_id=? AND e.tool_use_id=? AND e.phase='pre_tool_use'
        AND e.sequence_no>? AND e.sequence_no<? AND d.action='allow' ''',
        (workspace, post[1], post[2], boundary, post[-1])).fetchall()
    # Do not guess between redelivered or conflicting operation identities.
    if len(rows) != 1:
        return
    event, saved_identity, encoded, expected, *pre = rows[0]
    if saved_identity != identity(pre) or saved_identity != identity(post[:-1]):
        return
    evidence = json.loads(encoded)
    if digest(evidence) != expected:
        return
    return dict(event_id=event,
        temporal_scope='observed_before_execution_not_remote_delivery', **evidence)


def attach(conn, workspace, node):
    node.pop('pre_execution_payload', None)
    node.pop('pre_execution_payload_ref', None)
    evidence = load(conn, workspace, node)
    if evidence is not None:
        # Do not duplicate every historical payload in every model request.
        node['pre_execution_payload_ref'] = dict(event_id=evidence['event_id'],
                                                evidence_hash=digest(evidence))
