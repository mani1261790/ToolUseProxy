"""Project-owned runtime state. No protected-source manifest is read here."""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from tooluseproxy.paths import PathConfigurationError, RuntimePaths

DIRECTORY = ".tooluseproxy"


def project_paths(root: Path) -> RuntimePaths:
    root = root.resolve(strict=True)
    directory = root / DIRECTORY
    if directory.is_symlink() or (directory.exists() and not directory.is_dir()):
        raise PathConfigurationError("project_storage_invalid")
    if (directory / "events.db").is_symlink():
        raise PathConfigurationError("project_database_symlink")
    return RuntimePaths(directory, directory / "events.db", "project")


def discover_project(cwd: str | Path) -> Path:
    candidate = Path(cwd).resolve(strict=True)
    for root in (candidate, *candidate.parents):
        if (root / DIRECTORY).exists() or (root / DIRECTORY).is_symlink():
            project_paths(root)  # reject symlink storage, including broken links
            return root
        if (root / ".git").exists() or (root / ".git").is_symlink():
            return root
    return candidate


def legacy_workspace_exists(database: Path, root: Path) -> bool:
    if not database.exists():
        return False
    from tooluseproxy.engine.workspace import make_workspace_id
    with sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True) as conn:
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "workspaces" not in tables:
            return False
        return conn.execute("SELECT 1 FROM workspaces WHERE workspace_id=?",
                            (make_workspace_id(str(root)),)).fetchone() is not None


def require_new_project_storage(local: RuntimePaths, legacy: RuntimePaths, root: Path):
    if local.db_path.exists():
        return
    if legacy_workspace_exists(legacy.db_path, root):
        raise PathConfigurationError("legacy_project_storage_requires_reconfiguration")


def prepare_project(root: Path):
    """Ignore runtime state before any DB/config is created; retain user patterns."""
    paths = project_paths(root)
    ignore = root / ".gitignore"
    if ignore.is_symlink():
        raise PathConfigurationError("gitignore_symlink")
    text = ignore.read_text() if ignore.exists() else ""
    # Append even after negations: project state must remain ignored.
    if not text.endswith("/.tooluseproxy/\n"):
        with ignore.open("a", encoding="utf-8") as stream:
            stream.write(("\n" if text and not text.endswith("\n") else "") + "/.tooluseproxy/\n")
    paths.data_dir.mkdir(mode=0o700, exist_ok=True)
    if os.name == "posix":
        paths.data_dir.chmod(0o700)


def hook_paths(cwd: str, legacy_dir: Path | None = None) -> RuntimePaths:
    from tooluseproxy.integrations.activation import enabled_workspace_root
    root = discover_project(cwd)
    if (root / DIRECTORY).exists():
        return project_paths(root)
    if legacy_dir is None:
        return project_paths(root)
    legacy_root = enabled_workspace_root(legacy_dir / "events.db", cwd)
    if legacy_root is not None and not (root / DIRECTORY).exists():
        root = Path(legacy_root)
    local = project_paths(root)
    legacy = RuntimePaths(legacy_dir, legacy_dir / "events.db", "legacy")
    require_new_project_storage(local, legacy, root)
    return local
