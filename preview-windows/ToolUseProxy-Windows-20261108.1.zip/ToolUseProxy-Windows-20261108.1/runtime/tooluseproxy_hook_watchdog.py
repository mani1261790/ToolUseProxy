#!/usr/bin/env python3
"""Bound the model-driven Hook. A timeout is not a leak finding."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import BinaryIO, Sequence

PRE_TOOL_CHILD_TIMEOUT_SECONDS = 720.0


def run_child(
    command: Sequence[str],
    *,
    phase: str,
    stdin: BinaryIO,
    stdout: BinaryIO,
    timeout_seconds: float = PRE_TOOL_CHILD_TIMEOUT_SECONDS,
    timing_sink=None,
) -> int:
    """Observe the child envelope, not shell startup or host delivery latency."""
    started = time.monotonic_ns()
    invocation = uuid.uuid4().hex
    recorded_phase = phase if phase in (
        "session-start", "subagent-start", "pre-tool-use", "post-tool-use", "stop"
    ) else "other"
    receipt = {"invocation": invocation, "phase": recorded_phase, "outcome": "interrupted"}
    env = None
    if timing_sink is not None:
        env = dict(os.environ, TOOLUSEPROXY_HOOK_INVOCATION=invocation)
    try:
        return _run_child(command, phase=phase, stdin=stdin, stdout=stdout,
                          timeout_seconds=timeout_seconds, receipt=receipt, env=env)
    finally:
        receipt["duration_ms"] = (time.monotonic_ns() - started) / 1_000_000
        if timing_sink is not None:
            try:
                timing_sink(receipt)
            except Exception:
                pass  # Missing telemetry is unknown; never change permission.


def _run_child(command, *, phase, stdin, stdout, timeout_seconds, receipt, env):
    try:
        with subprocess.Popen(
            list(command), stdin=stdin, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, start_new_session=os.name == "posix",
            env=env,
        ) as child:
            try:
                output, _ = child.communicate(timeout=timeout_seconds)
            except subprocess.TimeoutExpired:
                # Terminate descendants that share the Hook group. The Codex
                # transport owns a separate group and its own bounded timeout.
                if os.name == "posix":
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                else:
                    child.kill()
                child.communicate()
                raise
            completed = subprocess.CompletedProcess(command, child.returncode, output)
    except (subprocess.TimeoutExpired, OSError) as error:
        reason = "semantic_watchdog_timeout" if isinstance(error, subprocess.TimeoutExpired) else "semantic_start_failed"
        receipt["outcome"] = reason
        return pending_output(stdout, phase, reason)
    if phase == "pre-tool-use":
        if completed.returncode:
            receipt["outcome"] = "semantic_child_failed"
            return pending_output(stdout, phase, "semantic_child_failed")
        try:
            value = json.loads(completed.stdout)
            if not isinstance(value, dict):
                raise ValueError()
            if value:
                details = value["hookSpecificOutput"]
                if (details.get("hookEventName") != "PreToolUse"
                        or details.get("permissionDecision") != "deny"):
                    raise ValueError()
        except (ValueError, KeyError, TypeError, AttributeError):
            receipt["outcome"] = "semantic_child_invalid_response"
            return pending_output(stdout, phase, "semantic_child_invalid_response")
    stdout.write(completed.stdout)
    stdout.flush()
    receipt["outcome"] = "returned" if completed.returncode == 0 else "semantic_child_failed"
    return completed.returncode


def pending_output(stdout, phase, reason):
    output = {}
    if phase == "pre-tool-use":
        output = {"hookSpecificOutput": {
            "hookEventName": "PreToolUse", "permissionDecision": "deny",
            "permissionDecisionReason": "ToolUseProxyは判定完了まで実行を保留しています。"
            "流出検出ではありません。復旧後に再検査してください。（" + reason + "）",
        }}
    stdout.write((json.dumps(output, ensure_ascii=False) + "\n").encode())
    return 0


def main(argv=None):
    arguments = list(sys.argv[1:] if argv is None else argv)
    if len(arguments) != 3 or arguments[1] not in ("--data-dir", "--project-data"):
        return 2
    if arguments[1] == "--project-data":
        import tempfile
        from tooluseproxy.project_storage import hook_paths
        raw = sys.stdin.buffer.read(1024 * 1024 + 1)
        try:
            payload = json.loads(raw)
            if len(raw) > 1024 * 1024 or not isinstance(payload, dict):
                raise ValueError("invalid_payload")
            paths = hook_paths(payload.get("cwd") or os.getcwd(),
                               Path(arguments[2]) if arguments[2] else None)
        except Exception:
            return pending_output(sys.stdout.buffer, arguments[0], "project_storage_unavailable")
        with tempfile.TemporaryFile() as incoming:
            incoming.write(raw)
            incoming.seek(0)
            return run_child(
                [sys.executable, str(Path(__file__).resolve().parent / "tooluseproxy_plugin.py"),
                 "hook", arguments[0], "--data-dir", str(paths.data_dir)],
                phase=arguments[0], stdin=incoming, stdout=sys.stdout.buffer,
                timing_sink=(lambda receipt: record_timing(paths.data_dir, receipt))
                if os.environ.get("TOOLUSEPROXY_HOOK_TIMING") == "1" else None)
    root = Path(__file__).resolve().parent
    sink = None
    if os.environ.get("TOOLUSEPROXY_HOOK_TIMING") == "1":
        def sink(receipt):
            record_timing(Path(arguments[2]), receipt)
    return run_child(
        [sys.executable, str(root / "tooluseproxy_plugin.py"), "hook", *arguments],
        phase=arguments[0],
        stdin=sys.stdin.buffer,
        stdout=sys.stdout.buffer,
        timing_sink=sink,
    )


def record_timing(data_dir, receipt):
    """Opt-in, content-free diagnostics, separate from the protection database.

    No directory creation, payload parsing, or interpretation of missing rows as
    zero duration. Storage overhead follows the measured interval.
    """
    import sqlite3
    with sqlite3.connect(data_dir / "hook-timings.db", timeout=0.05) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS hook_timings (
            invocation TEXT PRIMARY KEY, phase TEXT NOT NULL, outcome TEXT NOT NULL,
            duration_ms REAL NOT NULL, recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        conn.execute("INSERT INTO hook_timings(invocation,phase,outcome,duration_ms) VALUES(?,?,?,?)",
                     tuple(receipt[k] for k in ("invocation", "phase", "outcome", "duration_ms")))


if __name__ == "__main__":
    raise SystemExit(main())
