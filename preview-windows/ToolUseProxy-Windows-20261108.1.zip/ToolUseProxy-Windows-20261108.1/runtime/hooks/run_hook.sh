#!/bin/sh

phase=${1:-}

workspace_may_be_enabled() {
    candidate=$(pwd -P 2>/dev/null) || return 1
    # Local state must fail closed even when Python cannot start.
    while :; do
        [ -e "$candidate/.tooluseproxy" ] || [ -L "$candidate/.tooluseproxy" ] && return 0
        [ -e "$candidate/.git" ] && break
        [ "$candidate" = "/" ] && break
        candidate=${candidate%/*}
        [ -n "$candidate" ] || candidate=/
    done
    candidate=$(pwd -P 2>/dev/null) || return 1
    activation_dir=${PLUGIN_DATA:-}/events.db.workspaces
    if [ -n "${PLUGIN_DATA:-}" ] && [ -d "$activation_dir" ]; then
        has_any_marker=0
        for marker in "$activation_dir"/ws_v1_*.json; do
            if [ -f "$marker" ]; then
                has_any_marker=1
                break
            fi
        done
        while :; do
            if command -v shasum >/dev/null 2>&1; then
                hash_output=$(printf '%s' "$candidate" | shasum -a 256) || return 1
            elif [ -x /usr/bin/shasum ]; then
                hash_output=$(printf '%s' "$candidate" | /usr/bin/shasum -a 256) || return 1
            elif command -v sha256sum >/dev/null 2>&1; then
                hash_output=$(printf '%s' "$candidate" | sha256sum) || return 1
            else
                return 1
            fi
            digest=${hash_output%% *}
            [ -f "$activation_dir/ws_v1_$digest.json" ] && return 0
            if [ -e "$candidate/.git" ] || [ -L "$candidate/.git" ]; then
                break
            fi
            [ "$candidate" = "/" ] && break
            candidate=${candidate%/*}
            [ -n "$candidate" ] || candidate=/
        done
        [ -f "$activation_dir/migration-v1.complete" ] && return 1
        # A partial old-install migration cannot identify every configured
        # root safely. Fail closed until setup publishes the completion marker.
        [ "$has_any_marker" -eq 1 ] && return 0
        candidate=$(pwd -P 2>/dev/null) || return 1
    fi
    # Compatibility with releases that predate activation markers.
    while :; do
        [ -f "$candidate/protected_sources.json" ] && return 0
        if [ -e "$candidate/.git" ] || [ -L "$candidate/.git" ]; then
            return 1
        fi
        [ "$candidate" = "/" ] && return 1
        candidate=${candidate%/*}
        [ -n "$candidate" ] || candidate=/
    done
}

emit_inactive() {
    code=$1
    case "$code" in
        plugin_environment)
            message="ToolUseProxy Pluginの設定を読み込めないため、保護機能は動作していません。"
            ;;
        python_missing)
            message="Python 3.11または3.12が見つからないため、ToolUseProxyの保護機能は動作していません。"
            ;;
        *)
            message="ToolUseProxyを開始できなかったため、保護機能は動作していません。"
            ;;
    esac
    case "$phase" in
        session-start)
            printf '{"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":"%s WebSearchなどのhosted toolはToolUseProxyで検査・遮断できません。保護対象やそこから得た内容をhosted toolへ入力しないでください。（技術情報: %s）"}}\n' "$message" "$code"
            ;;
        subagent-start)
            printf '{"hookSpecificOutput":{"hookEventName":"SubagentStart","additionalContext":"%s WebSearchなどのhosted toolはToolUseProxyで検査・遮断できません。保護対象やそこから得た内容をhosted toolへ入力しないでください。（技術情報: %s）"}}\n' "$message" "$code"
            ;;
        pre-tool-use)
            printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"%s 判定完了まで実行を保留します。復旧後に再検査してください。（技術情報: %s）"}}\n' "$message" "$code"
            ;;
        post-tool-use)
            printf '{"hookSpecificOutput":{"hookEventName":"PostToolUse","additionalContext":"%s（技術情報: %s）"}}\n' "$message" "$code"
            ;;
        stop)
            printf '{"systemMessage":"%s（技術情報: %s）"}\n' "$message" "$code"
            ;;
        *)
            printf '%s（技術情報: %s）\n' "$message" "$code" >&2
            ;;
    esac
}

if [ -z "$phase" ] || [ -z "${PLUGIN_ROOT:-}" ]; then
    if workspace_may_be_enabled; then
        emit_inactive "plugin_environment" "PLUGIN_ROOT is required"
    fi
    exit 0
fi

# GUI hosts may inherit only the system PATH. Do not source shell profiles.
for python in "${TOOLUSEPROXY_PYTHON:-}" python3.12 python3.11 python3 \
    /opt/homebrew/bin/python3.12 /opt/homebrew/bin/python3.11 \
    /opt/homebrew/opt/python@3.12/bin/python3.12 \
    /opt/homebrew/opt/python@3.11/bin/python3.11 \
    /usr/local/bin/python3.12 /usr/local/bin/python3.11 \
    "${HOME:-}/.local/bin/python3.12" "${HOME:-}/.local/bin/python3.11" \
    /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 \
    /Library/Frameworks/Python.framework/Versions/3.11/bin/python3.11; do
    if [ -z "$python" ] || ! command -v "$python" >/dev/null 2>&1; then
        continue
    fi
    if ! "$python" -c 'import sys; raise SystemExit(sys.version_info < (3, 11) or sys.version_info >= (3, 13))' >/dev/null 2>&1; then
        continue
    fi
    if output=$(
        "$python" "$PLUGIN_ROOT/tooluseproxy_hook_watchdog.py" \
            "$phase" --project-data "${PLUGIN_DATA:-}" 2>/dev/null
    ); then
        if [ -n "$output" ]; then
            printf '%s\n' "$output"
        fi
        exit 0
    fi
    if workspace_may_be_enabled; then
        emit_inactive \
            "runtime_start_failed" \
            "the local Hook runtime could not start"
    fi
    exit 0
done

if workspace_may_be_enabled; then
    emit_inactive "python_missing" "Python 3.11 or 3.12 is required"
fi
exit 0
