"""Install the tested runtime into an existing project by explicit selection."""
import tomllib, tempfile, re
import argparse, hashlib, json, os, shlex, shutil, subprocess, sys
from pathlib import Path

base = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--workspace', required=True, type=Path)
ap.add_argument('--accept-judge-data', action='store_true', required=True)
ap.add_argument('--protect', type=Path, action='append', default=[])
ap.add_argument('--plan', action='store_true')
args = ap.parse_args()
sys.stdout.reconfigure(encoding='utf-8')
if sys.platform != 'win32' or sys.version_info[:2] not in ((3,11),(3,12)) or not shutil.which('codex'):
    sys.exit('Windows、Python 3.11/3.12、PATH上のCodex CLIを確認してください。')
w = args.workspace.expanduser().resolve()
if not w.is_dir() or (w == Path(w.anchor) or w == Path.home()) or w.is_relative_to(base):
    sys.exit('展開先ではなく、既存プロジェクトのフォルダーを選んでください。')
cfg=w/'.codex/config.toml'
control=w/'.codex/tooluseproxy-review'
data=w/'.tooluseproxy'
ignore=w/'.gitignore'
for f in (w/'.codex',cfg,control,data,ignore):
    if f.is_symlink() or (f.exists() and f.lstat().st_file_attributes & 1024):sys.exit(f'リンク先は変更しません: {f.name}')
if any(f.exists() for f in (control,data,w/'protected_sources.json')):
    sys.exit('既存のToolUseProxy設定があります。上書きや移行は行いません。')
if cfg.exists() and not cfg.is_file() or ignore.exists() and not ignore.is_file():
    sys.exit('設定先が通常のファイルではありません。')
paths=[]
if w.anchor.startswith('\\\\') or any(c in str(w)+sys.executable for c in '%!&|<>^`$;\n\r'):
    sys.exit('試験版では通常のローカルドライブ上の単純なパスを使用してください。')
for f in args.protect:
    target=(w/f).resolve(strict=True)
    if not target.is_relative_to(w) or not target.is_file():sys.exit('プロジェクト内のファイルを指定してください。')
    rel=target.relative_to(w)
    if any(k in ('.git','.codex','.tooluseproxy','protected_sources.json') for k in (x.casefold() for x in rel.parts)):
        sys.exit('管理ファイルは保護対象に指定できません。')
    paths.extend(['--protect',str(rel)])
old=cfg.read_bytes() if cfg.exists() else b''
oldignore=ignore.read_bytes() if ignore.exists() else None
prior=tomllib.loads(old.decode())
if (prior.get('approval_policy','on-request')!='on-request' or
    prior.get('sandbox_mode','workspace-write')!='workspace-write' or
    prior.get('features',{}).get('hooks',True) is not True or
    'tooluseproxy_review' in prior.get('mcp_servers',{}) or
    'tooluseproxy@tooluseproxy' in prior.get('plugins',{}) or 'tooluseproxy' in str(prior.get('hooks',{})).lower()):
    sys.exit('権限やToolUseProxyの既存設定が競合しています。変更していません。')
m = json.loads((base/'runtime-manifest.json').read_text())
for k,h in m.items():
    p=base/'runtime'/k
    if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:
        sys.exit('配布物の整合性を確認できません。')
rt=control/'runtime'
py=str(Path(sys.executable).absolute())
q=lambda v:json.dumps(v,ensure_ascii=False)
config='approval_policy = "on-request"\nsandbox_mode = "workspace-write"\n[features]\nhooks = true\n[plugins."tooluseproxy@tooluseproxy"]\nenabled = false\n'
for event,phase in [('PreToolUse','pre-tool-use'),('SessionStart','session-start'),('SubagentStart','subagent-start'),('PostToolUse','post-tool-use'),('Stop','stop')]:
    pre=event=='PreToolUse'
    cmd=f'"{py}" -X utf8 "{rt / "winhook.py"}" {phase}'
    config+=f'\n[[hooks.{event}]]\n'+('matcher = "^.*$"\n' if event in ('PreToolUse','PostToolUse') else '')+f'[[hooks.{event}.hooks]]\ntype = "command"\ncommand = '+q(cmd)+'\ntimeout = 900\n'
for name in ('approval_policy','sandbox_mode'):
    if name in prior:config=re.sub('^'+name+r' = .*\n','',config,flags=re.M)
settings,sections=config.split('[plugins.',1)
original=old.decode()
if 'features' in prior:
    settings=settings.replace('[features]\nhooks = true\n','')
    if 'hooks' not in prior['features']:
        original,n=re.subn(r'(?m)^(\[features\][ \t]*(?:#[^\n]*)?)$',r'\1\nhooks = true',original,count=1)
        if not n:sys.exit('features 設定を安全に追記できません。変更していません。')
prefix,sep,ft=settings.partition('[features]')
merged=prefix+original+'\n'+sep+ft+'\n[plugins.'+sections
tomllib.loads(merged)
if args.plan:
    print('導入先:',w,'\n登録するファイル:',paths[1::2], '\nプロジェクトの .codex/config.toml にHookを追加し、.tooluseproxy に記録します。既存本文の変更・送信はありません。')
    sys.exit(0)
for k in m:
    dest=rt/k;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/'runtime'/k,dest)
sys.path.insert(0,str(rt))

shutil.copy2(base/'AGENT_INSTALL.md',control/'AGENT_INSTALL.md')
if cfg.exists(): (control/'before-config.toml').write_bytes(old)
if oldignore is not None: (control/'before-gitignore').write_bytes(oldignore)
subprocess.run([py,str(rt/'tooluseproxy_plugin.py'),'setup','--workspace',str(w),'--no-viewer','--accept-judge-data',*paths,'--json'],cwd=w,check=True)
with ignore.open('a') as f:f.write('/.codex/tooluseproxy-review/\n/.codex/config.toml\n')
if (cfg.read_bytes() if cfg.exists() else b'')!=old:sys.exit('他の操作で設定が変わりました。Hookの有効化を中断しました。')
with tempfile.NamedTemporaryFile(dir=cfg.parent,delete=False) as f:
    f.write(merged.encode());tmp=Path(f.name)
os.replace(tmp,cfg)
print('導入完了。対象プロジェクトをCodex Desktopで開き、標準権限で /hooks を確認してください。\n'+str(w))
