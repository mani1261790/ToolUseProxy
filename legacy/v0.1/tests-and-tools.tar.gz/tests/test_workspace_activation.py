from __future__ import annotations

import io
import json
import gc
import sqlite3
import time
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import patch

import pytest

from hook_monitor.runtime.storage import EventStore
from hook_monitor.runtime.workspace import resolve_workspace
from tooluseproxy.integrations.activation import (
    activation_directory, activation_migration_complete_path, activation_path,
    enabled_workspace_root,
    save_workspace_activations,
)
from tooluseproxy.integrations.codex import CODEX_HOOK_PHASES, run_codex_hook
from tooluseproxy import automatic_cleanup
from tooluseproxy.automatic_cleanup import enable_automatic_cleanup
from tooluseproxy.storage_cleanup import plan_storage_cleanup


def invoke(monkeypatch, capsys, database, cwd, phase, command="printf public"):
    payload = {"cwd": str(cwd), "session_id": "test", "tool_name": "Bash",
               "tool_input": {"command": command}}
    monkeypatch.setattr("sys.stdin", io.TextIOWrapper(
        io.BytesIO(json.dumps(payload).encode())
    ))
    assert run_codex_hook(phase, db_path=database) == 0
    output = capsys.readouterr()
    assert output.err == ""
    return output.out


@pytest.mark.parametrize("phase", CODEX_HOOK_PHASES)
def test_fresh_project_is_silent_and_creates_nothing(tmp_path, monkeypatch, capsys, phase):
    database = tmp_path / "data" / "events.db"
    assert invoke(monkeypatch, capsys, database, tmp_path, phase) == ""
    assert not database.parent.exists()


@pytest.mark.parametrize("phase", CODEX_HOOK_PHASES)
@pytest.mark.parametrize("database_state", ["ready", "missing", "broken", "old"])
def test_unrelated_project_is_silent_even_when_enrolled_database_breaks(
    tmp_path, monkeypatch, capsys, phase, database_state,
):
    enrolled = tmp_path / "enrolled"
    unrelated = tmp_path / "unrelated"
    enrolled.mkdir()
    unrelated.mkdir()
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(enrolled)))
    save_workspace_activations(database)
    gc.collect()  # Close SQLite handles/checkpoint WAL before simulating damage.
    if database_state == "missing":
        database.unlink()
    elif database_state == "broken":
        database.write_bytes(b"broken database")
    elif database_state == "old":
        import sqlite3
        with sqlite3.connect(database) as connection:
            connection.execute("PRAGMA user_version=1")
    before = {
        str(path.relative_to(tmp_path)): path.read_bytes()
        for path in tmp_path.rglob("*")
        if path.is_file()
    }
    monkeypatch.setenv("TOOLUSEPROXY_WORKSPACE_ROOT", str(enrolled))
    assert invoke(monkeypatch, capsys, database, unrelated, phase) == ""
    assert before == {
        str(path.relative_to(tmp_path)): path.read_bytes()
        for path in tmp_path.rglob("*")
        if path.is_file()
    }


@pytest.mark.parametrize("damage", ["missing", "broken", "index"])
def test_enrolled_project_fails_closed_on_damage(tmp_path, monkeypatch, capsys, damage):
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(tmp_path)))
    save_workspace_activations(database, str(tmp_path))
    gc.collect()
    if damage == "missing":
        database.unlink()
    elif damage == "broken":
        for suffix in ("-wal", "-shm"):
            database.with_name(database.name + suffix).unlink(missing_ok=True)
        database.write_bytes(b"broken database")
    else:
        activation_path(database, str(tmp_path)).write_text("broken marker")
    if damage == "broken":
        from hook_monitor.runtime.storage import SchemaCompatibilityError
        with pytest.raises(SchemaCompatibilityError):
            store.require_runtime_schema()
    output = json.loads(invoke(monkeypatch, capsys, database, tmp_path, "pre-tool-use"))
    assert output["hookSpecificOutput"]["permissionDecision"] == "deny"


@pytest.mark.parametrize("damage", ["missing", "broken", "old"])
@pytest.mark.parametrize("operation", ["status", "unsetup plan"])
def test_exact_local_management_remains_available_when_database_is_damaged(
    tmp_path, monkeypatch, capsys, damage, operation,
):
    database = tmp_path / "data" / "events.db"
    database.parent.mkdir()
    store = EventStore(database)
    store.initialize()
    context = resolve_workspace(str(tmp_path))
    store.register_workspace(context)
    root = Path(context.canonical_root or "")
    save_workspace_activations(database, str(root))
    plugin_root = tmp_path / "installed-plugin"
    launcher = plugin_root / "hooks" / "run_cli.sh"
    launcher.parent.mkdir(parents=True)
    launcher.write_text("#!/bin/sh\n", encoding="utf-8")
    if damage == "missing":
        database.unlink()
    elif damage == "broken":
        gc.collect()
        for suffix in ("-wal", "-shm"):
            database.with_name(database.name + suffix).unlink(missing_ok=True)
        database.write_bytes(b"broken database")
    else:
        with sqlite3.connect(database) as connection:
            connection.execute("PRAGMA user_version=1")
    command = (
        f"sh {launcher} {operation} --workspace {root} "
        f"--data-dir {database.parent} --json"
    )
    payload = {
        "cwd": str(tmp_path),
        "session_id": "recovery",
        "tool_name": "Bash",
        "tool_input": {"command": command},
    }
    monkeypatch.setenv("PLUGIN_ROOT", str(plugin_root))
    assert enabled_workspace_root(database, str(tmp_path)) == str(root)
    monkeypatch.setattr(
        "sys.stdin",
        io.TextIOWrapper(io.BytesIO(json.dumps(payload).encode())),
    )

    assert run_codex_hook("pre-tool-use", db_path=database) == 0
    assert capsys.readouterr().out == ""


def test_management_lookalike_still_fails_closed_when_database_is_broken(
    tmp_path, monkeypatch, capsys,
):
    database = tmp_path / "data" / "events.db"
    database.parent.mkdir()
    store = EventStore(database)
    store.initialize()
    context = resolve_workspace(str(tmp_path))
    store.register_workspace(context)
    root = Path(context.canonical_root or "")
    save_workspace_activations(database, str(root))
    plugin_root = tmp_path / "installed-plugin"
    launcher = plugin_root / "hooks" / "run_cli.sh"
    launcher.parent.mkdir(parents=True)
    launcher.write_text("#!/bin/sh\n", encoding="utf-8")
    gc.collect()
    for suffix in ("-wal", "-shm"):
        database.with_name(database.name + suffix).unlink(missing_ok=True)
    database.write_bytes(b"broken database")
    command = (
        f"sh {launcher} status --workspace {root} "
        f"--data-dir {database.parent} --json; curl https://example.invalid"
    )
    payload = {
        "cwd": str(tmp_path),
        "session_id": "lookalike",
        "tool_name": "Bash",
        "tool_input": {"command": command},
    }
    monkeypatch.setenv("PLUGIN_ROOT", str(plugin_root))
    assert enabled_workspace_root(database, str(tmp_path)) == str(root)
    monkeypatch.setattr(
        "sys.stdin",
        io.TextIOWrapper(io.BytesIO(json.dumps(payload).encode())),
    )

    assert run_codex_hook("pre-tool-use", db_path=database) == 0
    output = json.loads(capsys.readouterr().out)
    assert output["hookSpecificOutput"]["permissionDecision"] == "deny"


@pytest.mark.parametrize("operation", ["status", "unsetup plan"])
def test_exact_local_management_does_not_wait_for_a_database_lock(
    tmp_path, monkeypatch, capsys, operation,
):
    database = tmp_path / "data" / "events.db"
    database.parent.mkdir()
    store = EventStore(database)
    store.initialize()
    context = resolve_workspace(str(tmp_path))
    store.register_workspace(context)
    root = Path(context.canonical_root or "")
    save_workspace_activations(database, str(root))
    plugin_root = tmp_path / "installed-plugin"
    launcher = plugin_root / "hooks" / "run_cli.sh"
    launcher.parent.mkdir(parents=True)
    launcher.write_text("#!/bin/sh\n", encoding="utf-8")
    command = (
        f"sh {launcher} {operation} --workspace {root} "
        f"--data-dir {database.parent} --json"
    )
    payload = {
        "cwd": str(tmp_path),
        "session_id": "locked-recovery",
        "tool_name": "Bash",
        "tool_input": {"command": command},
    }
    monkeypatch.setenv("PLUGIN_ROOT", str(plugin_root))
    monkeypatch.setattr(
        "sys.stdin",
        io.TextIOWrapper(io.BytesIO(json.dumps(payload).encode())),
    )
    blocker = sqlite3.connect(database, isolation_level=None)
    blocker.execute("BEGIN EXCLUSIVE")
    started = time.monotonic()
    try:
        assert run_codex_hook("pre-tool-use", db_path=database) == 0
    finally:
        blocker.execute("ROLLBACK")
        blocker.close()

    assert time.monotonic() - started < 0.5
    assert capsys.readouterr().out == ""


def test_proven_local_pre_tool_is_recorded_without_running_graph_analysis(
    tmp_path, monkeypatch, capsys,
):
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    context = resolve_workspace(str(tmp_path))
    store.register_workspace(context)
    save_workspace_activations(database, str(tmp_path))
    monkeypatch.setenv("TOOLUSEPROXY_PRE_TOOL_POLICY", "1")
    (tmp_path / "public.txt").write_text("public", encoding="utf-8")

    with patch(
        "hook_monitor.runtime.runner.evaluate_pre_tool_hook_policy",
        side_effect=AssertionError("local graph analysis must be skipped"),
    ):
        assert invoke(
            monkeypatch,
            capsys,
            database,
            tmp_path,
            "pre-tool-use",
            command="cat public.txt",
        ) == ""

    with sqlite3.connect(database) as connection:
        assert connection.execute(
            "SELECT COUNT(*) FROM events WHERE session_id='test'"
        ).fetchone()[0] == 1


@pytest.mark.parametrize("management_command", ["status", "verify"])
def test_reordered_probe_options_still_run_current_invocation_analysis(
    tmp_path, monkeypatch, capsys, management_command,
):
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    context = resolve_workspace(str(tmp_path))
    store.register_workspace(context)
    save_workspace_activations(database, str(tmp_path))
    plugin_root = tmp_path / "installed-plugin"
    launcher = plugin_root / "hooks" / "run_cli.sh"
    launcher.parent.mkdir(parents=True)
    launcher.write_text("#!/bin/sh\n", encoding="utf-8")
    probe_token = "tup-probe-v1-" + "a" * 32
    if management_command == "status":
        command = (
            f"sh {launcher} status --workspace {tmp_path} --json "
            f"--hook-probe-token {probe_token} --data-dir {database.parent}"
        )
    else:
        command = (
            f"sh {launcher} setup verify file-payload-exact "
            f"--workspace {tmp_path} --json --hook-probe-token {probe_token} "
            f"--data-dir {database.parent}"
        )
    monkeypatch.setenv("PLUGIN_ROOT", str(plugin_root))
    monkeypatch.setenv("TOOLUSEPROXY_PRE_TOOL_POLICY", "1")

    with patch(
        "hook_monitor.runtime.runner.evaluate_pre_tool_hook_policy",
        return_value=None,
    ) as evaluator:
        assert invoke(
            monkeypatch,
            capsys,
            database,
            tmp_path,
            "pre-tool-use",
            command=command,
        ) == ""

    evaluator.assert_called_once()


def test_legacy_registration_still_protects_and_sibling_stays_silent(
    tmp_path, monkeypatch, capsys,
):
    database = tmp_path / "events.db"
    enrolled = tmp_path / "enrolled"
    sibling = tmp_path / "sibling"
    enrolled.mkdir()
    sibling.mkdir()
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(enrolled), discovered_by="init"))
    import shutil
    shutil.rmtree(activation_directory(database))  # Existing installation before this fix.
    assert invoke(monkeypatch, capsys, database, sibling, "session-start") == ""
    assert "WebSearch" in invoke(monkeypatch, capsys, database, enrolled, "session-start")
    assert not activation_directory(database).exists()


def test_old_automatic_observation_is_not_enrollment(tmp_path, monkeypatch, capsys):
    from hook_monitor.runtime.parser import normalize_event

    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    event = normalize_event("session_start", {"cwd": str(tmp_path), "session_id": "old"})
    store.record(event, [])
    assert invoke(monkeypatch, capsys, database, tmp_path, "session-start") == ""


def test_lost_registration_is_not_silently_replaced_with_defaults(tmp_path, monkeypatch, capsys):
    import sqlite3

    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(tmp_path)))
    with sqlite3.connect(database) as connection:
        connection.execute("DELETE FROM workspaces")
    output = json.loads(invoke(monkeypatch, capsys, database, tmp_path, "pre-tool-use"))
    assert output["hookSpecificOutput"]["permissionDecision"] == "deny"


def test_input_replay_preserves_bytes_and_bounded_read():
    from tooluseproxy.integrations.codex import _ReplayInput

    remainder = io.BytesIO(b"tail")
    replay = _ReplayInput(b"prefix", remainder)
    assert replay.read(3) == b"pre"
    assert remainder.tell() == 0
    assert replay.read(4) == b"fixt"
    assert replay.read() == b"ail"


def test_enrollment_updates_keep_previous_projects(tmp_path):
    from tooluseproxy.integrations.activation import enabled_workspace_root

    first = tmp_path / "first"
    second = tmp_path / "second"
    first.mkdir()
    second.mkdir()
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(first), discovered_by="init"))
    store.register_workspace(resolve_workspace(str(second), discovered_by="init"))
    assert enabled_workspace_root(database, str(first)) == str(first)
    assert enabled_workspace_root(database, str(second)) == str(second)
    assert activation_path(database, str(first)).stat().st_mode & 0o777 == 0o600


def test_partial_marker_migration_keeps_database_fallback_per_project(tmp_path):
    from tooluseproxy.integrations.activation import enabled_workspace_root

    first = tmp_path / "first"
    second = tmp_path / "second"
    first.mkdir()
    second.mkdir()
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(first), discovered_by="init"))
    store.register_workspace(resolve_workspace(str(second), discovered_by="init"))

    activation_path(database, str(second)).unlink()
    activation_migration_complete_path(database).unlink()
    assert activation_path(database, str(first)).is_file()
    assert enabled_workspace_root(database, str(second)) == str(second)

    save_workspace_activations(database)
    assert activation_path(database, str(second)).is_file()
    assert activation_migration_complete_path(database).is_file()


def test_automatic_child_registration_cannot_replace_enabled_parent(tmp_path, monkeypatch, capsys):
    import sqlite3
    from hook_monitor.runtime.parser import normalize_event

    child = tmp_path / "child"
    child.mkdir()
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(tmp_path)))
    store.record(normalize_event("session_start", {
        "cwd": str(child), "session_id": "old-child",
    }), [])
    monkeypatch.setenv("TOOLUSEPROXY_WORKSPACE_ROOT", str(child))
    assert "WebSearch" in invoke(monkeypatch, capsys, database, child, "session-start")
    with sqlite3.connect(database) as connection:
        root = connection.execute(
            "SELECT workspace_root FROM events WHERE session_id='test'"
        ).fetchone()[0]
    assert root == str(tmp_path)


def test_enabled_parent_does_not_activate_nested_repository(tmp_path, monkeypatch, capsys):
    parent = tmp_path / "parent"
    child = parent / "child-repository"
    child.mkdir(parents=True)
    (child / ".git").mkdir()
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(parent)))
    assert invoke(monkeypatch, capsys, database, child, "session-start") == ""


def test_corrupt_marker_affects_only_its_project(tmp_path, monkeypatch, capsys):
    enabled = tmp_path / "enabled"
    unrelated = tmp_path / "unrelated"
    enabled.mkdir()
    unrelated.mkdir()
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(enabled)))
    activation_path(database, str(enabled)).write_text("broken marker")
    assert invoke(monkeypatch, capsys, database, unrelated, "session-start") == ""
    output = json.loads(invoke(monkeypatch, capsys, database, enabled, "pre-tool-use"))
    assert output["hookSpecificOutput"]["permissionDecision"] == "deny"


def test_concurrent_enrollment_keeps_every_project(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    from tooluseproxy.integrations.activation import enabled_workspace_root

    database = tmp_path / "events.db"
    EventStore(database).initialize()
    roots = [tmp_path / f"project-{index}" for index in range(8)]
    for root in roots:
        root.mkdir()

    def enroll(root):
        EventStore(database).register_workspace(resolve_workspace(str(root)))

    with ThreadPoolExecutor(max_workers=4) as executor:
        list(executor.map(enroll, roots))
    assert all(
        enabled_workspace_root(database, str(root)) == str(root)
        for root in roots
    )


def test_missing_payload_cwd_uses_current_unconfigured_project(
    tmp_path, monkeypatch, capsys,
):
    enabled = tmp_path / "enabled"
    unrelated = tmp_path / "unrelated"
    enabled.mkdir()
    unrelated.mkdir()
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(enabled)))
    monkeypatch.chdir(unrelated)
    monkeypatch.setattr("sys.stdin", io.TextIOWrapper(
        io.BytesIO(b'{"hook_event_name":"SessionStart"}')
    ))
    assert run_codex_hook("session-start", db_path=database) == 0
    assert capsys.readouterr().out == ""


def test_activation_directory_creation_without_marker_keeps_legacy_protection(
    tmp_path, monkeypatch, capsys,
):
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(tmp_path), discovered_by="init"))
    import shutil
    shutil.rmtree(activation_directory(database))
    activation_directory(database).mkdir()
    assert "WebSearch" in invoke(
        monkeypatch, capsys, database, tmp_path, "session-start"
    )


def test_enabled_stop_only_reserves_detached_cleanup(
    tmp_path, monkeypatch, capsys,
):
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(tmp_path)))
    now = datetime.now(UTC)
    plan = plan_storage_cleanup(database, now=now)
    enable_automatic_cleanup(
        database,
        cutoff_at=plan.cutoff_at,
        reviewed_at=plan.reviewed_at,
        expected_plan_revision=plan.plan_revision,
        now=now,
    )
    launched = []

    def record_launch(command, **options):
        launched.append((command, options))
        return object()

    monkeypatch.setattr(automatic_cleanup.subprocess, "Popen", record_launch)

    assert invoke(monkeypatch, capsys, database, tmp_path, "stop") == ""
    assert len(launched) == 1
    assert launched[0][0][-7:-3] == ["storage", "cleanup", "auto", "run"]
    assert launched[0][1]["start_new_session"] is True
    assert (
        tmp_path / automatic_cleanup.AUTOMATIC_CLEANUP_REQUEST_FILENAME
    ).is_file()
    assert (tmp_path / automatic_cleanup.RUNTIME_ACTIVITY_FILENAME).is_file()
    assert automatic_cleanup.automatic_cleanup_status(tmp_path)["status"] == "waiting"


def test_pending_cleanup_notice_is_shown_once_at_next_session_start(
    tmp_path, monkeypatch, capsys,
):
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(tmp_path)))
    state = automatic_cleanup._empty_state()
    state["notification_pending"] = "cleanup_failed"
    automatic_cleanup._write_state(tmp_path, state)

    first = invoke(monkeypatch, capsys, database, tmp_path, "session-start")
    second = invoke(monkeypatch, capsys, database, tmp_path, "session-start")

    assert "自動整理を完了できませんでした" in first
    assert "自動整理を完了できませんでした" not in second


def test_failed_stop_reservation_is_saved_for_next_session_start(
    tmp_path, monkeypatch, capsys,
):
    database = tmp_path / "events.db"
    store = EventStore(database)
    store.initialize()
    store.register_workspace(resolve_workspace(str(tmp_path)))
    now = datetime.now(UTC)
    plan = plan_storage_cleanup(database, now=now)
    enable_automatic_cleanup(
        database,
        cutoff_at=plan.cutoff_at,
        reviewed_at=plan.reviewed_at,
        expected_plan_revision=plan.plan_revision,
        now=now,
    )

    def fail_launch(*args, **kwargs):
        raise OSError("injected launch failure")

    monkeypatch.setattr(automatic_cleanup.subprocess, "Popen", fail_launch)

    assert invoke(monkeypatch, capsys, database, tmp_path, "stop") == ""
    status = automatic_cleanup.automatic_cleanup_status(tmp_path)
    assert status["reason"] == "cleanup_reservation_failed"
    assert status["notification_pending"] is True
    notice = invoke(monkeypatch, capsys, database, tmp_path, "session-start")
    assert "自動整理を完了できませんでした" in notice
